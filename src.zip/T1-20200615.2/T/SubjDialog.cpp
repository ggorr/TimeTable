// SubjDialog.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "T.h"

#include "Base.h"
#include "Inst.h"
#include "Team.h"
#include "Lect.h"
#include "Subj.h"

#include "TDialog.h"
#include "SubjDialog.h"
#include "TeamDialog.h"
#include "LectDialog.h"

#include "DataManager.h"

#define WIDTH_NO		45
#define WIDTH_ID		30
#define WIDTH_NAME		120	
#define WIDTH_GRADE		45
#define WIDTH_TEAM		50
#define WIDTH_LECT		50
#define WIDTH_NPRDS		50
#define WIDTH_NOTE		100
#define WIDTH_LIST		(WIDTH_NO+WIDTH_ID+WIDTH_NAME+WIDTH_GRADE+WIDTH_NPRDS+WIDTH_TEAM+WIDTH_LECT+WIDTH_NOTE+20)


// CSubjListCtrl

IMPLEMENT_DYNAMIC(CSubjListCtrl, CTListCtrl)

CSubjListCtrl::CSubjListCtrl()
{
	m_vecB = &TheSubjs;

	m_nCols = 8;

	m_primaryCol = COL_NONE;

	m_editableCols.push_back(COL_SUBJ_ID);
	m_editableCols.push_back(COL_SUBJ_NAME);
	m_editableCols.push_back(COL_SUBJ_NOTE);

	m_comboBoxCols.push_back(COL_SUBJ_GRADE);
	
	m_funcCols.push_back(COL_SUBJ_TEAM);

	m_funcs.push_back(&CTListCtrl::PickTeam);
}

CSubjListCtrl::~CSubjListCtrl()
{
}


BEGIN_MESSAGE_MAP(CSubjListCtrl, CTListCtrl)
END_MESSAGE_MAP()

COLORREF CSubjListCtrl::OnGetCellBkColor(int nRow, int nColumn)
{
	return RGB(255,255,255);
}


void CSubjListCtrl::Initialize()
{
	vector<LPCTSTR> labels;
	labels.push_back(_T("��ȣ"));
	labels.push_back(_T("ID"));
	labels.push_back(_T("�̸�"));
	labels.push_back(_T("�г�"));
	labels.push_back(_T("����"));
	labels.push_back(_T("����"));
	labels.push_back(_T("�ð� ��"));
	labels.push_back(_T("��Ÿ"));

	vector<int>widths;
	widths.push_back(WIDTH_NO);
	widths.push_back(WIDTH_ID);
	widths.push_back(WIDTH_NAME);
	widths.push_back(WIDTH_GRADE);
	widths.push_back(WIDTH_TEAM);
	widths.push_back(WIDTH_LECT);
	widths.push_back(WIDTH_NPRDS);
	widths.push_back(WIDTH_NOTE);

	vector<int> lvcfmt;
	lvcfmt.push_back(LVCFMT_LEFT);
	lvcfmt.push_back(LVCFMT_LEFT);
	lvcfmt.push_back(LVCFMT_LEFT);
	lvcfmt.push_back(LVCFMT_CENTER);
	lvcfmt.push_back(LVCFMT_LEFT);
	lvcfmt.push_back(LVCFMT_CENTER);
	lvcfmt.push_back(LVCFMT_CENTER);
	lvcfmt.push_back(LVCFMT_LEFT);

	CTListCtrl::Initialize(labels, widths, lvcfmt);
}

void CSubjListCtrl::PostCopyEditToCell()
{
	if(m_selectedCol == COL_SUBJ_NAME)
	{
		m_dlg->GetRefererDlg()->GetList()->UpdateCol(COL_LECT_SUBJ);
		theApp.ResetTables();
	}
}

void CSubjListCtrl::PostCopyComboBoxToCell()
{
	m_dlg->GetRefererDlg()->GetList()->UpdateCol(COL_LECT_GRADE);
}

void CSubjListCtrl::PickTeam()
{
	CTeamDialog dlg;
	// dlg�� call�ϴ� dialog�� CLectDialog�̴�.
	dlg.SetRefererDlg(m_dlg);
	// ������ CTeamDialog�� modal�̹Ƿ� modeless dialog�� �����ؾ� �Ѵ�.
	dlg.SetMode(MODE_MODAL);
	dlg.SetTitle(_T("���� ���(����) - ����"));
	dlg.SetMaxCheckedRows(1);

	// ��ϵ� ���縦 dialog�� �Ѱܼ� check�ϵ��� �Ѵ�.
	// CSubj* subj = (CSubj*) TheSubjs[m_selectedRow];
	CSubj* subj = CSubj::Get(m_selectedRow);
	if(subj->GetTeam() != NULL)
		dlg.PushBackCheckedRow(subj->GetTeam()->GetRow());

	if(dlg.DoModal() == IDC_SELECT)
	{
		if(dlg.GetCheckedRows().size() == 0)
			subj->SetTeam(NULL);
		else
			subj->SetTeam(CTeam::Get(dlg.GetCheckedRows()[0]));
		UpdateRow(m_selectedRow);
		theApp.ResetTables();
	}
	m_state = DSTATE_SELECTED;
}

CSubjDialog TheSubjModelessDlg;

// CSubjDialog ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CSubjDialog, CTDialog)


CSubjDialog::CSubjDialog(CWnd* pParent)
	: CTDialog(CSubjDialog::IDD, pParent)
{
}

CSubjDialog::~CSubjDialog()
{
}

void CSubjDialog::DoDataExchange(CDataExchange* pDX)
{
	CTDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST, theList);
}

BEGIN_MESSAGE_MAP(CSubjDialog, CTDialog)
	ON_BN_CLICKED(IDC_DELETE, &CSubjDialog::OnBnClickedDelete)
END_MESSAGE_MAP()

// CSubjDialog �޽��� ó�����Դϴ�.

BOOL CSubjDialog::OnInitDialog()
{
	CTDialog::OnInitDialog();

	//SetWindowText(_T("������ ���"));

	theComboBox.Create(WS_CHILD | CBS_DROPDOWNLIST, CRect(0,0,0,0), this, IDC_COMBO);
	theList.SetComboBox(&theComboBox);

	m_list = &theList;

	PostInitDialog(WIDTH_LIST);

	for(int i = 0; i < TheDataMgr.GetNGrades(); i++)
		theComboBox.AddString(TheDataMgr.GetGrade(i));
	theComboBox.AddString(_T("����"));

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSubjDialog::OnBnClickedDelete()
{
	// lect dialog���� ��� checked subjs ����
	// lect ��ü�� ���ŵ�
	BOOL* subjs = new BOOL[TheSubjs.GetSize()];
	ZeroMemory(subjs, sizeof(BOOL)*TheSubjs.GetSize());
	BOOL* lects = new BOOL[TheLects.GetSize()];
	ZeroMemory(lects, sizeof(BOOL)*TheLects.GetSize());

	for(int i = 0; i < TheSubjs.GetSize(); i++)
		if(m_list->GetCheck(i))
		{
			subjs[i] = TRUE;
			for(int j = 0; j < TheLects.GetSize(); j++)
				if(CLect::Get(j)->GetSubj() == TheSubjs[i])
					lects[j] = TRUE;
		}

	// lect ����
	m_refererDlg->DeleteRows(lects);

	// list ����
	DeleteRows(subjs);
	delete[] lects;
	delete[] subjs;
	theApp.ResetTables();
}
