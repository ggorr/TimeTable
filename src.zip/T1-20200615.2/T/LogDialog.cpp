// LogDialog.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "T.h"
#include "LogDialog.h"
#include "DataManager.h"

#define BTN_WIDTH	100
#define BTN_HEIGHT	28

// CLogDialog ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CLogDialog, CDialog)

CLogDialog::CLogDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CLogDialog::IDD, pParent)
{
	m_Position = NULL;
}

CLogDialog::~CLogDialog()
{
	if(m_Position != NULL)
		free(m_Position);
}

void CLogDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST, m_List);
}


BEGIN_MESSAGE_MAP(CLogDialog, CDialog)
	ON_WM_SIZE()
END_MESSAGE_MAP()

BOOL CLogDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_List.SetExtendedStyle(LVS_EX_CHECKBOXES | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES); 
	/*
	 * LVS_REPORT: ����Ʈ �������� ����Ѵ�. LVS_ICON, LVS_SMALLICON, LVS_LIST
	*/
	m_List.ModifyStyle(NULL, LVS_REPORT | LVS_SINGLESEL | LVS_ALIGNLEFT);

	Resize();

	m_List.InsertColumn(0, _T("�̸�"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(1, _T("��¥"), LVCFMT_LEFT, 320);

	CStdioFile file;
	if(!file.Open(m_LogPath, CFile::modeRead))
		return TRUE;
	int nRow = 0, pos;
	CString line, str;
	while(file.ReadString(line))
	{
		if(line.Left(10).Compare(_T("LOGGING AT")) == 0)
		{
			if(nRow % 20 == 0)
				m_Position = (ULONGLONG*) realloc(m_Position, sizeof(ULONGLONG)*(nRow+20));
			m_Position[nRow] = file.GetPosition();
			m_List.InsertItem(nRow, _T(""));
			m_List.SetItemText(nRow, 1, line.Mid(11).Trim());
			CDataManager::ReadHeaderedString(file, line, FILENAME_HEADER);
			pos = 0;
			CDataManager::GetSeparatedString(line, PRI_SEPARATOR, pos, str);
			m_List.SetItemText(nRow++, 0, str);
		}
	}
	file.Close();
	RECT rect;
	m_List.GetItemRect(0, &rect, LVIR_BOUNDS);
	int vScrollPos = m_List.GetItemCount()*(rect.bottom - rect.top);
	m_List.Scroll(CSize(0, vScrollPos));
	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CLogDialog::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);
	Resize();
}

void CLogDialog::Resize()
{
	if(m_List.GetSafeHwnd() == NULL) return;
	
	RECT rect;
	GetClientRect(&rect);
	RECT rect1 = rect;
	rect1.bottom -= BTN_HEIGHT+10;
	m_List.MoveWindow(&rect1);
	rect1.right = rect.right - 3;
	rect1.left = rect1.right - BTN_WIDTH;
	rect1.bottom = rect.bottom - 3;
	rect1.top = rect1.bottom - BTN_HEIGHT - 3;
	GetDlgItem(IDCANCEL)->MoveWindow(&rect1);
	rect1.left -= BTN_WIDTH+3;
	rect1.right -= BTN_WIDTH+3;
	GetDlgItem(IDOK)->MoveWindow(&rect1);
}

// CLogDialog �޽��� ó�����Դϴ�.
CString CLogDialog::GetFileName()
{
	return m_Filename;
}

ULONGLONG CLogDialog::GetFilePosition()
{
	return m_Position[m_Row];
}

void CLogDialog::OnOK()
{
	m_Row = -1;
	for(int i=m_List.GetItemCount()-1; i>=0; i--)
	{
		if(m_List.GetCheck(i))
		{
			m_Row = i;
			m_Filename = m_List.GetItemText(m_Row, 0);
			break;
		}
	}
	if(m_Row >= 0)
		EndDialog(IDOK);
	else
		EndDialog(IDCANCEL);
}
