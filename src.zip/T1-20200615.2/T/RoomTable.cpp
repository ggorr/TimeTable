// GradeTable.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "T.h"

#include "Base.h"
#include "Inst.h"
#include "Team.h"
#include "Room.h"
#include "Subj.h"
#include "Lect.h"

#include "TTable.h"
#include "RoomTable.h"

#include "DataManager.h"

// CRoomTable

IMPLEMENT_DYNCREATE(CRoomTable, CTTable)

CRoomTable::CRoomTable()
{
}

CRoomTable::~CRoomTable()
{
}

BEGIN_MESSAGE_MAP(CRoomTable, CTTable)
END_MESSAGE_MAP()

// CRoomTable �����Դϴ�.

#ifdef _DEBUG
void CRoomTable::AssertValid() const
{
	CTTable::AssertValid();
}

#ifndef _WIN32_WCE
void CRoomTable::Dump(CDumpContext& dc) const
{
	CTTable::Dump(dc);
}
#endif
#endif //_DEBUG

void CRoomTable::Initialize()
{
	m_name = AllocCharBuffer(m_name, TheDataMgr.GetRoomTableName());
	m_sectTitles.clear();
	m_lects.clear();
	for(int i = m_order*TheDataMgr.GetNSects(); i < (m_order+1)*TheDataMgr.GetNSects(); i++)
	{
		if(i < CRoom::GetSize())
		{
			vector<CLect*> lects;
			CRoom* room = CRoom::Get(i);
			m_sectTitles.push_back(room->GetName());
			for(int j=0; j<TheLects.GetSize(); j++)
			{
				CLect* lect = CLect::Get(j);
				if(lect->HasRoom(room) && lect->GetDay() != NONE &&
					lect->GetSPrd() != NONE && lect->GetEPrd() != NONE)
					lects.push_back(CLect::Get(j));
			}
			m_lects.push_back(lects);				
		}
		else
			break;
	}
	m_nValidSects = (int) m_sectTitles.size();
}

void CRoomTable::GetLectString(CLect* lect, CString& str)
{
	CSubj* subj = lect->GetSubj();
	if(subj != NULL)
	{
		CString strTemp;
		str = subj->GetName();
		subj->GetInString(COL_SUBJ_GRADE, strTemp);
		str.AppendFormat(_T("\n(%s)\n"), strTemp);
		subj->GetInString(COL_SUBJ_TEAM, strTemp);
		str += strTemp;
	}
	else
		str = _T("()");
}

void CRoomTable::GetHmlLectString(CString& str, CString& format, CLect* lect)
{
	CString strTemp;
	CSubj* subj = lect->GetSubj();
	if(subj != NULL)
	{
		str.Format(format, 1, subj->GetName());
		subj->GetInString(COL_SUBJ_GRADE, strTemp);
		str.AppendFormat(format, 1, _T("(") + strTemp + _T(")\n"));
		subj->GetInString(COL_SUBJ_TEAM, strTemp);
		str.AppendFormat(format, 1, strTemp);
	}
	else
		str.Format(format, 1, _T("()"));
}