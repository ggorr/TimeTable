#pragma once


// CRoomTable ���Դϴ�.

class CRoomTable : public CTTable
{
	DECLARE_DYNCREATE(CRoomTable)

protected:
	CRoomTable();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CRoomTable();

public:
	void Initialize();
	void GetLectString(CLect* lect, CString& str);
	void GetHmlLectString(CString& str, CString& format, CLect* lect);

#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	DECLARE_MESSAGE_MAP()
public:
};


