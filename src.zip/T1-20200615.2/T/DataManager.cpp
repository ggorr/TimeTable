#include "StdAfx.h"
#include "DataManager.h"
#include "T.h"

#include "Base.h"
#include "Room.h"
#include "Inst.h"
#include "Team.h"
#include "Lect.h"
#include "Subj.h"

#include "Hml.h"

#include "TTable.h"

CDataManager TheDataMgr;

CDataManager::CDataManager(void)
{
	m_pathName = NULL;
	m_days = NULL;
	m_times = NULL;
	m_prds = NULL;
	m_grades = NULL;
	m_title = NULL;

	m_title = NULL;
}

CDataManager::~CDataManager(void)
{
	if(m_pathName != NULL)
		free(m_pathName);

	if(m_title != NULL)
		free(m_title);

	if(m_gradeTableName != NULL)
		free(m_gradeTableName);
	if(m_instTableName != NULL)
		free(m_instTableName);
	if(m_roomTableName != NULL)
		free(m_roomTableName);

	DeleteBiArray(m_days, m_nDays);
	DeleteBiArray(m_times, m_nPrds);
	DeleteBiArray(m_prds, m_nPrds);
	DeleteBiArray(m_grades, m_nGrades);
}

void CDataManager::LoadTestData()
{
	// ����
#define _FROMSTRING
#ifndef _FROMSTRING
	int n = 0;
	CInst* inst;
	inst = CInst::Create(_T("�� ���"));
	inst->SetNote(_T("���� ����"));
	CInst::Create(_T("�ڸ�"))->SetNote(_T("���� ����"));
	CInst::Create()->FromString(_T(";�� ���;���� ����;"), n);
	CInst::Create(_T("���"));
	CInst::Create(_T("�ȵ��Ͳ�����"))->SetNote(_T("���� �ְ��� ������"));

	CTeam::Create()->AddInst(CInst::Get(0));
		CTeam::Get(0)->SetColor(RGB(255,127,0));
	CTeam::Create()->AddInst(CInst::Get(1));
		CTeam::Get(1)->SetColor(RGB(0,255,127));
	CTeam::Create()->AddInst(CInst::Get(2));
		CTeam::Get(2)->SetColor(RGB(127,0,255));
	CTeam::Create()->AddInst(CInst::Get(3));
		CTeam::Get(3)->SetColor(RGB(0, 127, 255));
	n = 0;
	CTeam::Create()->FromString(_T(";;0;;4,;;"), n);
	CTeam::Create(_T("��1"));
		CTeam::Get(5)->SetGroup(TRUE);
		CTeam::Get(5)->AddInst(CInst::Get(_T("�� ���")));
		CTeam::Get(5)->AddInst(CInst::Get(_T("�ڸ�")));
	n = 0;
	CTeam::Create()->FromString(_T(";16744192;1;��2;0,4,;ȯ���� Ŀ��;"), n);

	n = 0;
	CRoom::Create()->FromString(_T(";���ǽ� 514;"), n);
	CRoom::Create(_T("���ǽ� 515"));
		CRoom::Get(1)->SetByString(COL_ROOM_NOTE, _T("���� �ο� 30"));
	CRoom::Create(_T("���ǽ� 299"));
		TheRooms.SetByString(2, COL_ROOM_NOTE, _T("õ�� ���ǽ�"));		
	CRoom::Create(_T("ū ���ǽ�"));
		CRoom::Get(3)->SetNote(_T("���� �ο� 5õ����"));
	n = 0;
	CRoom::Create()->FromString(_T(";���ǽ� 300;���� ����?;"), n);
	CRoom::Create(_T("�ܺ�"));

	CSubj::Create(_T("����"));
		CSubj::Get(0)->SetTeam(CTeam::Get(0));
		CSubj::Get(0)->SetGrade(0);
	CSubj::Create(_T("����"));
		((CSubj*)TheSubjs[1])->SetTeam(CTeam::Get(5));
		((CSubj*)TheSubjs[1])->SetGrade(2);
	CSubj::Create(_T("���� Ȳ��"));
		CSubj::Get(0)->SetTeam(CTeam::Get(3));
	CSubj::Create(_T("3D ������"));
		CSubj::Get(3)->SetGrade(3);
		CSubj::Get(3)->SetTeam(CTeam::Get(5));

	CLect::Create(CSubj::Get(_T("����")), CRoom::Get(0), 0, 2, 4);
	CLect::Create(CSubj::Get(1), CRoom::Get(0), 1, 6, 8);
		CLect::SetByString(1, COL_LECT_NOTE, _T("���ǽ��� �۾ƿ�"));
	CLect::Create(CSubj::Create(_T("���� ����")), CRoom::Get(_T("���ǽ� 299")), 3, 11, 12);
		CSubj::Get(_T("���� ����"))->SetByString(COL_SUBJ_GRADE, _T("4�г�"));
	CLect::Create()->CaptureSubj(CSubj::Get(4));
		CLect::Get(3)->SetRoom(CRoom::Get(5));
		CLect::Get(3)->SetDay(0);
	CLect::Create();
		CLect::Get(4)->CaptureSubj(CSubj::Get(3));
		CLect::Get(4)->SetRoom(CRoom::Get(5));
		CLect::SetByString(4, COL_LECT_PRD, _T("4~9"));
		CLect::SetByString(4, COL_LECT_DAY, _T("��"));
	CLect::Create(CSubj::Get(0), CRoom::Get(3), 2, 3, 5);
	n = 0;
	CLect::Create()->FromString(_T(";0;1;4;3~5;;"), n);
	CLect::Create()->CaptureSubj(CSubj::Get(2));
#else
	CInst::BuildFromString(_T("0;�� ���;���� ����;1;�ڸ�;���� ����;2;�� ���;���� ����;3;���;;4;�ȵ��Ͳ�����;���� �ְ��� ������;"));
	CTeam::BuildFromString(_T("0;32767;0;;0,;;1;8388352;0;;1,;;2;16711807;0;;2,;;3;16744192;0;;3,;;4;65535;0;;4,;;5;16776960;1;��1;2,1,;;6;16744703;1;��2;0,4,;ȯ���� Ŀ��;"));
	CRoom::BuildFromString(_T("0;����� 514;;1;���� 1�� 515;���� �ο� 30;2;������ 299;õ�� ���ǽ�;3;���� ���ǽ�;���� �ο� 5õ����;4;���� 300;;5;�ܺ�;���� ����?;"));
	CSubj::BuildFromString(_T("0;;����;0;4;5,6,;6;;1;;�����;2;5;0,1,;6;;2;;���� Ȳ��;;;7,;4;;3;;3D ������;3;3;4,;6;;4;;��ȭ ����;3;0;2,3,;6;;"));
	CLect::BuildFromString(_T("0;1;0;0;2~4;2;;1;1;0;1;6~8;2;���ǽ��� �۾ƿ�;2;4;2;3;10~12;3;;3;4;5;0;1~3;3;;4;3;5;4;3~8;3;;5;0;3;2;3~5;0;;6;0;1;4;3~5;0;;7;2;;;1~4;;;"));
#endif

	//m_pathName = AllocCharBuffer(m_pathName, GetModuleFolderPath()+_T("Test.tsv"));
}

CString CDataManager::GetFileName()
{
	CString filename;
	GetWindowText(theApp.m_pMainWnd->GetSafeHwnd(), filename.GetBuffer(MAX_PATH), MAX_PATH);
	filename.ReleaseBuffer();
	return filename.Mid(_tcslen(NAME_MAINWND)+3);
}

void CDataManager::SetFileName(LPCTSTR filename)
{
	CString title;
	title.Format(_T("%s - %s"), NAME_MAINWND, filename);
	SetWindowText(theApp.m_pMainWnd->GetSafeHwnd(), title);
}

int CDataManager::GetDayIndex(LPCTSTR dayStr)
{
	if(dayStr != NULL)
		for(int i=0; i<m_nDays; i++)
			if(_tcscmp(dayStr, CString(m_days[i]).Trim()) == 0)
				return i;
	return NONE;
}

int CDataManager::GetPrdIndex(LPCTSTR prdStr)
{
	if(prdStr != NULL)
		for(int i=0; i<m_nPrds; i++)
			if(_tcscmp(prdStr, CString(m_prds[i]).Trim()) == 0)
				return i;
	return NONE;
}

int CDataManager::GetGradeIndex(LPCTSTR gradeStr)
{
	if(gradeStr != NULL)
		for(int i=0; i<m_nGrades; i++)
			if(_tcscmp(gradeStr, CString(m_grades[i]).Trim()) == 0)
				return i;
	return NONE;
}

void CDataManager::LoadDefaultCfg()
{
	DeleteBiArray(m_days, m_nDays);
	DeleteBiArray(m_times, m_nPrds);
	DeleteBiArray(m_prds, m_nPrds);
	DeleteBiArray(m_grades, m_nGrades);

	m_nSects = N_SECTS;
	m_nGrades = N_GRADES;
	m_nDays = N_DAYS;
	m_nPrds = N_PRDS;

	m_gradeTableName = AllocCharBuffer(m_gradeTableName, GRADETABLE_NAME);
	m_instTableName = AllocCharBuffer(m_instTableName, INSTTABLE_NAME);
	m_roomTableName = AllocCharBuffer(m_roomTableName, ROOMTABLE_NAME);

	CHml::Sizes[wdTable] = HML_TABLEWIDTH;
	CHml::Sizes[wdTime] = HML_TIMEWIDTH;
	CHml::Sizes[wdPrd] = HML_PRDWIDTH;
	CHml::Sizes[wdDay] = HML_DAYWIDTH;
	CHml::Sizes[htTable] = HML_TABLEHEIGHT;
	CHml::Sizes[htSect] = HML_SECTHEIGHT;
	CHml::Sizes[htDay] = HML_DAYHEIGHT;
	CHml::Sizes[htPrd] = HML_PRDHEIGHT;

	m_days = new LPTSTR[m_nDays];
	m_days[0] = new TCHAR[2];	_tcscpy_s(m_days[0], 2, _T("��"));
	m_days[1] = new TCHAR[2];	_tcscpy_s(m_days[1], 2, _T("ȭ"));
	m_days[2] = new TCHAR[2];	_tcscpy_s(m_days[2], 2, _T("��"));
	m_days[3] = new TCHAR[2];	_tcscpy_s(m_days[3], 2, _T("��"));
	m_days[4] = new TCHAR[2];	_tcscpy_s(m_days[4], 2, _T("��"));

	m_times = new LPTSTR[m_nPrds];
	m_prds = new LPTSTR[m_nPrds];
	for(int i=0; i<m_nPrds; i++)
	{
		m_times[i] = new TCHAR[12];
		m_prds[i] = new TCHAR[3];
		if(i%2 == 0)
			wsprintf(m_times[i], _T("%02d:00~%02d:30"), i/2+9, i/2+9);
		else
			wsprintf(m_times[i], _T("%02d:30~%02d:00"), i/2+9, i/2+10);
		wsprintf(m_prds[i], _T("%d"), i+1);
	}

	m_grades = new LPTSTR[m_nGrades];
	for(int i=0; i<m_nGrades; i++)
	{
		m_grades[i] = new TCHAR[4];
		wsprintf(m_grades[i], _T("%d�г�"), i+1);
	}
}

int CDataManager::LoadCfg(CStdioFile& file, ULONGLONG initPos)
{
	CString str;

	// subtitles
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, SUBTITLE_HEADER))
		return CFG_UNKNOWN;
	int pos = 0;
	CString str1;
	if (GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		m_gradeTableName = AllocCharBuffer(m_gradeTableName, Deescape(str1));
	if (GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		m_instTableName = AllocCharBuffer(m_instTableName, Deescape(str1));
	if (GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		m_roomTableName = AllocCharBuffer(m_roomTableName, Deescape(str1));
	// NSects
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, NSECTS_HEADER))
		return CFG_UNKNOWN;
	_stscanf_s(str, _T("%d"), &m_nSects);
	// days
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, DAYS_HEADER))
		return CFG_UNKNOWN;
	BuildBiArray(str, PRI_SEPARATOR, m_nDays, m_days);
	// grades
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, GRADES_HEADER))
		return CFG_UNKNOWN;
	BuildBiArray(str, PRI_SEPARATOR, m_nGrades, m_grades);
	// prds
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, PRDS_HEADER))
		return CFG_UNKNOWN;
	int nPrds = m_nPrds;
	BuildBiArray(str, PRI_SEPARATOR, m_nPrds, m_prds);
	// times
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, TIMES_HEADER))
		return CFG_UNKNOWN;
	BuildBiArray(str, PRI_SEPARATOR, nPrds, m_times);
	// hml table sizes
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, TABLEWIDTH_HEADER))
		return CFG_UNKNOWN;
	_stscanf_s(str, _T("%d"), &CHml::Sizes[wdTable]);
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, TABLEHEIGHT_HEADER))
		return CFG_UNKNOWN;
	_stscanf_s(str, _T("%d"), &CHml::Sizes[htTable]);
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, TIMEWIDTH_HEADER))
		return CFG_UNKNOWN;
	_stscanf_s(str, _T("%d"), &CHml::Sizes[wdTime]);
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, PRDWIDTH_HEADER))
		return CFG_UNKNOWN;
	_stscanf_s(str, _T("%d"), &CHml::Sizes[wdPrd]);
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, SECTHEIGHT_HEADER))
		return CFG_UNKNOWN;
	_stscanf_s(str, _T("%d"), &CHml::Sizes[htSect]);
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, DAYHEIGHT_HEADER))
		return CFG_UNKNOWN;
	_stscanf_s(str, _T("%d"), &CHml::Sizes[htDay]);
	file.Seek(initPos, CFile::begin);

	// Hml
	CHml::Sizes[wdDay] = (int)((CHml::Sizes[wdTable] - CHml::Sizes[wdTime] -
		TheDataMgr.GetNSects() * CHml::Sizes[wdPrd]) / (TheDataMgr.GetNSects() * TheDataMgr.GetNDays()));
	CHml::Sizes[wdTable] = CHml::Sizes[wdTime] +
		TheDataMgr.GetNSects() * (CHml::Sizes[wdPrd] + TheDataMgr.GetNDays() * CHml::Sizes[wdDay]);
	CHml::Sizes[htPrd] = (int)((CHml::Sizes[htTable] - CHml::Sizes[htSect] - CHml::Sizes[htDay]) / TheDataMgr.GetNPrds());
	CHml::Sizes[htTable] = CHml::Sizes[htSect] + CHml::Sizes[htDay] + TheDataMgr.GetNPrds() * CHml::Sizes[htPrd];

	// version
	file.Seek(initPos, CFile::begin);
	if (!ReadHeaderedString(file, str, VERSION_HEADER))
		return CFG_VERSION_MISMATCH;
	pos = 0;
	if (!GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return CFG_VERSION_MISMATCH;
	pos = str1.Find(L'.', str1.Trim().Find(L'.', 0) + 1);
	return pos > 0 && str1.Left(pos).Compare(CString(VERSION).Left(pos)) == 0 ? CFG_CURRENT_VERSION : CFG_VERSION_MISMATCH;
}

CString CDataManager::LoadAll(CStdioFile& file, ULONGLONG initPos)
{
	int cfgType = LoadCfg(file, initPos);

	CString str;
	// title
	file.Seek(initPos, CFile::begin);
	ReadHeaderedString(file, str, TITLE_HEADER);
	CString str1;
	int pos = 0;
	if(GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		m_title = AllocCharBuffer(m_title, Deescape(str1));
	else
		m_title = AllocCharBuffer(m_title, Deescape(str));

	CInst::Clear();
	CTeam::Clear();
	CRoom::Clear();
	CSubj::Clear();
	CLect::Clear();

	// ����-����
	file.Seek(initPos, CFile::begin);
	ReadHeaderedString(file, str, INST_HEADER);
	CInst::BuildFromString(str);
	// ����-����
	file.Seek(initPos, CFile::begin);
	ReadHeaderedString(file, str, TEAM_HEADER);
	CTeam::BuildFromString(str);
	CTeam::DetermineIndexForNew();
	// ���ǽ�
	file.Seek(initPos, CFile::begin);
	ReadHeaderedString(file, str, ROOM_HEADER);
	CRoom::BuildFromString(str);
	CRoom::DetermineIndexForNew();
	// ������
	file.Seek(initPos, CFile::begin);
	ReadHeaderedString(file, str, SUBJ_HEADER);
	CSubj::BuildFromString(str);
	CSubj::DetermineIndexForNew();
	// ����
	file.Seek(initPos, CFile::begin);
	ReadHeaderedString(file, str, LECT_HEADER);
	CLect::BuildFromString(str);

	// filename
	CString filename;
	if(cfgType == CFG_CURRENT_VERSION)
	{
		file.Seek(initPos, CFile::begin);
		ReadHeaderedString(file, str, TITLE_HEADER);
		GetSeparatedString(str, PRI_SEPARATOR, pos, filename);
	}
	return filename;
}

void CDataManager::SaveCfg(CFile& file, BOOL comment)
{
	CString startor(STARTOR);
	CString str0, str1;

	// version
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT version") + EOL);
	str0 = startor + VERSION_HEADER + EOL;
	AppendEscString(str0, VERSION);
	WriteAsMbs(file, str0 + EOL);

	// file size
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT file size") + EOL);
	str0 = startor + FILESIZE_HEADER + EOL;
	AppendEscString(str0, FILESIZE); 
	WriteAsMbs(file, str0 + EOL);

	// subtitle
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT table names") + EOL);
	str0 = startor + SUBTITLE_HEADER + EOL;
	AppendEscString(str0, m_gradeTableName);
	AppendEscString(str0, m_instTableName);
	AppendEscString(str0, m_roomTableName);
	WriteAsMbs(file, str0 + EOL);
	// nSects
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT table�� ǥ�õ� �г� ���� ����.") + EOL);
	str0 = startor + NSECTS_HEADER + EOL;
	str0.AppendFormat(_T("%d%c"), m_nSects, PRI_SEPARATOR);
	WriteAsMbs(file, str0 + EOL);
	// days
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT ������ semicolon���� �и�. ���� ������ ����.") + EOL);
	str0 = startor + DAYS_HEADER + EOL;
	for(int i = 0; i < m_nDays; i++)
		AppendEscString(str0, m_days[i]);
	WriteAsMbs(file, str0 + EOL);
	//grades
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT �г��� semicolon���� �и�. ���� ������ ����.") + EOL);
	str0 = startor + GRADES_HEADER + EOL;
	for(int i = 0; i < m_nGrades; i++)
		AppendEscString(str0, m_grades[i]);
	WriteAsMbs(file, str0 + EOL);
	// prds, times
	str0 = startor + PRDS_HEADER + EOL;
	str1 = startor + TIMES_HEADER + EOL;
	for(int i = 0; i < m_nPrds; i++)
	{
		AppendEscString(str0, m_prds[i]);
		AppendEscString(str1, m_times[i]);
	}
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT PERIODS�� 1���� 2���� ��. TIMES�� ���� ��ġ.") + EOL);
	WriteAsMbs(file, str0 + EOL);
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT TIMES�� �ð�. PERIODS�� ���� ��ġ.") + EOL);
	WriteAsMbs(file, str1 + EOL);
	// table sizes
	if(comment)
	{
		WriteAsMbs(file, startor + _T("COMMENT HML �׸��� �ѱ� ��½� ���. ������ �ѱۿ��� ���Ǵ� hunit = 1/1800��ġ. �Ʒ� ��ġ�� �����Ͽ� ������ ������ ����.") + EOL);
		WriteAsMbs(file, startor + _T("COMMENT Table�� ��, �ణ �پ�� �� �ִ�.") + EOL);
	}
	str0 = startor + TABLEWIDTH_HEADER + EOL;
	str0.AppendFormat(_T("%d%c"),  CHml::Sizes[wdTable], PRI_SEPARATOR);
	WriteAsMbs(file, str0 + EOL);
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT Table�� ����, �ణ �پ�� �� �ִ�.") + EOL);
	str0 = startor + TABLEHEIGHT_HEADER + EOL;
	str0.AppendFormat(_T("%d%c"), CHml::Sizes[htTable], PRI_SEPARATOR);
	WriteAsMbs(file, str0 + EOL);
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT �ð� cell�� ��.") + EOL);
	str0 = startor + TIMEWIDTH_HEADER + EOL;
	str0.AppendFormat(_T("%d%c"), CHml::Sizes[wdTime], PRI_SEPARATOR);
	WriteAsMbs(file, str0 + EOL);
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT period cell �� ��.") + EOL);
	str0 = startor + PRDWIDTH_HEADER + EOL;
	str0.AppendFormat(_T("%d%c"), CHml::Sizes[wdPrd], PRI_SEPARATOR);
	WriteAsMbs(file, str0 + EOL);
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT SECTOR ���� cell�� ����.") + EOL);
	str0 = startor + SECTHEIGHT_HEADER + EOL;
	str0.AppendFormat(_T("%d%c"), CHml::Sizes[htSect], PRI_SEPARATOR);
	WriteAsMbs(file, str0 + EOL);
	if(comment)
		WriteAsMbs(file, startor + _T("COMMENT ���� cell�� ����.") + EOL);
	str0 = startor + DAYHEIGHT_HEADER + EOL;
	str0.AppendFormat(_T("%d%c"), CHml::Sizes[htDay], PRI_SEPARATOR);
	WriteAsMbs(file, str0 + EOL);
}

void CDataManager::SaveAll(CFile& file, BOOL comment)
{
	SaveCfg(file, comment);

	CString startor(STARTOR);

	CString str0 = CDataManager::GetFileName();
	WriteAsMbs(file, startor + FILENAME_HEADER + EOL + Enescape(str0) + PRI_SEPARATOR + EOL);	
	str0 = m_title;
	WriteAsMbs(file, startor + TITLE_HEADER + EOL + Enescape(str0) + PRI_SEPARATOR + EOL);
	CInst::ConvertToString(str0);
	WriteAsMbs(file, startor + INST_HEADER + EOL + str0);
	CTeam::ConvertToString(str0);
	WriteAsMbs(file, startor + TEAM_HEADER + EOL + str0);
	CRoom::ConvertToString(str0);
	WriteAsMbs(file, startor + ROOM_HEADER + EOL + str0);
	CSubj::ConvertToString(str0);
	WriteAsMbs(file, startor + SUBJ_HEADER + EOL + str0);
	CLect::ConvertToString(str0);
	WriteAsMbs(file, startor + LECT_HEADER + EOL + str0);
}

// static

void CDataManager::DeleteBiArray(LPTSTR*& arr, int size)
{
	if(arr != NULL)
	{
		for(int i = 0; i < size; i++)
			free(arr[i]);
		delete[] arr;
		arr = NULL;
	}
}

int CDataManager::FindChar(const CString& str, TCHAR c, int pos)
{
	int pos1 = pos;
	while(TRUE)
	{
		if((pos = str.Find(c, pos)) == -1 || pos == pos1 || str.GetAt(pos-1) != ESCAPE_CHAR)
			return pos;
		pos++;
	}
}

BOOL CDataManager::ReadHeaderedString(CStdioFile& file, CString &str, LPCTSTR header)
{
	CString str1;
	int n = _tcslen(header);
	int pos;
	str.Empty();
	while(TRUE)
	{
		while((pos = FindChar(str, STARTOR)) == -1)
			if(!file.ReadString(str))
				return FALSE;
		str.Delete(0, pos+1);
		while((pos = FindChar(str, STARTOR)) == -1)
		{
			if(!file.ReadString(str1))
			{
				pos = str.GetLength();
				break;
			}
			str += str1;
		}
		if(str.Left(n).CompareNoCase(header) == 0)
		{	
			str = str.Mid(n, pos-n);
			return TRUE;
		}
	}
}

// necessities
//	#include <locale.h>
//	setlocale(LC_ALL, "");
void CDataManager::WriteAsMbs(CFile& file, LPCTSTR wcsStr)
{
	size_t n;
	_wcstombs_s_l(&n, NULL, 0, wcsStr, _TRUNCATE, NULL);
	CStringA mbsStr;
	_wcstombs_s_l(&n, mbsStr.GetBuffer(n-1), n, wcsStr, _TRUNCATE, NULL);
	mbsStr.ReleaseBuffer(--n);
	file.Write(mbsStr, n);
}

void CDataManager::BuildBiArray(const CString& str, TCHAR sep, int& nData, LPTSTR*& data)
{
	vector<CString> vec;
	CString str1;
	int pos = 0;
	while(GetSeparatedString(str, sep, pos, str1))
		vec.push_back(Deescape(str1));
	if(vec.size() > 0)
	{
		DeleteBiArray(data, nData);
		nData = (int) vec.size();
		data = new LPTSTR[nData];
		for(int i = 0; i < nData; i++)
			data[i] = AllocCharBuffer(NULL, vec[i]);
	}
}
BOOL CDataManager::GetSeparatedString(const CString& src, TCHAR sep, int& pos, CString& dst)
{
	int pos1 = pos;
	if((pos = FindChar(src, sep, pos)) == -1)
		return FALSE;
	dst = src.Mid(pos1, pos++-pos1);
	return TRUE;
}
