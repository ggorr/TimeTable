// TeamDialog.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "T.h"

#include "Base.h"
#include "Inst.h"
#include "Team.h"
#include "Subj.h"

#include "TDialog.h"
#include "InstDialog.h"
#include "TeamDialog.h"
#include "SubjDialog.h"

#define WIDTH_NO	45
#define WIDTH_COLOR	40
#define WIDTH_GROUP 40
#define WIDTH_NAME	100
#define WIDTH_MEMB	100
#define WIDTH_NOTE	100
#define WIDTH_LIST	(WIDTH_NO+WIDTH_COLOR+WIDTH_GROUP+WIDTH_NAME+WIDTH_MEMB+WIDTH_NOTE+20)

// CTeamListCtrl

IMPLEMENT_DYNAMIC(CTeamListCtrl, CTListCtrl)

CTeamListCtrl::CTeamListCtrl()
{
	m_vecB = &TheTeams;

	m_nCols = 6;

	m_primaryCol = COL_TEAM_VNAME;

	m_editableCols.push_back(COL_TEAM_VNAME);
	m_editableCols.push_back(COL_TEAM_VNOTE);

	m_funcCols.push_back(COL_TEAM_COLOR);
	m_funcCols.push_back(COL_TEAM_GROUP);
	m_funcCols.push_back(COL_TEAM_INST);

	m_funcs.push_back(&CTListCtrl::PickColor);
	m_funcs.push_back(&CTListCtrl::ChangeGroup);
	m_funcs.push_back(&CTListCtrl::PickInst);
}

CTeamListCtrl::~CTeamListCtrl()
{
}

BEGIN_MESSAGE_MAP(CTeamListCtrl, CTListCtrl)
END_MESSAGE_MAP()

COLORREF CTeamListCtrl::OnGetCellBkColor(int nRow, int nColumn)
{
	if(0 <= nRow && nRow < GetItemCount() && nColumn == COL_TEAM_COLOR)
		return CTeam::Get(nRow)->GetColor();
	else
		return RGB(255,255,255);
}

void CTeamListCtrl::Initialize()
{
	vector<LPCTSTR> labels;
	labels.push_back(_T("��ȣ"));
	labels.push_back(_T("����"));
	labels.push_back(_T("�׷�"));
	labels.push_back(_T("�̸�"));
	labels.push_back(_T("����"));
	labels.push_back(_T("��Ÿ"));

	vector<int> widths;
	widths.push_back(WIDTH_NO);
	widths.push_back(WIDTH_COLOR);
	widths.push_back(WIDTH_GROUP);
	widths.push_back(WIDTH_NAME);
	widths.push_back(WIDTH_MEMB);
	widths.push_back(WIDTH_NOTE);
	
	vector<int> lvcfmt;
	lvcfmt.push_back(LVCFMT_LEFT);
	lvcfmt.push_back(LVCFMT_LEFT);
	lvcfmt.push_back(LVCFMT_CENTER);
	lvcfmt.push_back(LVCFMT_LEFT);
	lvcfmt.push_back(LVCFMT_LEFT);
	lvcfmt.push_back(LVCFMT_LEFT);

	CTListCtrl::Initialize(labels, widths, lvcfmt);
}

void CTeamListCtrl::PostCopyEditToCell()
{
	CTeam* team = CTeam::Get(m_selectedRow);
	if(!team->IsGroup())
		TheInstModelessDlg.GetList()->UpdateRow0(team->GetInst(0)->GetRow());
	if(m_selectedCol == COL_TEAM_VNAME)
	{
		UpdateCol(COL_TEAM_INST);
		m_dlg->GetRefererDlg()->GetList()->UpdateCol(COL_SUBJ_TEAM);
		theApp.ResetTables();
	}
}

void CTeamListCtrl::ExchangeRows(int row0, int row1)
{
	CTListCtrl::ExchangeRows(row0, row1);
	if(CTeam::Get(row0)->IsGroup() || CTeam::Get(row1)->IsGroup())
		return;
	int instRow0 = CTeam::Get(row0)->GetInst(0)->GetRow();
	int instRow1 = CTeam::Get(row1)->GetInst(0)->GetRow();
	TheInstModelessDlg.GetList()->GetVecB()->Exchange(instRow0, instRow1);
	TheInstModelessDlg.GetList()->CTListCtrl::ExchangeRows(instRow0, instRow1);
}

void CTeamListCtrl::PickColor()
{
	CColorDialog dlg(CTeam::Get(m_selectedRow)->GetColor());
	if(dlg.DoModal() == 1)
	{
		// ���� ����
//		CTeam::Get(m_selectedRow)->SetColor(RGB(dlg.m_cc.rgbResult%256, dlg.m_cc.rgbResult/256%256, dlg.m_cc.rgbResult/256/256));
		CTeam::Get(m_selectedRow)->SetColor(dlg.m_cc.rgbResult);
		UpdateCol(COL_TEAM_COLOR);
		SetItemState(m_selectedRow, 0, LVIS_SELECTED | LVIS_FOCUSED);
		m_state = DSTATE_READY;
		theApp.ResetTables();
	}
	else
	{
		SetItemState(m_selectedRow, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
		m_state = DSTATE_SELECTED;
	}
}

void CTeamListCtrl::ChangeGroup()
{
	CTListCtrl* instList = TheInstModelessDlg.GetList();
	CTeam* team = CTeam::Get(m_selectedRow);
	if(team->IsGroup())
	{
		// TheInsts���� insert point�� ã�´�.
		int row = team->GetRow();
		CVecB::iterator iter = TheTeams.begin() + row;
		CInst* inst = NULL;
		do
		{
			iter--;
			if(!((CTeam*) *iter)->IsGroup())
			{
				// team ���� �ִ� row �� ù ��° single(== not group)
				inst = ((CTeam*) *iter)->GetInst(0);
				break;
			}
		}
		while(iter != TheTeams.begin());
		// iter�� TheInsts���� insert �������� �����.
		row = inst == NULL ? 0 : inst->GetRow()+1;
		//------------------------------------------------------------
		// GroupToSingle()���� team�� �����Ѵ�.
		// CInst�� �����Ͽ� TheInsts�� TheTeams�� ���� �ڸ��� ä���.
		//------------------------------------------------------------
		team->GroupToSingle();
		instList->InsertRow(row);
	}
	else
	{
		int row = team->GetInst(0)->GetRow();
		//-------------------------------------------------------------
		// SingleToGroup()���� inst�� ������(TheInsts������) �����Ѵ�.
		// TheTeams�� inst�� ������ �ڸ��� CTeam�� �����Ѵ�.
		//-------------------------------------------------------------
		team->SingleToGroup();
		// inst���� �ش� row�� �����ϰ� ��ȣ�� �ٽ� ���δ�.
		instList->DeleteRow(row);
		UpdateCol(COL_TEAM_INST);
	}
	UpdateRow(team->GetRow());
	SetItemState(m_selectedRow, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
	m_state = DSTATE_SELECTED;
	theApp.ResetTables();
}

void CTeamListCtrl::PickInst()
{
	if(!CTeam::Get(m_selectedRow)->IsGroup())
		return;
	CInstDialog dlg;
	// dlg�� call�ϴ� dialog�� CLectDialog�̴�.
	dlg.SetRefererDlg(m_dlg);
	// ������ CTeamDialog�� modal�̹Ƿ� modeless dialog�� �����ؾ� �Ѵ�.
	dlg.SetMode(MODE_MODAL);
	dlg.SetTitle(_T("���� ���(����) - ����"));
	dlg.SetMaxCheckedRows(99);

	// ��ϵ� ���縦 dialog�� �Ѱܼ� check�ϵ��� �Ѵ�.
	CTeam* team = CTeam::Get(m_selectedRow);
	for(int i = 0; i < team->GetInstSize(); i++)
		dlg.PushBackCheckedRow(team->GetInst(i)->GetRow());

	if(dlg.DoModal() == IDC_SELECT)
	{
		team->EraseAllInsts();
		vector<int> checkedRows = dlg.GetCheckedRows();
		for(vector<int>::iterator i = checkedRows.begin(); i != checkedRows.end(); i++)
			team->AddInst(CInst::Get(*i));
		UpdateRow(m_selectedRow);
	}
	m_state = DSTATE_SELECTED;
	theApp.ResetTables();
}

// CTeamDialog ��ȭ �����Դϴ�.

CTeamDialog TheTeamModelessDlg;

IMPLEMENT_DYNAMIC(CTeamDialog, CTDialog)

CTeamDialog::CTeamDialog(CWnd* pParent /*=NULL*/)
	: CTDialog(CTeamDialog::IDD, pParent)
{
}

CTeamDialog::~CTeamDialog()
{
}

void CTeamDialog::DoDataExchange(CDataExchange* pDX)
{
	CTDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST, theList);
}


BEGIN_MESSAGE_MAP(CTeamDialog, CTDialog)
	ON_BN_CLICKED(IDC_DELETE, &CTeamDialog::OnBnClickedDelete)
END_MESSAGE_MAP()


// CTeamDialog �޽��� ó�����Դϴ�.

BOOL CTeamDialog::OnInitDialog()
{
	CTDialog::OnInitDialog();

	//SetWindowText(_T("���� ��� - ����"));
	m_list = &theList;

	PostInitDialog(WIDTH_LIST);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CTeamDialog::OnBnAdd()
{
	CTDialog ::OnBnAdd();

	TheInstModelessDlg.GetList()->AppendRow0();

	theApp.BuildTables();
	theApp.ResetTables();
}

void CTeamDialog::OnBnClickedDelete()
{
	BOOL* insts = new BOOL[TheInsts.GetSize()];
	ZeroMemory(insts, sizeof(BOOL)*TheInsts.GetSize());
	BOOL* teams = new BOOL[TheTeams.GetSize()];
	ZeroMemory(teams, sizeof(BOOL)*TheTeams.GetSize());
	
	CTeam* team;
	for(int i = 0; i < m_list->GetItemCount(); i++)
	{
		if(m_list->GetCheck(i))
		{
			team = CTeam::Get(i);
			teams[i] = TRUE;
			if(!team->IsGroup() && team->GetInstSize() > 0)
			{
				insts[team->GetInst(0)->GetRow()] = TRUE;
				CTeam::ClearInst(team->GetInst(0));
			}
		}
	}
	// team�� �����ϰ� subj dialog�� update
	DeleteRowsAndUpdateReferer(teams, m_refererDlg, COL_SUBJ_TEAM);
	// inst ����
	// �� ��Ȳ���� modal inst dialog�� ����.
	TheInstModelessDlg.DeleteRows(insts);
	delete[] teams;
	delete[] insts;

	theApp.BuildTables();
	theApp.ResetTables();
}
