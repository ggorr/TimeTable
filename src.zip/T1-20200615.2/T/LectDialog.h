#pragma once

class CLectDialog;
extern CLectDialog TheLectModelessDlg;

// CLectListCtrl
class CLectListCtrl : public CTListCtrl
{
	DECLARE_DYNAMIC(CLectListCtrl)

public:
	CLectListCtrl();
	virtual ~CLectListCtrl();

protected:
	DECLARE_MESSAGE_MAP()
public:
	COLORREF OnGetCellBkColor(int nRow, int nColumn);
	void Initialize();
	void PostCopyEditToCell();
	void ExchangeRows(int row0, int row1);

	void PickRoom();
	void PickSubj();
};

// CLectDialog ��ȭ �����Դϴ�.

class CLectDialog : public CTDialog
{
	DECLARE_DYNAMIC(CLectDialog)

	CLectListCtrl theList;
	CComboBox theComboBox;

public:
	CLectDialog(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CLectDialog();

	// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_BASE };

	inline CTDialog* GetModelessDlg() {return &TheLectModelessDlg;}
	//void OnExit();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedDelete();
};
