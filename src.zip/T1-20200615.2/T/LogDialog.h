#pragma once
#include "afxcmn.h"


// CLogDialog ��ȭ �����Դϴ�.

class CLogDialog : public CDialog
{
	DECLARE_DYNAMIC(CLogDialog)

public:
	CLogDialog(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CLogDialog();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_LOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	CString m_LogPath;
	CListCtrl m_List;
	ULONGLONG* m_Position;
	CString m_Filename;
	int m_Row;

	CString GetFileName();
	ULONGLONG GetFilePosition();
	inline void SetLogPath(LPCTSTR logPath) {m_LogPath = logPath;}
	virtual BOOL OnInitDialog();
	void Resize();

	afx_msg void OnSize(UINT nType, int cx, int cy);
protected:
	virtual void OnOK();
};
