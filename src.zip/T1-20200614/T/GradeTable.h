#pragma once


// CGradeTable ���Դϴ�.

class CGradeTable : public CTTable
{
	DECLARE_DYNCREATE(CGradeTable)

protected:
	CGradeTable();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CGradeTable();

public:
	void Initialize();
	void GetLectString(CLect* lect, CString& str);
	void GetHmlLectString(CString& str, CString& format, CLect* lect);

#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	DECLARE_MESSAGE_MAP()
public:
};


