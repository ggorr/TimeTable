#pragma once

class CRoomDialog;
extern CRoomDialog TheRoomModelessDlg;

class CRoomListCtrl : public CTListCtrl
{
	DECLARE_DYNAMIC(CRoomListCtrl)

public:
	CRoomListCtrl();
	virtual ~CRoomListCtrl();

protected:
	DECLARE_MESSAGE_MAP()
public:
	COLORREF OnGetCellBkColor(int nRow, int nColumn);
	void Initialize();
	void PostCopyEditToCell();
};

// CRoomDialog ��ȭ �����Դϴ�.

class CRoomDialog : public CTDialog
{
	DECLARE_DYNAMIC(CRoomDialog)

	CRoomListCtrl theList;
public:
	CRoomDialog(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CRoomDialog();

	// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_BASE };

	inline CTDialog* GetModelessDlg() {return &TheRoomModelessDlg;}
	void OnBnAdd();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedDelete();
};
