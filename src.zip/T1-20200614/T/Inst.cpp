#include "StdAfx.h"
#include "T.h"
#include "Base.h"
#include "Inst.h"
#include "Team.h"

#include "DataManager.h"

CInst::CInst(LPCTSTR name)
{
	m_name = AllocCharBuffer(NULL, name);
	m_note = NULL;
}

CInst::~CInst(void)
{
	if(m_name != NULL)
		free(m_name);
	if(m_note != NULL)
		free(m_note);
}

// inherited from CBase

int CInst::GetRow()
{
	return TheInsts.GetRow(this);
}

BOOL CInst::GetInString(int col, CString &str)
{
	switch(col)
	{
	case COL_INDEX:
		str.Format(_T("%d"), GetRow());
		break;
	case COL_THIS:
		str.SetString(m_name);
		break;
	case COL_INST_NAME:
		str.SetString(m_name);
		break;
	case COL_INST_NOTE:
		str.SetString(m_note);
		break;
	default:
		return CBase::GetInString(col, str);
	}
	return TRUE;
}

BOOL CInst::SetByString(int col, LPCTSTR str)
{
	switch(col)
	{
	case COL_INST_NAME:
		m_name = AllocCharBuffer(m_name, str);
		break;
	case COL_INST_NOTE:
		m_note = AllocCharBuffer(m_note, str);
		break;
	default:
		return CBase::SetByString(col, str);
	}
	return TRUE;
}


void CInst::ToString(CString& str)
{
	// index
	str.Format(_T("%d%c"), GetRow(), PRI_SEPARATOR);
	// name
	AppendEscString(str, m_name);
	// note
	AppendEscString(str, m_note);
	str += END_OF_LINE;
}

void CInst::FromString(const CString& str, int& pos)
{
	CString str1;
	// index
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	// name
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	m_name = AllocCharBuffer(m_name, Deescape(str1));
	// note
	if(CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		m_note = AllocCharBuffer(m_note, Deescape(str1));
}

// static

int CInst::GetRow(LPCTSTR name)
{
	for(UINT i = 0; i < TheInsts.size(); i++)
		if(((CInst*) TheInsts[i])->HasName(name))
			return (int) i;
	return ROW_NONE;
}

CInst* CInst::Create(LPCTSTR name)
{
	CInst* inst = Get(name);
	if(inst == NULL)
	{
		inst = new CInst(name);
		TheInsts.push_back(inst);
	}
	return inst;
}

CInst* CInst::CreateForDlg()
{
	// CInst�� CTeam�� �����Ͽ� ���� �����ȴ�. 
	return CTeam::CreateForDlg()->GetInst(0);
}

CInst* CInst::Get(LPCTSTR name)
{
	CInst *inst;
	for(CVecB::iterator i=TheInsts.begin(); i!=TheInsts.end(); i++)
	{
		inst = (CInst*) *i;
		if(inst->HasName(name))
			return inst;
	}
	return NULL;
}

