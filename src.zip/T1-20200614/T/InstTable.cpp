// GradeTable.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "T.h"

#include "Base.h"
#include "Inst.h"
#include "Team.h"
#include "Room.h"
#include "Subj.h"
#include "Lect.h"

#include "TTable.h"
#include "InstTable.h"

#include "DataManager.h"

// CInstTable

IMPLEMENT_DYNCREATE(CInstTable, CTTable)

CInstTable::CInstTable()
{
}

CInstTable::~CInstTable()
{
}

BEGIN_MESSAGE_MAP(CInstTable, CTTable)
END_MESSAGE_MAP()

// CInstTable �����Դϴ�.

#ifdef _DEBUG
void CInstTable::AssertValid() const
{
	CTTable::AssertValid();
}

#ifndef _WIN32_WCE
void CInstTable::Dump(CDumpContext& dc) const
{
	CTTable::Dump(dc);
}
#endif
#endif //_DEBUG

void CInstTable::Initialize()
{
	m_name = AllocCharBuffer(m_name, TheDataMgr.GetInstTableName());
	m_sectTitles.clear();
	m_lects.clear();
	for(int i = m_order*TheDataMgr.GetNSects(); i < (m_order+1)*TheDataMgr.GetNSects(); i++)
	{
		if(i < CInst::GetSize())
		{
			CInst* inst = CInst::Get(i);
			m_sectTitles.push_back(inst->GetName());
			vector<CLect*> lects;
			for(int j=0; j<TheLects.GetSize(); j++)
			{
				CLect* lect = CLect::Get(j);
				if(lect->GetSubj() != NULL && lect->GetSubj()->GetTeam() != NULL &&
					lect->GetSubj()->GetTeam()->HasInst(inst) &&
					lect->GetDay() != NONE && lect->GetSPrd() != NONE && lect->GetEPrd() != NONE)
					lects.push_back(lect);
			}
			m_lects.push_back(lects);				
		}
		else
			break;
	}
	m_nValidSects = (int) m_sectTitles.size();
}

void CInstTable::GetLectString(CLect* lect, CString& str)
{
	CString strTemp;
	CSubj* subj = lect->GetSubj();
	subj->GetInString(COL_THIS, str);
	if(subj->GetGrade() == NONE)
	{
		if(lect->GetRoom() != NULL)
		{
			lect->GetInString(COL_LECT_ROOM, strTemp);
			str.AppendFormat(_T("\n()\n%s"), strTemp);
		}
	}
	else
	{
		subj->GetInString(COL_SUBJ_GRADE, strTemp);
		str.AppendFormat(_T("\n(%s)"), strTemp);
		if(lect->GetRoom() != NULL)
		{
			lect->GetRoom()->GetInString(COL_THIS, strTemp);
			str.Append(_T("\n") + strTemp);
		}
	}
}

void CInstTable::GetHmlLectString(CString& str, CString& format, CLect* lect)
{
	CString strTemp;
	CSubj* subj = lect->GetSubj();
	subj->GetInString(COL_THIS, strTemp);
	str.Format(format, 1, strTemp);
	if(subj->GetGrade() == NONE)
	{
		if(lect->GetRoom() != NULL)
		{
			lect->GetInString(COL_LECT_ROOM, strTemp);
			str.AppendFormat(format, 1, _T("()"));
			str.AppendFormat(format, 1, strTemp);
		}
	}
	else
	{
		subj->GetInString(COL_SUBJ_GRADE, strTemp);
		str.AppendFormat(format, 1, _T("(") + strTemp + _T(")"));
		if(lect->GetRoom() != NULL)
		{
			lect->GetRoom()->GetInString(COL_THIS, strTemp);
			str.AppendFormat(format, 1, strTemp);
		}
	}
}