#pragma once

#define HML_LEFTBORDER		1
#define HML_TOPBORDER		2
#define HML_RIGHTBORDER		4
#define HML_BOTTOMBORDER	8

#define wdTable		0
#define wdTime		1
#define wdPrd		2
#define	wdDay		3
#define htTable		4
#define htSect		5
#define htDay		6
#define htPrd		7

class CHml
{
public:
	CHml(void);
	~CHml(void);

	static int Sizes[8];

	static void GetUsedColors(vector<DWORD>& colors);
	static void WriteUTF8ByteOrderMark(CFile& file);
	static void WriteAsUTF8(CFile& file, const CStringW& wcsStr);
	static CString& GetTime(CString& str);
	static CString& GetLang(int n, CString& str);
	static void WriteFirstPageHeader(CFile& file);
	static void ExportAsHml(LPCTSTR pathName);

#ifdef _DEBUG
	// ������ ������ �� ����
	static int ReadAsUTF8(CFile& file, CStringW& wcsStr);
	static void WriteAsChar(CFile& file, const char* str);
	static void WideCharToUTF8(LPCTSTR src, CStringA& dst);
	static void UTF8ToWideChar(LPCSTR src, CStringW& dst);
#endif
};
