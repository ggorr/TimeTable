#pragma once

class CSubj : public CBase
{
	LPTSTR			m_id;		// ���� ��ȣ
	LPTSTR			m_name;		// ���� �̸�
	int				m_grade;	// �г�
	CTeam*			m_team;		// ������
	vector<CLect*>	m_lect;		// ����
	LPTSTR			m_note;		// �޸�

	static int IndexForNew;

	CSubj(LPCTSTR name = NULL);

public:
	~CSubj(void);
	
	// inherited from CBase

	int GetRow();

	BOOL GetInString(int col, CString &str);
	BOOL SetByString(int col, LPCTSTR str);

	int  GetInt(int col);
	void SetInt(int col, int n);

	void ToString(CString& str);
	void FromString(const CString& str, int& pos);	// pos returns next index

	// not inherited
	
	inline LPTSTR GetID() {return m_id;}
	inline void SetID(LPCTSTR id) {m_id = AllocCharBuffer(m_id, id);}
	inline BOOL HasName(const CString& str) {return m_name != NULL && str.Compare(m_name) == 0;}

	inline LPTSTR GetName() {return m_name;}
	inline void SetName(LPCTSTR name) {m_name = AllocCharBuffer(m_name, name);}

	inline LPTSTR GetNote() {return m_note;}
	inline void SetNote(LPCTSTR note) {m_name = AllocCharBuffer(m_note, note);}

	inline int& GetGrade() {return m_grade;}
	inline void SetGrade(int grade) {m_grade = grade;}

	int GetNPrds();

	inline BOOL HasTeam(const CTeam* team) {return m_team == team;}
	BOOL HasTeam(LPCTSTR name);
	inline CTeam* GetTeam() {return m_team;}
	inline void SetTeam(CTeam* team) {m_team = team;}
	inline void EraseTeam() {m_team = NULL;}

	BOOL HasLect(CLect* lect);
	inline int GetLectSize() {return m_lect.size();}
	int GetLectIndex(CLect* lect);
	inline CLect* GetLect(int index) {return m_lect[index];}
	void AddLect(CLect* lect) {if(lect != NULL && !HasLect(lect)) m_lect.push_back(lect);}
	void EraseLect(CLect* lect);
	void EraseLect(int index) {m_lect.erase(m_lect.begin()+index);}
	inline void EraseAllLects() {m_lect.clear();}

	// lect�� �����Ѵ�. lect->m_subj == this, this->m_lect = subj;
	void CaptureLect(CLect* lect);
	// lect�� ���踦 û���Ѵ�.
	void ReleaseLect(CLect* lect);

	// static
	inline static int GetSize() {return (int) TheSubjs.size();}

	static int GetRow(LPCTSTR name);

	static CSubj* Create(LPCTSTR = NULL);
	static CSubj* CreateForDlg();

	inline static CSubj* Get(int row) {return (CSubj*) TheSubjs[row];}
	static CSubj* Get(LPCTSTR name);

	inline static void Exchange(int row0, int row1) {TheSubjs.Exchange(row0, row1);}

	inline static void Delete(int row) {TheSubjs.Delete(row);}
	inline static void Delete(CSubj* subj) {TheSubjs.Delete(subj);}

	inline static void Clear() {TheSubjs.Clear();}

	inline static BOOL GetInString(int row, int col, CString &str) {return Get(row)->GetInString(col, str);}
	inline static BOOL SetByString(int row, int col, LPCTSTR  str) {return Get(row)->SetByString(col, str);}

	inline static int  GetInt(int row, int col) {return Get(row)->GetInt(col);}
	inline static void SetInt(int row, int col, int n) {Get(row)->SetInt(col, n);}

	static void ClearTeam(CTeam* team);
	static void ClearLect(CLect* lect);
	inline static void ClearSubbase(int col, CBase* base);

	inline static void ConvertToString(CString& str) {TheSubjs.ConvertToString(str);}
	inline static void BuildFromString(const CString& str) {TheSubjs.BuildFromString(str);}

	static void DetermineIndexForNew();
};

inline void CSubj::ClearSubbase(int col, CBase* base)
{
	if(col == COL_SUBJ_TEAM)
		ClearTeam((CTeam*) base);
	else if(col == COL_SUBJ_LECT)
		ClearLect((CLect*) base);
}