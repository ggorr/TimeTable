#include "StdAfx.h"
#include "T.h"
#include "Base.h"
#include "Inst.h"
#include "Team.h"

#include "DataManager.h"

#define NEW_NAME_FORMAT	_T("�� ���� %d")
#define DEFAULT_COLOR RGB(192,192,192)

int CTeam::IndexForNew = 0;

CTeam::CTeam(LPCTSTR name)
{
	m_name = AllocCharBuffer(NULL, name);
	m_note = NULL;
	m_color = DEFAULT_COLOR;
	m_group = FALSE;
}

CTeam::~CTeam(void)
{
	if(m_name != NULL)
		free(m_name);
	if(m_note != NULL)
		free(m_note);
}

// inherited from CBase

int CTeam::GetRow()
{
	return TheTeams.GetRow(this);
}

BOOL CTeam::GetInString(int col, CString &str)
{
	switch(col)
	{
	case COL_INDEX:
		str.Format(_T("%d"), GetRow());
		break;
	case COL_THIS:
	case COL_TEAM_VNAME:
		str.SetString(GetVName());
		break;
	case COL_TEAM_COLOR:
		str.Empty();
		break;
	case COL_TEAM_GROUP:
		str.SetString(m_group ? _T("O") : _T("X"));
		break;
	case COL_TEAM_INST:
		if(m_group && m_inst.size() > 0)
		{
			vector<CInst*>::iterator i = m_inst.begin();
			(*i)->GetInString(COL_THIS, str);
			CString temp;
			for(i++; i != m_inst.end(); i++)
			{
				str.Append(_T(", "));
				(*i)->GetInString(COL_THIS, temp);
				str.Append(temp);
			}
		}
		else
			str.Empty();
		break;
	case COL_TEAM_VNOTE:
		str.SetString(GetVNote());
		break;
	case COL_TEAM_NAME:
		str.SetString(m_name);
		break;
	case COL_TEAM_NOTE:
		str.SetString(m_note);
		break;
	default:
		return CBase::GetInString(col, str);
	}
	return TRUE;
}

BOOL CTeam::SetByString(int col, LPCTSTR str)
{
	switch(col)
	{
	case COL_TEAM_VNAME:
		SetVName(str);
		break;
	case COL_TEAM_VNOTE:
		SetVNote(str);
		break;
	case COL_TEAM_NAME:
		m_name = AllocCharBuffer(m_name, str);
		break;
	case COL_TEAM_NOTE:
		m_note = AllocCharBuffer(m_note, str);
		break;
	case COL_TEAM_GROUP:
		m_group = _tcscmp(str, _T("O")) == 0;
		break;
	default:
		return CBase::SetByString(col, str);
	}
	return TRUE;
}

void CTeam::ToString(CString& str)
{
	// index, color, group
	str.Format(_T("%d%c%d%c%d%c"), GetRow(), PRI_SEPARATOR, m_color, PRI_SEPARATOR, m_group, PRI_SEPARATOR);
	AppendEscString(str, m_name);
	for(int i = 0; i < GetInstSize(); i++)
		str.AppendFormat(_T("%d%c"), m_inst[i]->GetRow(), SEC_SEPARATOR);
	str += PRI_SEPARATOR;
	AppendEscString(str, m_note);
	str += END_OF_LINE;
}

void CTeam::FromString(const CString& str, int& pos)
{
	CString str1;
	// index
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	// color
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	if(_stscanf_s(str1, _T("%d"), &m_color) == -1)
		m_color = DEFAULT_COLOR;
	// group
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	m_group = str1.Compare(_T("1")) == 0;
	// name
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	m_name = AllocCharBuffer(m_name, Deescape(str1));
	// inst
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	int pos1 = 0;
	while(true)
	{
		CString str2;
		if(!CDataManager::GetSeparatedString(str1, SEC_SEPARATOR, pos1, str2))
			break;
		int row;
		if(_stscanf_s(str2, _T("%d"), &row) != -1 && 0 <= row && row < CInst::GetSize())
			m_inst.push_back(CInst::Get(row));
	}
	// note
	if(CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		m_note = AllocCharBuffer(m_note, Deescape(str1));
}

// not inherited

void CTeam::GroupToSingle()
{
	ASSERT(m_group);

	// TheInsts���� insert point�� ã�´�.
	int row = GetRow();
	CVecB::iterator iter = TheTeams.begin() + row;
	CInst* inst = NULL;
	do
	{
		iter--;
		if(!((CTeam*) *iter)->IsGroup())
		{
			inst = ((CTeam*) *iter)->m_inst[0];
			break;
		}
	}
	while(iter != TheTeams.begin());
	// iter�� TheInsts���� insert �������� �����.
	if(inst == NULL)
		iter = TheInsts.begin();
	else
		iter = TheInsts.begin() + (inst->GetRow() + 1);
	// m_name���� CInst�� ����� TheInsts�� �����Ѵ�.
	if(iter == TheInsts.end())
		inst = CInst::Create(m_name);
	else
	{
		inst = CInst::Create(m_name);
		TheInsts.insert(iter, inst);
		TheInsts.pop_back();
	}
	// team�� ��� ������ �����Ѵ�.
	m_inst.clear();
	m_inst.push_back(inst);
	free(m_name);	// NULL�� �ƴ�!!
	m_name = NULL;
	if(m_note != NULL)
	{
		inst->SetNote(m_note);
		free(m_note);
		m_note = NULL;
	}
	m_group = FALSE;
}

void CTeam::SingleToGroup()
{
	ASSERT(!m_group);

	// m_inst[0]->m_name���� ���ο� �׷��� ����� m_inst[0]�� TheInsts���� �����Ѵ�.
	m_group = TRUE;
	CInst* inst = m_inst[0];
	m_name = AllocCharBuffer(m_name, inst->GetName());
	m_note = AllocCharBuffer(m_note, inst->GetNote());
	ClearInst(inst);
	CInst::Delete(inst);
}

BOOL CTeam::HasInst(const CInst* inst)
{
	for(vector<CInst*>::iterator i = m_inst.begin(); i != m_inst.end(); i++)
		if(inst == *i)
			return TRUE;
	return FALSE;
}

int CTeam::GetInstIndex(CInst* inst)
{
	for(UINT i=0; i<m_inst.size(); i++)
		if(inst == m_inst[i])
			return (int) i;
	return NONE;
}
/*
int CTeam::GetInstIndex(LPCTSTR name)
{
	for(UINT i=0; i<m_inst.size(); i++)
		if(m_inst[i]->HasName(name))
			return (int) i;
	return NONE;
}
*/
CInst* CTeam::GetInst(int index)
{
	if(0 <= index && index < (int) m_inst.size())
		return m_inst[index];
	else
		return NULL;
}

CInst* CTeam::GetInst(LPCTSTR name)
{
	for(vector<CInst*>::iterator i = m_inst.begin(); i != m_inst.end(); i++)
		if((*i)->HasName(name))
			return *i;
	return NULL;
}

void CTeam::EraseInst(CInst* inst)
{
	for(vector<CInst*>::iterator i = m_inst.begin(); i != m_inst.end(); i++)
		if(inst == *i)
		{
			m_inst.erase(i);
			return;
		}
}

void CTeam::EraseInst(int index)
{
	ASSERT(0 <= index || index < GetInstSize());
	m_inst.erase(m_inst.begin()+index);
}

BOOL CTeam::IsOverlappedWith(CTeam* team)
{
	for(vector<CInst*>::iterator i = m_inst.begin(); i != m_inst.end(); i++)
		for(vector<CInst*>::iterator j = team->m_inst.begin(); j != team->m_inst.end(); j++)
			if(*i == *j) return TRUE;
	return FALSE;
}

// static

int CTeam::GetRow(LPCTSTR name)
{
	for(UINT i = 0; i < TheTeams.size(); i++)
		if(((CTeam*) TheTeams[i])->HasName(name))
			return (int) i;
	return ROW_NONE;
}

CTeam* CTeam::Create(LPCTSTR name)
{
	CTeam* team = Get(name);
	if(team == NULL)
	{
		team = new CTeam(name);
		TheTeams.push_back(team);
	}
	return team;
}

CTeam* CTeam::CreateWithInst(LPCTSTR name)
{
	CTeam* team = new CTeam();
	team->m_inst.push_back(CInst::Create(name));
	TheTeams.push_back(team);
	return team;
}

CTeam* CTeam::CreateForDlg()
{
	CString str;
	str.Format(NEW_NAME_FORMAT, IndexForNew);
	IndexForNew++;
	return CreateWithInst(str);
}

CTeam* CTeam::Get(LPCTSTR name)
{
	CTeam *team;
	for(CVecB::iterator i=TheTeams.begin(); i!=TheTeams.end(); i++)
	{
		team = (CTeam*) *i;
		if(team->HasName(name))
			return team;
	}
	return NULL;
}

void CTeam::ClearInst(CInst* inst)
{
	for(CVecB::iterator i = TheTeams.begin(); i != TheTeams.end(); i++)
		if(((CTeam*) *i)->IsGroup())
			((CTeam*) *i)->EraseInst(inst);
}

void CTeam::DetermineIndexForNew()
{
	CString str0(NEW_NAME_FORMAT);
	int pos = str0.Find(_T("%d"));
	str0.Truncate(pos);
	CString str1;
	int index;
	IndexForNew = 0;
	for(int i = 0; i < GetSize(); i++)
	{
		GetInString(i, COL_TEAM_VNAME, str1);
		if(str0.Compare(str1.Left(pos)) == 0)
		{
			_stscanf_s(str1.Mid(pos), _T("%d"), &index);
			if(index >= IndexForNew)
				IndexForNew = index + 1;
		}
	}
}