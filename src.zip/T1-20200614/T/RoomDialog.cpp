// RoomDialog.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "T.h"

#include "Base.h"
#include "Lect.h"
#include "Room.h"

#include "TDialog.h"
#include "RoomDialog.h"
#include "LectDialog.h"

#define WIDTH_NO	45
#define WIDTH_NAME	100
#define WIDTH_NOTE	200
#define WIDTH_LIST	(WIDTH_NO+WIDTH_NAME+WIDTH_NOTE+20)

// CRoomListCtrl

IMPLEMENT_DYNAMIC(CRoomListCtrl, CTListCtrl)

CRoomListCtrl::CRoomListCtrl()
{
	m_vecB = &TheRooms;

	m_nCols = 3;

	m_primaryCol = COL_ROOM_NAME;

	m_editableCols.push_back(COL_ROOM_NAME);
	m_editableCols.push_back(COL_ROOM_NOTE);
}

CRoomListCtrl::~CRoomListCtrl()
{
}

BEGIN_MESSAGE_MAP(CRoomListCtrl, CTListCtrl)
END_MESSAGE_MAP()

COLORREF CRoomListCtrl::OnGetCellBkColor(int nRow, int nColumn)
{
	return RGB(255,255,255);
}

void CRoomListCtrl::Initialize()
{
	vector<LPCTSTR> labels;
	labels.push_back(_T("��ȣ"));
	labels.push_back(_T("�̸�"));
	labels.push_back(_T("��Ÿ"));

	vector<int> widths;
	widths.push_back(WIDTH_NO);
	widths.push_back(WIDTH_NAME);
	widths.push_back(WIDTH_NOTE);
	
	CTListCtrl::Initialize(labels, widths);
}

void CRoomListCtrl::PostCopyEditToCell()
{
	if(m_selectedCol == COL_ROOM_NAME)
	{
		m_dlg->GetRefererDlg()->GetList()->UpdateCol(COL_LECT_ROOM);
		theApp.ResetTables();
	}
}

// CRoomDialog ��ȭ �����Դϴ�.
CRoomDialog TheRoomModelessDlg;

IMPLEMENT_DYNAMIC(CRoomDialog, CTDialog)

CRoomDialog::CRoomDialog(CWnd* pParent /*=NULL*/)
	: CTDialog(CRoomDialog::IDD, pParent)
{
}

CRoomDialog::~CRoomDialog()
{
}

void CRoomDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST, theList);
}


BEGIN_MESSAGE_MAP(CRoomDialog, CTDialog)
	ON_BN_CLICKED(IDC_DELETE, &CRoomDialog::OnBnClickedDelete)
END_MESSAGE_MAP()


// CRoomDialog �޽��� ó�����Դϴ�.

BOOL CRoomDialog::OnInitDialog()
{
	CTDialog::OnInitDialog();

	//SetWindowText(_T("���ǽ� ���"));

	m_list = &theList;

	PostInitDialog(WIDTH_LIST);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CRoomDialog::OnBnAdd()
{
	CTDialog ::OnBnAdd();

	theApp.BuildTables();
	theApp.ResetTables();
}

void CRoomDialog::OnBnClickedDelete()
{
	DeleteCheckedRowsAndUpdateReferer(m_refererDlg, COL_LECT_ROOM);
	theApp.BuildTables();
	theApp.ResetTables();
}