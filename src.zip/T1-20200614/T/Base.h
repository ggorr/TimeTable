#pragma once

#include <vector>

using namespace std;

class CBase
{
protected:
	CBase() {}
public:
	virtual ~CBase(){}
	virtual int GetRow() = NULL;

	virtual BOOL GetInString(int col, CString &str) {return FALSE;}
	virtual BOOL SetByString(int col, LPCTSTR  str) {return FALSE;}

	virtual int  GetInt(int col) {return NONE;}
	virtual void SetInt(int col, int n) {}

	virtual void ToString(CString& str) = NULL;
	virtual void FromString(const CString& str, int& pos) = NULL;
};

class CVecB : public vector<CBase*>
{
private:
	// �� VecB�� type
	// TYPE_INST, TYPE_TEAM, TYPE_ROOM, TYPE_SUBJ, TYPE_LECT �� �ϳ��̴�.
	int m_type;

	//int m_nCols;
public:
	CVecB(int type);
	~CVecB();

	inline int& GetType() {return m_type;}
	inline BOOL IsType(int type) {return m_type == type;}

	inline int GetSize() {return (int) size();}
	
	int GetRow(const CBase* base);
	BOOL Contains(const CBase* base);

	inline CBase* Get(int row) {return *(begin()+row);}

	inline BOOL GetInString(int row, int col, CString &str) {return Get(row)->GetInString(col, str);}
	inline BOOL SetByString(int row, int col, LPCTSTR  str)	{return Get(row)->SetByString(col, str);}

	inline int  GetInt(int row, int col) {return Get(row)->GetInt(col);}
	inline void SetInt(int row, int col, int n) {Get(row)->SetInt(col, n);}

	void Exchange(int row0, int row1);

	CBase* CreateBase();
	// Dialog���� ���� ���� "���ο� �̸�"�� �����Ѵ�.
	// ���ο� CTeam�� �����ϸ� CInst�� �ڵ����� �����ȴ�.
	CBase* CreateBaseForDlg();

	// Delete means erase base from vector and delete it
	void Delete(CBase* base);
	void Delete(int row);

	void Clear();

	// subbase�� Base Ŭ������ ����� Base�� ���Ѵ�.
	// CTeam�� m_inst�� ��ϵ� CInst�� instance, CSubj�� m_team�� ��ϵ� CTeam�� instance ��
	void ClearSubbase(int col, CBase* base);

	void ConvertToString(CString& str);
	void BuildFromString(const CString& str);
};

extern CVecB TheRooms;
extern CVecB TheInsts;
extern CVecB TheTeams;
extern CVecB TheLects;
extern CVecB TheSubjs;
