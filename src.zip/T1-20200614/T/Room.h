#pragma once

class CRoom : public CBase
{
private:
	LPTSTR	m_name;
	LPTSTR	m_note;

	static int IndexForNew;

	CRoom(LPCTSTR name = NULL);
public:
	~CRoom(void);

	// inherited from CBase

	int GetRow();

	BOOL GetInString(int col, CString &str);
	BOOL SetByString(int col, LPCTSTR  str);

	void ToString(CString& str);
	void FromString(const CString& str, int& pos);

	// not inherited

	inline BOOL HasName(const CString& str) {return m_name != NULL && str.Compare(m_name) ==0;}
	inline LPTSTR GetName() {return m_name;}
	inline void SetName(LPCTSTR name) {m_name = AllocCharBuffer(m_name, name);}

	inline LPTSTR GetNote() {return m_note;}
	inline void SetNote(LPCTSTR note) {m_note = AllocCharBuffer(m_note, note);}

	// static
	inline static int GetSize() {return (int) TheRooms.size();}

	static int GetRow(LPCTSTR name);

	static CRoom* Create(LPCTSTR name = NULL);
	static CRoom* CreateForDlg();
	
	inline static CRoom* Get(int row) {return (CRoom*) TheRooms[row];}
	static CRoom* Get(LPCTSTR name);

	inline static void Exchange(int row0, int row1) {TheRooms.Exchange(row0, row1);}

	inline static void Delete(int row) {TheRooms.Delete(row);}
	inline static void Delete(CRoom* room) {TheRooms.Delete(room);}

	inline static void Clear() {TheRooms.Clear();}

	inline static BOOL GetInString(int row, int col, CString &str) {return Get(row)->GetInString(col, str);}
	inline static BOOL SetByString(int row, int col, LPCTSTR  str) {return Get(row)->SetByString(col, str);}

	inline static void ConvertToString(CString& str) {TheRooms.ConvertToString(str);}
	inline static void BuildFromString(const CString& str) {TheRooms.BuildFromString(str);}

	static void DetermineIndexForNew();
};
