#pragma once

// CTListCtrl

#define DSTATE_READY		0
#define DSTATE_SELECTED	1
#define	DSTATE_EDITING	2
#define DSTATE_COMBOBOX	3
#define DSTATE_FUNCTION		4	// ó���ϴ� ���� ����
#define DSTATE_DRAGGING	5

#define MODE_MODELESS	0
#define MODE_MODAL		1

class CTListCtrl;
class CTDialog;

typedef void (CTListCtrl::*TFunc)();

class CTListCtrl : public CMFCListCtrl
{
	DECLARE_DYNAMIC(CTListCtrl)

public:
	CTListCtrl();
	virtual ~CTListCtrl();

protected:
	DECLARE_MESSAGE_MAP()

	CVecB* m_vecB;
	// number of columns
	int m_nCols;
	// ���ο� row�� ������ �� ���� ���� �Է��ϴ� column
	int m_primaryCol;

	vector<int> m_editableCols;
	vector<int> m_comboBoxCols;

	// functions ���� �� ������ ������ ��ġ�ؾ� �Ѵ�.
	vector<int> m_funcCols;
	vector<TFunc> m_funcs;

	// list�� owner
	CTDialog *m_dlg;
	CEdit *m_edit;
	CComboBox *m_comboBox;

	int m_state;		// ���� ����
	int m_selectedRow;	// ������ row
	int m_selectedCol;	// ������ col

public:
	inline CVecB* GetVecB() {return m_vecB;}
	inline void SetOwnerDlg(CTDialog* dlg) {m_dlg = dlg;}
	inline void SetEdit(CEdit* edit) {m_edit = edit;}
	inline void SetComboBox(CComboBox* comboBox) {m_comboBox = comboBox;}
	inline int GetSelectedRow() {return m_selectedRow;}
	inline int SetSelectedRow(int selectedRow) {return m_selectedRow = selectedRow;}

	virtual void Initialize() = NULL;
	void Initialize(vector<LPCTSTR> labels, vector<int> widths, vector<int> lvcfmt = vector<int>());
	// �������� �� row�� �����Ѵ�.
	inline void AppendRow0() {InsertRow0(ROW_NONE);}
	inline void AppendRow() {InsertRow(ROW_NONE);}
	// �� row�� �����Ѵ�.
	void InsertRow0(int row);
	void InsertRow(int row);
	// �� row�� �����Ѵ�.
	void DeleteRow0(int row);
	void DeleteRow(int row);
	void UpdateRow0(int row);
	void UpdateRow(int row);
	void UpdateCol0(int col);
	void UpdateCol(int col);
	void UpdateAllRows0();
	void ExchangeRows0(int row0, int row1);
	virtual void ExchangeRows(int row0, int row1);

	virtual void PostCopyEditToCell() = NULL;
	virtual BOOL CopyEditToCell();
	virtual void CopyComboBoxToCell();
	virtual void PostCopyComboBoxToCell() {}
	void ActivateEdit();
	void ActivateComboBox();

	BOOL OnLButtonDown(CPoint p);
	BOOL OnLButtonUp();
	BOOL OnMouseMove(CPoint p);
	BOOL OnKeyDown(WPARAM key);

	virtual void PickColor() {}
	virtual void ChangeGroup() {}
	virtual void PickTeam() {}
	virtual void PickSubj() {}
	virtual void PickRoom() {}
	virtual void PickInst() {}

	afx_msg void OnNMClick(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnBeginDrag(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnColumnclick(NMHDR *pNMHDR, LRESULT *pResult);
};

// CTDialog ��ȭ �����Դϴ�.

class CTDialog : public CDialog
{
	DECLARE_DYNAMIC(CTDialog)

	CEdit theEdit;
public:
	CTDialog(UINT nID, CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CTDialog();

// ��ȭ ���� �������Դϴ�.
//	enum { IDD = IDD_TDIALOG };
protected:
	int m_mode;
	CTListCtrl *m_list;
	int m_maxCheckedRows;
	vector<int> m_checkedRows;
	CString m_title;
	// �� dialog�� ȣ�� �Ǵ� �ο��ϴ� dialog
	CTDialog* m_refererDlg;

public:
	inline BOOL IsModal() {return m_mode == MODE_MODAL;}
	inline void SetMode(int mode) {m_mode = mode;}
	inline void SetTitle(LPCTSTR title) {m_title = title;}
	inline CTListCtrl* GetList() {return m_list;}
	inline void SetList(CTListCtrl* list) {m_list = list;}
	inline void SetMaxCheckedRows(int maxCheckedRows) {m_maxCheckedRows = maxCheckedRows;}
	//inline int GetMaxCheckedRows() {return m_maxCheckedRows;}
	inline vector<int>& GetCheckedRows() {return m_checkedRows;}
	inline void PushBackCheckedRow(int row) {m_checkedRows.push_back(row);}
	inline void SetRefererDlg(CTDialog* refererDlg) {m_refererDlg = refererDlg;}
	inline CTDialog* GetRefererDlg() {return m_refererDlg;}

	// the modeless dialog of this dialog, CXxxx::ModelessDlg
	// this if modeless
	virtual CTDialog* GetModelessDlg() {return NULL;}
	void PostInitDialog(int listWidth);
	// default add row
	virtual void OnBnAdd();
	// lect dialog
	virtual void OnExit() {}

	// base�� �����.
	// modal dlg, modeless dlg ��� ����
	void DeleteRows(BOOL* rows);
	// checked rows�� �׿� �����Ǵ� base�� �����.
	// modal dlg, modeless dlg ��� ����
	void DeleteCheckedRows();
	// vecB, modal dlg, modeless dlg���� base�� �����. �� referer�� update�Ѵ�.
	void DeleteRowsAndUpdateReferer(BOOL* rows, CTDialog* refererDlg, int colInReferer);
	// default delete row
	void DeleteCheckedRowsAndUpdateReferer(CTDialog* refererDlg, int colInReferer);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBnClickedAdd();
	afx_msg void OnBnClickedSelect();
	afx_msg void OnBnClickedExit();
	afx_msg void OnDestroy();
};
