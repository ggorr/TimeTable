#pragma once

class CSubjDialog;
extern CSubjDialog TheSubjModelessDlg;

class CSubjListCtrl : public CTListCtrl
{
	DECLARE_DYNAMIC(CSubjListCtrl)

public:
	CSubjListCtrl();
	virtual ~CSubjListCtrl();

protected:
	DECLARE_MESSAGE_MAP()

public:
	COLORREF OnGetCellBkColor(int nRow, int nColumn);
	void Initialize();
	void PostCopyEditToCell();
	void PostCopyComboBoxToCell();
	
	void PickTeam();
	void PickLect();
};




// CSubjDialog ��ȭ �����Դϴ�.

class CSubjDialog : public CTDialog
{
	DECLARE_DYNAMIC(CSubjDialog)

	CSubjListCtrl theList;
	CComboBox theComboBox;
public:
	CSubjDialog(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSubjDialog();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_BASE };

	inline CTDialog* GetModelessDlg() {return &TheSubjModelessDlg;}

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedDelete();
};
