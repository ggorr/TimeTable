// TTable.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "T.h"
#include "TTable.h"
#include "DataManager.h"

#include "Base.h"
#include "Inst.h"
#include "Team.h"
#include "Room.h"
#include "Subj.h"
#include "Lect.h"

#include "TDialog.h"
#include "SubjDialog.h"
#include "LectDialog.h"

#include "Hml.h"

#define FONTSIZE_TITLE		16
#define MAX_LECT_FONTSIZE	10

//#define OVERLAP_COLOR	RGB(63,63,63)
#define OVERLAP_COLOR	RGB(225,225,225)
#define DEFAULT_COLOR	RGB(255,255,255)
//#define DEFAULT_COLOR	RGB(200,200,200)

#define NSects	TheDataMgr.GetNSects()
#define NDays	TheDataMgr.GetNDays()
#define NPrds	TheDataMgr.GetNPrds()

// CTTable

IMPLEMENT_DYNCREATE(CTTable, CView)

CTTable::CTTable()
{
	m_name = NULL;
	m_nValidSects = 0;
}

CTTable::~CTTable()
{
	if(m_name != NULL)
		free(m_name);
}

BEGIN_MESSAGE_MAP(CTTable, CView)
	ON_WM_SETCURSOR()
	ON_WM_ERASEBKGND()
	ON_WM_KILLFOCUS()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDBLCLK()
//	ON_WM_SIZE()
END_MESSAGE_MAP()


// CTTable �׸����Դϴ�.

void CTTable::OnDraw(CDC* pDC)
{

	CMemDC memDC(*pDC, this);
	CDC& dc = memDC.GetDC();

	RECT rect;
	GetClientRect(&rect);
	if(BkDC == NULL)
	{
	    dc.FillSolidRect(&rect, RGB(255,255,255));
		DrawOutline(dc);
		DisplayAllLects(dc);
	}
	else
	{
		dc.BitBlt(0, 0, rect.right, rect.bottom, BkDC, 0, 0, SRCCOPY);
		DrawColoredRects(dc);
	}
	if(CurrLect != NULL) DisplayCurrLect(dc);
}


// CTTable �����Դϴ�.

#ifdef _DEBUG
void CTTable::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CTTable::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG

COLORREF CTTable::DefaultColor = DEFAULT_COLOR;
COLORREF CTTable::OverlapColor = OVERLAP_COLOR;

int CTTable::CursorType = CURSOR_NORMAL;
HCURSOR CTTable::CursorSizeNS = NULL;
int CTTable::State = TSTATE_READY;

CDC* CTTable::BkDC = NULL;

int CTTable::Left;		// ǥ�� ���� x ��ǥ
int CTTable::Right;		// ǥ�� ������ x ��ǥ
int CTTable::Top;		// ǥ�� ���� y ��ǥ
int CTTable::Bottom;	// ǥ�� �Ʒ��� y ��ǥ

int* CTTable::SectX = NULL;
int  CTTable::SectY;

int** CTTable::CoordX = NULL;
int*  CTTable::CoordY = NULL;

int		CTTable::CurrSect = NONE;
vector<int> CTTable::CurrLectSects;
CLect*	CTTable::CurrLect = NULL;
CPoint	CTTable::CurrPoint;		// previous point
CRect	CTTable::CurrRect;		// current dragging rect
CString	CTTable::CurrText;		// current dragging 

int CTTable::Len[hvNo];

void CTTable::BuildBkDC()
{
	CDC* pDC = GetDC();
	BkDC = new CDC;
	BkDC->CreateCompatibleDC(pDC);
	CRect rect;
	GetClientRect(&rect);
	CBitmap bitmap;
	bitmap.CreateCompatibleBitmap(pDC, rect.right-rect.left, rect.bottom-rect.top);
	BkDC->SelectObject(&bitmap)->DeleteObject();
    BkDC->FillSolidRect(&rect, RGB(255,255,255));
	DrawOutline(*BkDC);
	DisplayAllLectsText(*BkDC);
	ReleaseDC(pDC);
}

void CTTable::DrawOutline(CDC& dc)
{
	// sect�� ���Ϻ� ���μ�
	for(int i=0; i<NSects; i++)
	{
		for(int j=0; j<NDays; j++)
		{
			dc.MoveTo(CoordX[i][j]-1, SectY+1);
			dc.LineTo(CoordX[i][j]-1, Bottom+1);
		}
	}

	// �ð� �� ���μ�
	for(int i=1; i<=NPrds; i++)
	{
		dc.MoveTo(Left,  CoordY[i]-1);
		dc.LineTo(Right+1, CoordY[i]-1);
	}

	// sect name�� ������ ������ ���� ��
	dc.MoveTo(SectX[0], SectY+1);
	dc.LineTo(Right+1,	SectY+1);
	
	// ����
	dc.MoveTo(Left, Top);
	dc.LineTo(SectX[0]-2, CoordY[0]-2);

	CPen pen(PS_SOLID, 2, RGB(0,0,0));
	CPen* pOldPen = dc.SelectObject(&pen);
	
	// ���� �ٱ� ��
	dc.MoveTo(Left-2,  Top-1);
	dc.LineTo(Right+2, Top-1);
	dc.LineTo(Right+2, Bottom+2);
	dc.LineTo(Left-1,  Bottom+2);
	dc.LineTo(Left-1,  Top-2);

	// ���� sect ���� ���� ��
	for(int i=0; i<NSects; i++)
	{
		dc.MoveTo(SectX[i]-1, Top);
		dc.LineTo(SectX[i]-1, Bottom);
	}

	// ���� ���� ���� ���μ�
	dc.MoveTo(Left,	 CoordY[0]-1);
	dc.LineTo(Right, CoordY[0]-1);

	dc.SelectObject(pOldPen);
	
	// 1, 2, ... ���� text
	RECT rect;
	for(int i=0; i<NSects; i++)
	{
		rect.left  = SectX[i];
		rect.right = CoordX[i][0]-2;
		for(int j=0; j<NPrds; j++)
		{
			rect.top    = CoordY[j];
			rect.bottom = CoordY[j+1]-2;
			dc.DrawText(TheDataMgr.GetPrd(j), &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
		}
	}

	// ��ȭ�����
	rect.top    = SectY + 2;
	rect.bottom = CoordY[0] - 3;
	for(int i=0; i<NSects; i++)
		for(int j=0; j<NDays; j++)
		{
			rect.left  = CoordX[i][j];
			rect.right = CoordX[i][j+1]-2;
			dc.DrawText(TheDataMgr.GetDay(j), &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
		}

	// �ð�
	rect.left  = Left;
	rect.right = SectX[0]-2;
	for(int i=0; i<NPrds; i++)
	{
		rect.top    = CoordY[i];
		rect.bottom = CoordY[i+1]-2;
		dc.DrawText(TheDataMgr.GetTime(i), &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}

	// sect title
	rect.top    = Top;
	rect.bottom = SectY;
	for(UINT i=0; i<m_lects.size(); i++)
	{
		rect.left = SectX[i];
		rect.right = CoordX[i][NDays]-2;
		dc.DrawText(m_sectTitles[i], &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}
	
	// Ÿ��Ʋ
	CFont font;
	font.CreatePointFont(FONTSIZE_TITLE*10, _T("����"));
	CFont* prevFont = dc.SelectObject(&font);
	rect.left   = Left;
	rect.top    = Len[vtTop];
	rect.right  = Right;
	rect.bottom = Top - 3;
	dc.DrawText(CString(TheDataMgr.GetTitle())+_T(" - ")+m_name, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	dc.SelectObject(prevFont);
}

void CTTable::Initialize()
{
	m_sectTitles.clear();
	m_lects.clear();
	if(m_type == TTYPE_GRADE)
	{
		m_name = AllocCharBuffer(m_name, TheDataMgr.GetGradeTableName());
		for(int i = m_order*TheDataMgr.GetNSects(); i < (m_order+1)*TheDataMgr.GetNSects(); i++)
		{
			if(i < TheDataMgr.GetNGrades())
			{
				m_sectTitles.push_back(TheDataMgr.GetGrade(i));
				vector<CLect*> lects;
				for(int j=0; j<TheLects.GetSize(); j++)
				{
					CLect* lect = CLect::Get(j);
					if(lect->GetSubj() != NULL && lect->GetSubj()->GetGrade() == i &&
						lect->GetDay() != NONE && lect->GetSPrd() != NONE && lect->GetEPrd() != NONE)
						lects.push_back(lect);
				}
				m_lects.push_back(lects);
			}
			else
				break;
		}
	}
	else if(m_type == TTYPE_INST)
	{
		m_name = AllocCharBuffer(m_name, TheDataMgr.GetInstTableName());
		for(int i = m_order*TheDataMgr.GetNSects(); i < (m_order+1)*TheDataMgr.GetNSects(); i++)
		{
			if(i < CInst::GetSize())
			{
				CInst* inst = CInst::Get(i);
				m_sectTitles.push_back(inst->GetName());
				vector<CLect*> lects;
				for(int j=0; j<TheLects.GetSize(); j++)
				{
					CLect* lect = CLect::Get(j);
					if(lect->GetSubj() != NULL && lect->GetSubj()->GetTeam() != NULL &&
						lect->GetSubj()->GetTeam()->HasInst(inst) &&
						lect->GetDay() != NONE && lect->GetSPrd() != NONE && lect->GetEPrd() != NONE)
						lects.push_back(lect);
				}
				m_lects.push_back(lects);				
			}
			else
				break;
		}
	}
	else //if(m_type == TTYPE_ROOM)
	{
		m_name = AllocCharBuffer(m_name, TheDataMgr.GetRoomTableName());
		for(int i = m_order*TheDataMgr.GetNSects(); i < (m_order+1)*TheDataMgr.GetNSects(); i++)
		{
			if(i < CRoom::GetSize())
			{
				vector<CLect*> lects;
				CRoom* room = CRoom::Get(i);
				m_sectTitles.push_back(room->GetName());
				for(int j=0; j<TheLects.GetSize(); j++)
				{
					CLect* lect = CLect::Get(j);
					if(lect->HasRoom(room) && lect->GetDay() != NONE &&
						lect->GetSPrd() != NONE && lect->GetEPrd() != NONE)
						lects.push_back(CLect::Get(j));
				}
				m_lects.push_back(lects);				
			}
			else
				break;
		}
	}
	m_nValidSects = (int) m_sectTitles.size();
}

void CTTable::GetLectString(CLect* lect, CString& str)
{
	if(m_type == TTYPE_GRADE)
	{
		CString strTemp;
		CSubj* subj = lect->GetSubj();
		subj->GetInString(COL_THIS, str);
		if(subj->GetTeam() == NULL)
		{
			if(lect->GetRoom() != NULL)
			{
				str.Append(_T("\n()\n"));
				lect->GetRoom()->GetInString(COL_THIS, strTemp);
				str.Append(strTemp);
			}
		}
		else
		{
			subj->GetInString(COL_SUBJ_TEAM, strTemp);
			str.Append(_T("\n(") + strTemp + _T(")"));
			if(lect->GetRoom() != NULL)
			{
				lect->GetRoom()->GetInString(COL_THIS, strTemp);
				str.Append(_T("\n") + strTemp);
			}
		}
	}
	else if(m_type == TTYPE_INST)
	{
		CString strTemp;
		CSubj* subj = lect->GetSubj();
		subj->GetInString(COL_THIS, str);
		if(subj->GetGrade() == NONE)
		{
			if(lect->GetRoom() != NULL)
			{
				lect->GetInString(COL_LECT_ROOM, strTemp);
				str.AppendFormat(_T("\n()\n%s"), strTemp);
			}
		}
		else
		{
			subj->GetInString(COL_SUBJ_GRADE, strTemp);
			str.AppendFormat(_T("\n(%s)"), strTemp);
			if(lect->GetRoom() != NULL)
			{
				lect->GetRoom()->GetInString(COL_THIS, strTemp);
				str.Append(_T("\n") + strTemp);
			}
		}
	}
	else //if(m_type == TTYPE_ROOM)
	{
		CSubj* subj = lect->GetSubj();
		if(subj != NULL)
		{
			CString strTemp;
			str = subj->GetName();
			subj->GetInString(COL_SUBJ_GRADE, strTemp);
			str.AppendFormat(_T("\n(%s)\n"), strTemp);
			subj->GetInString(COL_SUBJ_TEAM, strTemp);
			str += strTemp;
		}
		else
			str = _T("()");
	}
}

void CTTable::DisplayAllLectsText(CDC& dc)
{
	CString str;
	RECT rect;
	CBrush brush(RGB(255, 255, 255));
	CBrush* prevBrush = dc.SelectObject(&brush);
	for(UINT i = 0; i < m_lects.size(); i++)
		for(UINT j = 0; j < m_lects[i].size(); j++)
			if(m_lects[i][j] != CurrLect)
			{
				GetLectRect(m_lects[i][j], i, rect);
				dc.Rectangle(&TransformRect(rect));
				GetLectString(m_lects[i][j], str);
				DrawTextInRect(dc, str, rect);
			}
	dc.SelectObject(prevBrush);
}

void CTTable::DrawColoredRects(CDC& dc)
{
	int prevDrawingMode = dc.SetROP2(R2_MASKPEN);
	COLORREF color;
	RECT rect;
	CBrush brush(RGB(0,0,0));
	CBrush* prevBrush = dc.SelectObject(&brush);
	for(UINT i = 0; i < m_lects.size(); i++)
		for(UINT j = 0; j < m_lects[i].size(); j++)
			if(m_lects[i][j] != CurrLect)
			{
				if(m_lects[i][j]->IsOverlapped())
					color = OverlapColor;
				else if(m_lects[i][j]->GetSubj() == NULL || m_lects[i][j]->GetSubj()->GetTeam() == NULL)
					color = DefaultColor;
				else
					color = m_lects[i][j]->GetSubj()->GetTeam()->GetColor();
				GetLectRect(m_lects[i][j], i, rect);
				brush.DeleteObject();
				brush.CreateSolidBrush(color);
				dc.SelectObject(&brush);
				dc.Rectangle(&TransformRect(rect));
			}
	dc.SelectObject(prevBrush);
	dc.SetROP2(prevDrawingMode);
}

void CTTable::DisplayLect(CDC& dc, CLect* lect, int sect)
{
	COLORREF color;
	if(lect->IsOverlapped())
		color = OverlapColor;
	else if(lect->GetSubj() == NULL || lect->GetSubj()->GetTeam() == NULL)
		color = DefaultColor;
	else
		color = lect->GetSubj()->GetTeam()->GetColor();

	RECT rect;
	GetLectRect(lect, sect, rect);
	CBrush brush(color);
	CBrush* prevBrush = dc.SelectObject(&brush);
	dc.Rectangle(&TransformRect(rect));
	dc.SelectObject(prevBrush);

	CString str;
	GetLectString(lect, str);
	DrawTextInRect(dc, str, rect);
}

void CTTable::DisplayAllLects(CDC& dc)
{
	for(UINT i = 0; i < m_lects.size(); i++)
		for(UINT j = 0; j < m_lects[i].size(); j++)
			if(m_lects[i][j] != CurrLect)
				DisplayLect(dc, m_lects[i][j], i);
}

void CTTable::SetCurrLect(CPoint p)
{
	int day, prd;
	
	CLect* lect = CurrLect;
	CurrLect = NULL;
	if(GetPositon(p, CurrSect, day, prd) && CurrSect < (int) m_lects.size())
	{
		for(vector<CLect*>::iterator i = m_lects[CurrSect].begin(); i != m_lects[CurrSect].end(); i++)
			if(day == (*i)->GetDay() && (*i)->GetSPrd() <= prd && prd <= (*i)->GetEPrd())
			{
				CurrLect = *i;
				if(lect == CurrLect)
					break;
			}
		if(CurrLect != NULL)
		{
			CurrLectSects.clear();
			for(UINT j = 0; j < m_lects.size(); j++)
				for(UINT k = 0; k < m_lects[j].size(); k++)
					if(m_lects[j][k] == CurrLect)
					{
						CurrLectSects.push_back(j);
						break;
					}
			CurrLect->PrepareDrag();
			CurrPoint = p;
			GetLectRect(CurrLect, CurrSect, CurrRect);
			GetLectString(CurrLect, CurrText);
			Invalidate();
		}
	}
}

// the first lect in the cell
CLect* CTTable::GetCellLect(int sect, int day, int prd)
{
	for(vector<CLect*>::iterator i = m_lects[sect].begin(); i != m_lects[sect].end(); i++)
		if(day == (*i)->GetDay() && (*i)->GetSPrd() <= prd && prd <= (*i)->GetEPrd())
			return *i;
	return NULL;
}


void CTTable::GetHmlLectString(CString& str, CString& format, CLect* lect)
{
	if(m_type == TTYPE_GRADE)
	{
		CString strTemp;
		CSubj* subj = lect->GetSubj();
		subj->GetInString(COL_THIS, strTemp);
		str.Format(format, 1, strTemp);
		if(subj->GetTeam() == NULL)
		{
			if(lect->GetRoom() != NULL)
			{
				str.AppendFormat(format, 1, _T("()"));
				lect->GetRoom()->GetInString(COL_THIS, strTemp);
				str.AppendFormat(format, 1, strTemp);
			}
		}
		else
		{
			subj->GetInString(COL_SUBJ_TEAM, strTemp);
			str.AppendFormat(format,1,  _T("(") + strTemp + _T(")"));
			if(lect->GetRoom() != NULL)
			{
				lect->GetRoom()->GetInString(COL_THIS, strTemp);
				str.AppendFormat(format, 1, strTemp);
			}
		}
	}
	else if(m_type == TTYPE_INST)
	{
		CString strTemp;
		CSubj* subj = lect->GetSubj();
		subj->GetInString(COL_THIS, strTemp);
		str.Format(format, 1, strTemp);
		if(subj->GetGrade() == NONE)
		{
			if(lect->GetRoom() != NULL)
			{
				lect->GetInString(COL_LECT_ROOM, strTemp);
				str.AppendFormat(format, 1, _T("()"));
				str.AppendFormat(format, 1, strTemp);
			}
		}
		else
		{
			subj->GetInString(COL_SUBJ_GRADE, strTemp);
			str.AppendFormat(format, 1, _T("(") + strTemp + _T(")"));
			if(lect->GetRoom() != NULL)
			{
				lect->GetRoom()->GetInString(COL_THIS, strTemp);
				str.AppendFormat(format, 1, strTemp);
			}
		}
	}
	else //if(m_type == TTYPE_ROOM)
	{
		CString strTemp;
		CSubj* subj = lect->GetSubj();
		if(subj != NULL)
		{
			str.Format(format, 1, subj->GetName());
			subj->GetInString(COL_SUBJ_GRADE, strTemp);
			str.AppendFormat(format, 1, _T("(") + strTemp + _T(")\n"));
			subj->GetInString(COL_SUBJ_TEAM, strTemp);
			str.AppendFormat(format, 1, strTemp);
		}
		else
			str.Format(format, 1, _T("()"));
	}
}

BOOL CTTable::IsLectOverlapedInSect(int& nPrds, CLect* lect, int sect)
{
	BOOL overlap = FALSE;
	int sPrd = lect->GetSPrd();
	int ePrd = lect->GetEPrd();
	for(vector<CLect*>::iterator i = m_lects[sect].begin(); i != m_lects[sect].end(); i++)
		if(lect != *i && lect->GetDay() == (*i)->GetDay() && sPrd <= (*i)->GetEPrd() && (*i)->GetSPrd() <= ePrd)
		{
			if(sPrd > (*i)->GetSPrd())
			{
				nPrds = 0;
				return TRUE;
			}
			else if(ePrd < (*i)->GetEPrd())
				ePrd = (*i)->GetEPrd();
			overlap = TRUE;
		}
	nPrds = ePrd - sPrd + 1;
	return overlap;
}

#define WU(x)		CHml::WriteAsUTF8(file, _T(x))

// str1 �Է� BorderFill, RowAddr, RowSpan, ColAddr, ColSpan, Width, Height
// str3 for empty cell
// str4 for nonempty cell �Է� CharShape, char
void CTTable::ExportRow(CFile& file, int prd, vector<DWORD> colors,
						CString& str1, CString& str2, CString& str3, CString& str4, CString& str5)
{
	int borderFill;
	if(prd == 0)
		borderFill = HML_TOPBORDER + 2;
	else if(prd == TheDataMgr.GetNPrds()-1)
		borderFill = HML_BOTTOMBORDER + 2;
	else
		borderFill = 2;
	CString str0;
	// time
	str0.Format(str1, borderFill+HML_LEFTBORDER+HML_RIGHTBORDER, prd+2, 1, 0, 1, CHml::Sizes[wdTime], CHml::Sizes[htPrd]);
	CHml::WriteAsUTF8(file, _T("<ROW>") + str0);
	CHml::WriteAsUTF8(file, str2);
	str0.Format(str4, 0, TheDataMgr.GetTime(prd));
	CHml::WriteAsUTF8(file, str0 + str5);

	CLect* lect;
	int border;
	for(int sect = 0; sect < TheDataMgr.GetNSects(); sect++)
	{
		// period
		border = borderFill+HML_LEFTBORDER+(sect<m_nValidSects && GetCellLect(sect,0,prd)!=NULL ? HML_RIGHTBORDER : 0);
		str0.Format(str1, border, prd+2, 1, 1+sect*(TheDataMgr.GetNDays()+1), 1, CHml::Sizes[wdPrd], CHml::Sizes[htPrd]);
		CHml::WriteAsUTF8(file, str0);
		CHml::WriteAsUTF8(file, str2);
		str0.Format(str4, 0, TheDataMgr.GetPrd(prd));
		CHml::WriteAsUTF8(file, str0 + str5);
		// lectures
		if(sect < m_nValidSects)
		{
			for(int day = 0; day < TheDataMgr.GetNDays(); day++)
			{
				// �� cell�̸�
				if((lect=GetCellLect(sect, day, prd)) == NULL)
				{
					// border�� �����Ѵ�.
					border = 0;
					if(day != 0 && GetCellLect(sect, day-1, prd) != NULL)
						border += HML_LEFTBORDER;
					if(day == TheDataMgr.GetNDays()-1)
						border += HML_RIGHTBORDER;
					if(prd == 0 || GetCellLect(sect, day, prd-1) != NULL)
						border += HML_TOPBORDER;
					if(prd == TheDataMgr.GetNPrds()-1 || GetCellLect(sect, day, prd+1) != NULL)
						border += HML_BOTTOMBORDER;
					str0.Format(str1, border+2, prd+2, 1, 2+day+sect*(TheDataMgr.GetNDays()+1), 1, CHml::Sizes[wdDay], CHml::Sizes[htPrd]);
					CHml::WriteAsUTF8(file, str0);
					CHml::WriteAsUTF8(file, str2);
					CHml::WriteAsUTF8(file, str3 + str5);
				}
				// �ش� cell�� lect�� ���� cell�̸�
				else if(lect->GetSPrd() == prd)
				{
					int nPrds;
					// lect�� overlap�� ������
					if(IsLectOverlapedInSect(nPrds, lect, sect))
					{
						if(nPrds != 0)
						{
							// ���� ����
							UINT i;
							for(i = 0; i < colors.size(); i++)
								if(colors[i] == OverlapColor)
									break;
							str0.Format(str1, 18+i, prd+2, nPrds,2+day+sect*(TheDataMgr.GetNDays()+1), 1, CHml::Sizes[wdDay], CHml::Sizes[htPrd]*nPrds);
							CHml::WriteAsUTF8(file, str0);
							CHml::WriteAsUTF8(file, str2);
							CHml::WriteAsUTF8(file, str3 + str5);
						}
					}
					else
					{
						// ���� ����
						DWORD color = lect->GetSubj() != NULL && lect->GetSubj()->GetTeam() != NULL ? lect->GetSubj()->GetTeam()->GetColor() : DefaultColor;
						UINT i;
						for(i = 0; i < colors.size(); i++)
							if(colors[i] == color)
								break;
						str0.Format(str1, 18+i, prd+2, nPrds, 2+day+sect*(TheDataMgr.GetNDays()+1), 1, CHml::Sizes[wdDay], CHml::Sizes[htPrd]*nPrds);
						CHml::WriteAsUTF8(file, str0);
						CHml::WriteAsUTF8(file, str2);
						GetHmlLectString(str0, str4, lect);
						CHml::WriteAsUTF8(file, str0 + str5);
					}
				}
			}
		}
		else
		{
			for(int day = 0; day < TheDataMgr.GetNDays(); day++)
			{
				// ��� �� cell
				str0.Format(str1, borderFill+(day==TheDataMgr.GetNDays()-1 ? HML_RIGHTBORDER : 0),
					prd+2, 1, 2+day+sect*(TheDataMgr.GetNDays()+1), 1, CHml::Sizes[wdDay], CHml::Sizes[htPrd]);
				CHml::WriteAsUTF8(file, str0);
				CHml::WriteAsUTF8(file, str2);
				CHml::WriteAsUTF8(file, str3 + str5);
			}
		}
	}
	WU("</ROW>");
}

void CTTable::ExportAsHml(CFile& file, vector<DWORD> colors, BOOL firstPage)
{
	// row�� ���� �غ�
	// str1 �Է� BorderFill, RowAddr, RowSpan, ColAddr, ColSpan, Width, Height
	CString str1 = _T("<CELL BorderFill=\"%d\" RowAddr=\"%d\" RowSpan=\"%d\" ColAddr=\"%d\" ColSpan=\"%d\" Width=\"%d\" Height=\"%d\" Dirty=\"false\" Editable=\"false\" HasMargin=\"false\" Header=\"false\" Protect=\"false\">");
	CString str2 = _T("<PARALIST LineWrap=\"Break\" LinkListID=\"0\" LinkListIDNext=\"0\" TextDirection=\"0\" VertAlign=\"Center\">");
	// str3 for empty cell
	CString str3 = _T("<P ParaShape=\"0\" Style=\"0\"><TEXT CharShape=\"1\"/></P>");
	// str4 for nonempty cell �Է� CharShape, char
	CString str4 = _T("<P ParaShape=\"0\" Style=\"0\"><TEXT CharShape=\"%d\"><CHAR>%s</CHAR></TEXT></P>");
	// str5 end cell
	CString str5 = _T("</PARALIST></CELL>");
	WU("<P ParaShape=\"0\" Style=\"0\"><TEXT CharShape=\"3\">");
	if(firstPage)
		CHml::WriteFirstPageHeader(file);
	CString str0 = CString(_T("<CHAR>")) + TheDataMgr.GetTitle() + _T(" - ") + m_name;
	CHml::WriteAsUTF8(file, str0);
	WU("</CHAR></TEXT></P><P ParaShape=\"0\" Style=\"0\"><TEXT CharShape=\"3\">");

	// table <TABLE...> ... </TABLE>
	str0.Format(_T("<TABLE BorderFill=\"2\" RowCount=\"%d\" ColCount=\"%d\" CellSpacing=\"0\" PageBreak=\"Table\" RepeatHeader=\"true\">"), 2+TheDataMgr.GetNPrds(), 1+TheDataMgr.GetNSects()*(1+TheDataMgr.GetNDays()));
	CHml::WriteAsUTF8(file, str0);
	str0.Format(_T("<SHAPEOBJECT InstId=\"%d\" ZOrder=\"%d\" Lock=\"false\" NumberingType=\"None\">"), m_order, m_order);
	CHml::WriteAsUTF8(file, str0);
	str0.Format(_T("<SIZE Width=\"%d\" Height=\"%d\" HeightRelTo=\"Absolute\" Protect=\"false\" WidthRelTo=\"Absolute\"/>"), CHml::Sizes[wdTable], CHml::Sizes[htTable]);
	CHml::WriteAsUTF8(file, str0);
	WU("<POSITION AffectLSpacing=\"false\" AllowOverlap=\"false\" FlowWithText=\"true\" HoldAnchorAndSO=\"false\" HorzAlign=\"Left\" HorzOffset=\"0\" HorzRelTo=\"Para\" TreatAsChar=\"true\" VertAlign=\"Top\" VertOffset=\"0\" VertRelTo=\"Para\"/>");
	WU("<OUTSIDEMARGIN Bottom=\"283\" Left=\"283\" Right=\"283\" Top=\"283\"/></SHAPEOBJECT><INSIDEMARGIN Bottom=\"141\" Left=\"141\" Right=\"141\" Top=\"141\"/>");
	/************************************************************/
	// determine width and height
	/************************************************************/
	// rows
	// str1 �Է� BorderFill, RowAddr, RowSpan, ColAddr, ColSpan, Width, Height
	// str3 for empty cell
	// str4 for nonempty cell �Է� CharShape, char
	// ����
	WU("<ROW>");
	str0.Format(str1, colors.size()+18, 0, 2, 0, 1, CHml::Sizes[wdTime], CHml::Sizes[htSect]+CHml::Sizes[htDay]);
	CHml::WriteAsUTF8(file, str0);
	CHml::WriteAsUTF8(file, str2);
	CHml::WriteAsUTF8(file, str3 + str5);
	// sect titles
	for(int sect = 0; sect < TheDataMgr.GetNSects(); sect++)
	{
		str0.Format(str1, HML_LEFTBORDER+HML_TOPBORDER+HML_RIGHTBORDER+2, 0, 1, (TheDataMgr.GetNDays()+1)*sect+1, TheDataMgr.GetNDays()+1, CHml::Sizes[wdPrd]+TheDataMgr.GetNDays()*CHml::Sizes[wdDay], CHml::Sizes[htSect]);
		CHml::WriteAsUTF8(file, str0);
		CHml::WriteAsUTF8(file, str2);
		if(sect < m_nValidSects)
		{
			str0.Format(str4, 4, m_sectTitles[sect]);
			CHml::WriteAsUTF8(file, str0 + str5);
		}
		else
			CHml::WriteAsUTF8(file, str3 + str5);
	}
	WU("</ROW><ROW>");
	// ����
	for(int sect = 0; sect < TheDataMgr.GetNSects(); sect++)
	{
		for(int k = 0; k <= TheDataMgr.GetNDays(); k++)
		{
			str0.Format(str1, 2+(k==0 ? HML_LEFTBORDER : k==TheDataMgr.GetNDays() ? HML_RIGHTBORDER : 0)+HML_BOTTOMBORDER, 1, 1, (TheDataMgr.GetNDays()+1)*sect+1+k, 1, k==0 ? CHml::Sizes[wdPrd] : CHml::Sizes[wdDay], CHml::Sizes[htDay]);
			CHml::WriteAsUTF8(file, str0);
			CHml::WriteAsUTF8(file, str2);
			if(k == 0)
				CHml::WriteAsUTF8(file, str3+str5);
			else
			{
				str0.Format(str4, 4, TheDataMgr.GetDay(k-1));
				CHml::WriteAsUTF8(file, str0+str5);
			}
		}
	}
	WU("</ROW>");
	for(int prd = 0; prd < TheDataMgr.GetNPrds(); prd++)
		ExportRow(file, prd, colors, str1, str2, str3, str4, str5);

	WU("</TABLE></TEXT></P>");
}

// static
void CTTable::InitCoords()
{
	Len[hzLeft ] = LEFT_WIDTH;
	Len[hzRight] = RIGHT_WIDTH;
	Len[hzInner] = INNER_WIDTH;

	Len[vtTop   ] = TOP_HEIGHT;
	Len[vtBottom] = BOTTOM_HEIGHT;
	Len[vtInner ] = INNER_HEIGHT;

	CoordX = new int*[NSects];
	for(int i=0; i<NSects; i++)
		CoordX[i] = new int[NDays+1];
	CoordY = new int[NPrds+1];

	SectX = new int[NSects];  // ? +1
}

void CTTable::DeleteCoords()
{
	if(CoordX != NULL)
	{
		for(int i=0; i<NSects; i++)
			if(CoordX[i] != NULL)
				delete[] CoordX[i];
		delete[] CoordX;
	}
	if(CoordY != NULL)
		delete[] CoordY;

	if(SectX != NULL)
		delete[] SectX;
}

void CTTable::ResetSizeVars(CTTable* table)
{
	CDC* pDC = table->GetDC();
	CSize size;
	Len[hzTime] = 0;
	Len[hzPrd] = 0;
	RECT rect;
	// times�� prds�� �ʺ� ���ÿ� ����
	for(int i=0; i<NPrds; i++)
	{
		table->GetClientRect(&rect);
		pDC->DrawText(TheDataMgr.GetTime(i), &rect, DT_CALCRECT | DT_CENTER);
		if(Len[hzTime] < rect.right - rect.left)
			Len[hzTime] = rect.right - rect.left;
		table->GetClientRect(&rect);
		pDC->DrawText(TheDataMgr.GetPrd(i), &rect, DT_CALCRECT | DT_CENTER);
		if(Len[hzPrd] < rect.right - rect.left)
			Len[hzPrd] = rect.right - rect.left;
	}
	Len[hzTime] += 2 * Len[hzInner];
	Len[hzPrd]  += 2 * Len[hzInner];

	// title�� ���̸� ����
	CFont font;
	font.CreatePointFont(FONTSIZE_TITLE*10, _T("����"));
	CFont* prevFont = pDC->SelectObject(&font);
	table->GetClientRect(&rect);
	pDC->DrawText(TheDataMgr.GetTitle(), &rect, DT_CALCRECT | DT_CENTER);
	Len[vtTitle] = rect.bottom + 2 * Len[vtInner];
	pDC->SelectObject(prevFont);

	table->ReleaseDC(pDC);

	table->GetClientRect(&rect);

	int cx = rect.right - rect.left;
	int cy = rect.bottom - rect.top;

	// �ʺ�, ���̴� ���� ������ �κ��� ���̸� ���.
	Len[hzDay]	= (cx - (Len[hzLeft] + 2 + Len[hzTime] + NSects * (Len[hzPrd]+2) + 2 + Len[hzRight])) / (NSects * NDays) - 1;
	Len[hzSect] = Len[hzPrd] + NDays * (Len[hzDay] + 1);
	Len[vtPrd]	= (cy - (Len[vtTop] + Len[vtTitle] + 2 + 2 + Len[vtBottom])) / (NPrds+2) - 1;
	Len[vtDay]  = Len[vtSect] = Len[vtPrd];
	Len[vtSep]  = Len[vtSect] + 1 + Len[vtDay];
	 
	// main �簢���� ���� ��ǥ
	Left   = Len[hzLeft] + 2;
	Top	   = Len[vtTop] + Len[vtTitle] + 2;
	Right  = Len[hzLeft] + 2 + Len[hzTime] + NSects*(Len[hzSect]+2) - 1;
	Bottom = Len[vtTop] + Len[vtTitle] + 2 + Len[vtSep] + 1 + NPrds*(1+Len[vtPrd]) - 1;

	// sect ���� �簢��
	int d = Len[hzLeft] + 2 + Len[hzTime] + 2;
	for(int i=0; i<NSects; i++)
	{
		SectX[i] = d;
		d += Len[hzPrd] + 1;
		for(int j=0; j<NDays; j++)
		{
			CoordX[i][j] = d;
			d += Len[hzDay] + 1;
		}
		// ������ ��ǥ�� sect�� ��輱�� �´�.
		CoordX[i][NDays] = d++;
	}
	SectY = Len[vtTop] + Len[vtTitle] + 2 + Len[vtSect] - 1;

	d = Len[vtTop] + Len[vtTitle] + 2 + Len[vtSep] + 2;
	for(int i=0; i<=NPrds; i++)
	{
		CoordY[i] = d;
		d += Len[vtPrd] + 1;
	}
}

BOOL CTTable::GetPositon(const CPoint& p, int& sect, int& day, int& prd)
{
	if(p.y < CoordY[0] || CoordY[NPrds]-2 < p.y)
		return FALSE;
	prd = (p.y - CoordY[0]) / (Len[vtPrd]+1);
	if(p.y == CoordY[prd] + Len[vtPrd])
		return FALSE;

	for(sect = 0; sect < NSects; sect++)
	{
		if(CoordX[sect][0] <= p.x && p.x < CoordX[sect][NDays]-1)
		{
			day = (p.x - CoordX[sect][0]) / (Len[hzDay]+1);
			return p.x != CoordX[sect][day] + Len[hzDay];
		}
	}
	return FALSE;
}

void CTTable::DrawTextInRect(CDC& dc, LPCTSTR str, CRect rect)
{
	CFont font;
	font.CreatePointFont(MAX_LECT_FONTSIZE*10, _T("����"), &dc);
	CFont* prevFont = dc.SelectObject(&font);
	rect.DeflateRect(DEFLATION_X, DEFLATION_Y);
	// font size ����
	CRect rectTemp;
	for(int i=MAX_LECT_FONTSIZE; i>0; i--)
	{
		rectTemp = rect;
		dc.DrawText(str, &rectTemp, DT_CALCRECT | DT_CENTER | DT_WORDBREAK);
		if(rectTemp.bottom <= rect.bottom) break;
		font.DeleteObject();
		font.CreatePointFont((i-1)*10, _T("����"), &dc);
		dc.SelectObject(&font);
	}
	rect.DeflateRect((rect.right - rectTemp.right)/2, (rect.bottom - rectTemp.bottom)/2);
	int prevBkMode = dc.GetBkMode();
	dc.SetBkMode(TRANSPARENT);
	dc.DrawText(str, &rect, DT_CENTER | DT_WORDBREAK);
	dc.SetBkMode(prevBkMode);
	dc.SelectObject(prevFont);
}

void CTTable::GetLectRect(CLect* lect, int sect, RECT &rect)
{
	ASSERT(lect->GetDay() != NONE || lect->GetSPrd() != NONE || lect->GetEPrd() != NONE);
	rect.left	= CoordX[sect][lect->GetDay()];
	rect.top	= CoordY[lect->GetSPrd()];
	rect.right  = rect.left + Len[hzDay] - 1;
	rect.bottom	= CoordY[lect->GetEPrd()+1] - 2;
}

//#define _UNINSCRIBED2DVIEW
//#define _UNINSCRIBED3DVIEW
//#define _INSCRIBEDVIEW
RECT& CTTable::TransformRect(RECT& rect)
{
#if defined _UNINSCRIBED2DVIEW
	// uninscribed 2D view
	rect.left--;
	rect.top--;
	rect.right += 2;
	rect.bottom += 2;
#undef _UNINSCRIBED2DVIEW
#elif defined _UNINSCRIBED3DVIEW
	// uninscribed 3D view
	rect.left--;
	rect.top--;
	rect.right++;
	rect.bottom++;
#undef _UNINSCRIBED3DVIEW
#else //#elif defined _INSCRIBEDVIEW
	// inscribed view
	rect.right++;
	rect.bottom++;
#endif
	return rect;
}

void CTTable::DisplayCurrLect(CDC& dc)
{
	COLORREF color;
	if(CurrLect->IsOverlapped())
		color = OverlapColor;
	else if(CurrLect->GetSubj() == NULL || CurrLect->GetSubj()->GetTeam() == NULL)
		color = DefaultColor;
	else
		color = CurrLect->GetSubj()->GetTeam()->GetColor();

	RECT rectOuter(CurrRect);
	rectOuter.left  -= SectX[CurrSect];
	rectOuter.right -= SectX[CurrSect];
	TransformRect(rectOuter);
	CBrush brush(color);
	CBrush* prevBrush = dc.SelectObject(&brush);

	for(vector<int>::iterator i = CurrLectSects.begin(); i != CurrLectSects.end(); i++)
	{
		CRect rect(rectOuter);
		rect.OffsetRect(SectX[*i],0);
		dc.Rectangle(&rect);

		DrawTextInRect(dc, CurrText, rect);

		// ���õǾ����� ��Ÿ���� ǥ�ø� �ؾ� �Ѵ�.
		//rect.DeflateRect(DEFLATION_X, DEFLATION_Y);
		rect.left   += DEFLATION_X;
		rect.right  -= DEFLATION_X+1;
		rect.top    += DEFLATION_Y;
		rect.bottom -= DEFLATION_Y+1;
		dc.MoveTo(rect.left,  rect.top);
		dc.LineTo(rect.right, rect.top);
		dc.LineTo(rect.right, rect.bottom);
		dc.LineTo(rect.left,  rect.bottom);
		dc.LineTo(rect.left,  rect.top);
	}
	dc.SelectObject(prevBrush);
}

// for dragging
void CTTable::AdjustCurrRect_Drag(const CPoint& p)
{
	CurrRect.OffsetRect(p - CurrPoint);

	int dx = 0, dy = 0;
	if(CurrRect.left < CoordX[CurrSect][0])
		dx = CoordX[CurrSect][0] - CurrRect.left;
	else if(CoordX[CurrSect][NDays]-2 < CurrRect.right)
		dx = CoordX[CurrSect][NDays] - 2 - CurrRect.right;
	if(CurrRect.top < CoordY[0])
		dy = CoordY[0] - CurrRect.top;
	else if(CoordY[NPrds]-2 < CurrRect.bottom)
		dy = CoordY[NPrds] - 2 - CurrRect.bottom;

	CurrRect.OffsetRect(dx, dy);
	// day
	CurrLect->SetDay((int)((CurrRect.left - CoordX[CurrSect][0]) / (double)(Len[hzDay]+1) + 0.5));
	// new sPrd
	dx = (int)((CurrRect.top - CoordY[0]) / (double)(Len[vtPrd]+1) + 0.5);
	CurrLect->GetEPrd() += dx - CurrLect->GetSPrd();
	CurrLect->SetSPrd(dx);
}

// for sizing
void CTTable::AdjustCurrRect_Size(const CPoint& p)
{
	if(State == TSTATE_SIZINGUP)
	{
		if(p.y < CoordY[0])
			CurrRect.top = CoordY[0];
		else
			CurrRect.top = p.y <= CurrRect.bottom-Len[vtPrd] ? p.y : CurrRect.bottom-Len[vtPrd]+1;
		CurrLect->SetSPrd((int)((CurrRect.top - CoordY[0]) / (double)(Len[vtPrd]+1) + 0.5));
	}
	else
	{
		if(CoordY[NPrds]-2 <= p.y)
			CurrRect.bottom = CoordY[NPrds]-2;
		else 
			CurrRect.bottom = CurrRect.top+Len[vtPrd] <= p.y ? p.y : CurrRect.top+Len[vtPrd]-1;
		CurrLect->SetEPrd((int)((CurrRect.bottom - CoordY[0]) / (double)(Len[vtPrd]+1) - 0.5));
	}
}

// CTTable �޽��� ó�����Դϴ�.

BOOL CTTable::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	if(CursorType == CURSOR_SIZENS)
	{
		SetCursor(CursorSizeNS);
		return TRUE;
	}
	else
		return CView::OnSetCursor(pWnd, nHitTest, message);
}

BOOL CTTable::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
	//return CView::OnEraseBkgnd(pDC);
}

void CTTable::OnKillFocus(CWnd* pNewWnd)
{
	CView::OnKillFocus(pNewWnd);

	CurrLect = NULL;
	State = TSTATE_READY;
	Invalidate();
}

void CTTable::OnMouseMove(UINT nFlags, CPoint point)
{
	RECT rect;
	switch(State)
	{
	case TSTATE_LBUTTONDOWN:
		// ready to drag
		State = TSTATE_DRAGGING;
		SetCapture();
		break;
	case TSTATE_DRAGGING:
		rect = CurrRect;
		AdjustCurrRect_Drag(point);
		if(CurrRect.left == rect.left && CurrRect.top == rect.top) break; 
		CurrPoint.Offset(CurrRect.left - rect.left, CurrRect.top - rect.top);
		CurrLect->CheckOverlap_Drag();
		Invalidate();
		break;
	case TSTATE_SELECTED:
		CursorType = CurrRect.left <= point.x && point.x <= CurrRect.right &&
			((CurrRect.top <= point.y && point.y <= CurrRect.top+DEFLATION_Y) ||
			 (CurrRect.bottom-DEFLATION_Y <= point.y && point.y <= CurrRect.bottom))
			? CURSOR_SIZENS : CURSOR_NORMAL;
		break;
	case TSTATE_SIZINGUP:
	case TSTATE_SIZINGDOWN:
		SetCapture();
		AdjustCurrRect_Size(point);
		CurrLect->CheckOverlap_Drag();
		Invalidate();
		break;
	}
	CView::OnMouseMove(nFlags, point);
}

void CTTable::OnLButtonDown(UINT nFlags, CPoint point)
{
#ifdef _DEBUG
	OutputDebugString(_T("LButtonDown\n"));
#endif
	CLect* lect = CurrLect;
	SetCurrLect(point);

	if(State == TSTATE_READY)
	{
		if(CurrLect != NULL)
		{
			BuildBkDC();
			State = TSTATE_LBUTTONDOWN;
		}
	}
	else if(State == TSTATE_SELECTED)
	{
		// sizing
		if(CurrLect == lect && CurrRect.left <= point.x && point.x <= CurrRect.right &&
			((CurrRect.top <= point.y && point.y <= CurrRect.top+DEFLATION_Y) ||
			 (CurrRect.bottom-DEFLATION_Y <= point.y && point.y <= CurrRect.bottom)))
		{
			State = CurrRect.top <= point.y && point.y <= CurrRect.top+DEFLATION_Y ?
				// �� �ʿ��� sizing	  �Ʒ��ʿ��� sizing
				TSTATE_SIZINGUP		: TSTATE_SIZINGDOWN;
			BuildBkDC();
		}
		else if(CurrLect == NULL)
		{
			Invalidate();
			State = TSTATE_READY;
		}
		else // if(CurrLect != NULL)
		{
			//Invalidate();
			BuildBkDC();
			State = TSTATE_LBUTTONDOWN;
		}
	}
	CView::OnLButtonDown(nFlags, point);
}

void CTTable::OnLButtonUp(UINT nFlags, CPoint point)
{
#ifdef _DEBUG
	OutputDebugString(_T("LButtonUp\n"));
#endif
	switch(State)
	{
	case TSTATE_SIZINGUP:
	case TSTATE_SIZINGDOWN:
		TheSubjModelessDlg.GetList()->UpdateCol0(COL_SUBJ_NPRDS);
	case TSTATE_DRAGGING:
		ReleaseCapture();
		CLect::FullCheckOverlap();
		GetLectRect(CurrLect, CurrSect, CurrRect);
		theApp.InvalidateTables();
		TheLectModelessDlg.GetList()->UpdateRow(CurrLect->GetRow());
	case TSTATE_LBUTTONDOWN:
		delete BkDC;
		BkDC = NULL;
		Invalidate();
		State = TSTATE_SELECTED;
	}
	CView::OnLButtonUp(nFlags, point);
}

void CTTable::OnLButtonDblClk(UINT nFlags, CPoint point)
{
#ifdef _DEBUG
	OutputDebugString(_T("LButtonDblClk\n"));
#endif
	int sect, day, prd;
	if(GetPositon(point, sect, day, prd))
	{
		CLectDialog dlg;
		dlg.SetMode(MODE_MODAL);
		CLect* lect = NULL;
		if(sect < (int)m_lects.size())
			for(vector<CLect*>::reverse_iterator i = m_lects[sect].rbegin(); i != m_lects[sect].rend(); i++)
				if(day == (*i)->GetDay() && (*i)->GetSPrd() <= prd && prd <= (*i)->GetEPrd())
				{
					lect = *i;
					break;
				}
		if(lect == NULL)
		{
			lect = CLect::Create();
			lect->SetDay(day);
			lect->SetSPrd(prd);
			lect->SetEPrd(prd);
			TheLectModelessDlg.GetList()->AppendRow();
		}
		dlg.PushBackCheckedRow(lect->GetRow());
		dlg.DoModal();
		Invalidate();
	}
	CView::OnLButtonDblClk(nFlags, point);
}

#undef NSects
#undef NDays
#undef NPrds

