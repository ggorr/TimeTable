#pragma once

class CInst : public CBase
{
	LPTSTR	m_name;
	LPTSTR	m_note;

	CInst(LPCTSTR name = NULL);
public:
	~CInst(void);

	//inherited from CBase

	int GetRow();

	BOOL GetInString(int col, CString &str);
	BOOL SetByString(int col, LPCTSTR str);

	void ToString(CString& str);
	void FromString(const CString& str, int& pos);

	// not inherited

	inline BOOL HasName(const CString& str) {return m_name != NULL && str.Compare(m_name) == 0;}

	inline LPTSTR GetName() {return m_name;}
	inline void SetName(LPCTSTR name) {m_name = AllocCharBuffer(m_name, name);}

	inline LPTSTR GetNote() {return m_note;}
	inline void SetNote(LPCTSTR note) {m_note = AllocCharBuffer(m_note, note);}

	//static

	inline static int GetSize() {return (int) TheInsts.size();}

	static int GetRow(LPCTSTR name);

	static CInst* Create(LPCTSTR = NULL);
	static CInst* CreateForDlg();

	inline static CInst* Get(int row) {return (CInst*) TheInsts[row];}
	static CInst* Get(LPCTSTR name);

	inline static void Exchange(int row0, int row1) {TheInsts.Exchange(row0, row1);}

	inline static void Delete(int row) {TheInsts.Delete(row);}
	inline static void Delete(CInst* inst) {TheInsts.Delete(inst);}

	inline static void Clear() {TheInsts.Clear();}

	inline static BOOL GetInString(int row, int col, CString &str) {return Get(row)->GetInString(col, str);}
	inline static BOOL SetByString(int row, int col, LPCTSTR  str) {return Get(row)->SetByString(col, str);}

	inline static void ConvertToString(CString& str) {TheInsts.ConvertToString(str);}
	inline static void BuildFromString(const CString& str) {TheInsts.BuildFromString(str);}
};
