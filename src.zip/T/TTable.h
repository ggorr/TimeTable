#pragma once


// CTTable ���Դϴ�.

//
//														title
//      |             |       �г�(����) 0         | ... |         �г�(����) n        |
//      |             |    | �� | ȭ | �� | �� | �� | ... |    | �� | ȭ | �� | �� | �� |
//      | 09:00-09:30 | 1  |    |    |   |    |   | ... | 1  |    |    |    |    |   |
//      | 09:30-10:00 | 2  |    |    |   |    |   | ... | 2  |    |    |    |    |   |
//				................................................................
//      | 17:30-18:30 | 18 |    |    |   |    |   | ... | 18 |    |    |    |    |   |
//
//                                                  top
//													title
// left | sep  |				sect 0			   |     |				 sect n			     |
// left |	   |	 | day | day | day | day | day | ... |     | day | day | day | day | day | right
// left | time | prd |	   |     |	   |     |	   |     | prd |     |     |     |	   |     | right
// left | time | prd |	   |     |     |	 |	   |     | prd |     |     |     |     |     | right
//																		bottom
//***************************************************************************************************

#define LEFT_WIDTH		10
#define RIGHT_WIDTH		10
#define INNER_WIDTH		3

#define TOP_HEIGHT		5
#define BOTTOM_HEIGHT	5
#define INNER_HEIGHT	3

#define hzLeft		0	// left space
#define hzRight		1	// right space
#define hzInner		2	// inner space
#define hzTime		3	// time width
#define hzPrd		4	// prd width
#define hzDay		5	// day width
#define hzSect		6	// sect width
#define hzTotal		7	// total width
#define vtTop		8	// top space
#define vtBottom	9	// bottom space
#define vtInner		10	// inner space
#define vtTitle		11	// title height
#define vtSect		12	// grade height
#define vtDay		13	// day height
#define vtPrd		14	// prd height
#define vtSep		15	// sep height
#define vtTotal		16	// total height
#define hvNo		17	// ������ ��Ÿ����.

#define TTYPE_GRADE		0
#define TTYPE_INST		1
#define TTYPE_ROOM		2

#define DEFLATION_X		3
#define DEFLATION_Y		4

#define TSTATE_READY		0
#define TSTATE_SELECTED		1
#define TSTATE_DRAGGING		2
#define	TSTATE_LBUTTONDOWN	3
#define	TSTATE_SIZINGUP		4
#define TSTATE_SIZINGDOWN	5

#define CURSOR_NORMAL	0
#define CURSOR_SIZENS	1

class CTTable : public CView
{
	DECLARE_DYNCREATE(CTTable)

protected:
	CTTable();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CTTable();

public:
	virtual void OnDraw(CDC* pDC);      // �� �並 �׸��� ���� �����ǵǾ����ϴ�.
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	LPTSTR m_name;
	int m_type;
	int m_order;
	int m_nValidSects;
	vector<LPTSTR> m_sectTitles;
	vector<vector<CLect*>> m_lects;

public:
	inline LPTSTR GetName() {return m_name;}
	inline int GetType() {return m_type;}
	inline void SetType(int type) {m_type = type;}
	inline int GetOrder() {return m_order;}
	inline void SetOrder(int order) {m_order = order;}
	inline int GetNValidSects() {return m_nValidSects;}
	inline vector<LPTSTR> GetSectTitles() {return m_sectTitles;}
	inline LPTSTR GetSectTitle(int i) {return i < m_nValidSects ? m_sectTitles[i] : NULL;}
	inline vector<vector<CLect*>> GetLects() {return m_lects;}
	inline vector<CLect*> GetLects(int sect) {return m_lects[sect];}
	inline CLect* GetLect(int sect, int i) {return m_lects[sect][i];}

	void BuildBkDC();
	void DrawOutline(CDC& dc);
	void Initialize();
	void GetLectString(CLect* lect, CString& str);

	void DisplayAllLectsText(CDC& dc);
	void DrawColoredRects(CDC& dc);

	void DisplayLect(CDC& dc, CLect* lect, int sect);
	void DisplayAllLects(CDC& dc);

	void SetCurrLect(CPoint p);

	CLect* GetCellLect(int sect, int day, int prd);

	void GetHmlLectString(CString& str, CString& format, CLect* lect);
	BOOL IsLectOverlapedInSect(int& nPrds, CLect* lect, int sect);
	void ExportRow(CFile& file, int prd, vector<DWORD> colors, 
		CString& str1, CString& str2, CString& str3, CString& str4, CString& str5);
	void ExportAsHml(CFile& file, vector<DWORD> colors, BOOL firstPage);

	static COLORREF DefaultColor;
	static COLORREF	OverlapColor;

	static int CursorType;
	static HCURSOR CursorSizeNS;
	static int State;

	static CDC* BkDC;

	static int Left;		// ǥ�� ���� x ��ǥ
	static int Right;		// ǥ�� ������ x ��ǥ
	static int Top;			// ǥ�� ���� y ��ǥ
	static int Bottom;		// ǥ�� �Ʒ��� y ��ǥ

	static int* SectX;		// �� �г��� x��ǥ��
	static int  SectY;		// �г� �Ʒ��κ��� y ��ǥ

	static int** CoordX;	// ���� �Է¶��� x ��ǥ��
	static int*  CoordY;	// ���� �Է¶��� y ��ǥ��

	static int		CurrSect;		// current sect
	static CLect*	CurrLect;		// current dragging lect
	static CPoint	CurrPoint;		// current point
	static CRect	CurrRect;		// current dragging rect
	static CString	CurrText;		// current dragging 
	static vector<int> CurrLectSects;	// sects contains current lect

	static int Len[hvNo];

	static void InitCoords();
	static void DeleteCoords();
	static void ResetSizeVars(CTTable* table);
	static BOOL GetPositon(const CPoint& p, int& sect, int& day, int& prd);
	
	static void DrawTextInRect(CDC& dc, LPCTSTR str, CRect rect);
	static void GetLectRect(CLect* lect, int sect, RECT& rect);
	static RECT& TransformRect(RECT& rect);

	static void DisplayCurrLect(CDC& dc);
	static void AdjustCurrRect_Drag(const CPoint& point); // for dragging
	static void AdjustCurrRect_Size(const CPoint& point);	// for sizing

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
};


