#include "StdAfx.h"
#include "T.h"
#include "Base.h"
#include "Inst.h"
#include "Team.h"
#include "Room.h"
#include "Subj.h"
#include "Lect.h"

#include "DataManager.h"

#include <malloc.h>

CLect::CLect(void)
{
	m_day = m_sPrd = m_ePrd = NONE;
	m_room = NULL;
	m_subj = NULL;
	m_note = NULL;

	m_overlap = FALSE;
}

CLect::~CLect(void)
{
	if(m_note != NULL)
		free(m_note);
}

// inherited from CBase

int CLect::GetRow()
{
	return TheLects.GetRow(this);
}

BOOL CLect::GetInString(int col, CString &str)
{
	switch(col)
	{
	case COL_INDEX:
		str.Format(_T("%d"), GetRow());
		break;
	case COL_THIS:
		str.Empty();
		break;
	case COL_LECT_SUBJ:
		if(m_subj == NULL)
			str.Empty();
		else
			m_subj->GetInString(COL_THIS, str);
		break;
	case COL_LECT_ROOM:
		if(m_room == NULL)
			str.Empty();
		else
			m_room->GetInString(COL_THIS, str);
		break;
	case COL_LECT_DAY:
		if(m_day == NONE)
			str.Empty();
		else
			str.SetString(TheDataMgr.GetDay(m_day));
		break;
	case COL_LECT_PRD:
		if(m_sPrd == NONE && m_ePrd == NONE)
			str.Empty();
		else
			str.Format(_T("%s~%s"), m_sPrd==NONE ? _T("") : TheDataMgr.GetPrd(m_sPrd),
									m_ePrd==NONE ? _T("") : TheDataMgr.GetPrd(m_ePrd));
		break;
	case COL_LECT_GRADE:
		if(m_subj == NULL)
			str.Empty();
		else
			m_subj->GetInString(COL_SUBJ_GRADE, str);
		break;
	case COL_LECT_NOTE:
		str.SetString(m_note);
		break;
	default:
		return CBase::GetInString(col, str);
	}
	return TRUE;
}

BOOL CLect::SetByString(int col, LPCTSTR str)
{
	switch(col)
	{
	case COL_LECT_DAY:
		m_day = TheDataMgr.GetDayIndex(str);
		break;
	case COL_LECT_PRD:
	{
		CString temp(str);
		int pos = temp.Trim().Find(_T('~'));
		if(pos == -1)
			pos = temp.Find(_T(' '));
		if(pos >= 0)
		{
			m_sPrd = TheDataMgr.GetPrdIndex(temp.Left(pos).Trim());
			m_ePrd = TheDataMgr.GetPrdIndex(temp.Mid(pos+1).Trim());
			if(m_sPrd < 0)
				m_sPrd = 0;
			if(m_ePrd < 0)
				m_ePrd = m_sPrd;
			if(m_sPrd > m_ePrd)
			{
				int temp = m_sPrd;
				m_sPrd = m_ePrd;
				m_ePrd = temp;
			}
		}
		else
			m_sPrd = m_ePrd = TheDataMgr.GetPrdIndex(temp.Trim());
	}
		break;
	case COL_LECT_NOTE:
		m_note = AllocCharBuffer(m_note, str);
		break;
	case COL_LECT_SPRD:
		m_sPrd = TheDataMgr.GetPrdIndex(str);
		break;
	case COL_LECT_EPRD:
		m_ePrd = TheDataMgr.GetPrdIndex(str);
		break;
	default:
		return CBase::SetByString(col, str);
	}
	return TRUE;
}

int  CLect::GetInt(int col)
{
	switch(col)
	{
	case COL_LECT_DAY:
		return m_day;
	case COL_LECT_SPRD:
		return m_sPrd;
	case COL_LECT_EPRD:
		return m_ePrd;
	default:
		return CBase::GetInt(col);
	}
}

void CLect::SetInt(int col, int n)
{
	switch(col)
	{
	case COL_LECT_DAY:
		m_day = n;
		break;
	case COL_LECT_SPRD:
		m_sPrd = n;
		break;
	case COL_LECT_EPRD:
		m_ePrd = n;
		break;
	default:
		CBase::SetInt(col, n);
	}
}

void CLect::ToString(CString& str)
{
	// index
	str.Format(_T("%d%c"), GetRow(), PRI_SEPARATOR);
	// subj
	if(m_subj == NULL)
		str += PRI_SEPARATOR;
	else
		str.AppendFormat(_T("%d%c"), m_subj->GetRow(), PRI_SEPARATOR);
	// room
	if(m_room == NULL)
		str += PRI_SEPARATOR;
	else
		str.AppendFormat(_T("%d%c"), m_room->GetRow(), PRI_SEPARATOR);
	// day
	if(m_day == NONE)
		str += PRI_SEPARATOR;
	else
		str.AppendFormat(_T("%d%c"), m_day, PRI_SEPARATOR);
	// prd
	if(m_sPrd != NONE)
		str.AppendFormat(_T("%d"), m_sPrd+1);
	str += _T("~");
	if(m_ePrd != NONE)
		str.AppendFormat(_T("%d"), m_ePrd+1);
	str += PRI_SEPARATOR;
	// grade
	if(m_subj == NULL || m_subj->GetGrade() == NONE)
		str += PRI_SEPARATOR;
	else
		str.AppendFormat(_T("%d%c"), m_subj->GetGrade(), PRI_SEPARATOR);
	// note
	AppendEscString(str, m_note);
	str += END_OF_LINE;
}

void CLect::FromString(const CString& str, int& pos)
{
	CString str1;
	// index
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	int n;
	// subj
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	if(_stscanf_s(str1, _T("%d"), &n) == -1 || n < 0 || CSubj::GetSize() <= n)
		m_subj = NULL;
	else
		CaptureSubj(CSubj::Get(n));
	// room
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	if(_stscanf_s(str1, _T("%d"), &n) != -1 && 0 <= n && n < CRoom::GetSize())
		m_room = CRoom::Get(n);
	else
		m_room = NULL;
	// day
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	if(_stscanf_s(str1, _T("%d"), &m_day) == -1 || m_day < 0 || TheDataMgr.GetNDays() <= m_day)
		m_day = NONE;
	// prds
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	SetByString(COL_LECT_PRD, str1);
	// grade
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	// note
	if(CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		m_note = AllocCharBuffer(m_note, Deescape(str1));
}

// not inherited

BOOL CLect::HasSubj(LPCTSTR name)
{
	return m_subj != NULL && m_subj->HasName(name);
}

void CLect::CaptureSubj(CSubj*subj)
{
	ReleaseSubj();
	m_subj = subj;
	if(subj != NULL) subj->AddLect(this);
}

void CLect::ReleaseSubj()
{
	if(m_subj != NULL)
	{
		m_subj->EraseLect(this);
		m_subj = NULL;
	}
}

BOOL CLect::HasRoom(LPCTSTR name)
{
	return m_room != NULL && m_room->HasName(name);
}

BOOL CLect::Contains(int grade, int day, int prd)
{
	return m_subj != NULL && m_subj->GetGrade()==grade && m_day==day && m_sPrd<=prd && prd<=m_ePrd;
}

BOOL CLect::IsOverlappedWith(CLect* lect)
{
	return m_day == lect->m_day &&
		   (m_sPrd != NONE && lect->m_sPrd != NONE &&
			m_sPrd <= lect->m_ePrd && lect->m_sPrd <= m_ePrd) &&
		   ((m_room != NULL && m_room == lect->m_room) || 
		    (m_subj != NULL && lect->m_subj != NULL && 
		     (m_subj == lect->m_subj ||
			  m_subj->GetGrade() == lect->m_subj->GetGrade() ||
		      (m_subj->GetTeam() != NULL && lect->m_subj->GetTeam() != NULL &&
		       m_subj->GetTeam()->IsOverlappedWith(lect->m_subj->GetTeam())))));
}

BOOL* CLect::Overlap = NULL;

void CLect::PrepareDrag()
{
	Overlap = (BOOL*) realloc(Overlap, TheLects.size()*sizeof(BOOL));
	for(UINT i = 0; i < TheLects.size(); i++)
		Overlap[i] = FALSE;
	int row = GetRow();
	for(UINT i = 1; i < TheLects.size(); i++)
	{
		if(row == i) continue;
		for(UINT j = 0; j < i; j++)
		{
			if(j == row) continue;
			if(CLect::Get(i)->IsOverlappedWith(CLect::Get(j)))
				Overlap[i] = Overlap[j] = TRUE;
		}
	}
}

BOOL CLect::IsOverlappedWith_Drag(CLect* lect)
{
	return m_day == lect->m_day &&
		   (lect->m_sPrd != NONE && m_sPrd <= lect->m_ePrd && lect->m_sPrd <= m_ePrd) &&
		   ((m_room != NULL && m_room == lect->m_room) || 
		    ( m_subj != NULL &&lect->m_subj != NULL &&
		     (m_subj == lect->m_subj ||
			  m_subj->GetGrade() == lect->m_subj->GetGrade() ||
		      (m_subj->GetTeam() != NULL && lect->m_subj->GetTeam() != NULL &&
		       m_subj->GetTeam()->IsOverlappedWith(lect->m_subj->GetTeam())))));
}

void CLect::CheckOverlap_Drag()
{
	int row = GetRow();
	m_overlap = FALSE;
	for(UINT i = 0; i < TheLects.size(); i++)
	{
		if(row == i) continue;
		if(IsOverlappedWith_Drag(CLect::Get(i)))
		{
			CLect::Get(i)->m_overlap = TRUE;
			m_overlap = TRUE;
		}
		else
			CLect::Get(i)->m_overlap = Overlap[i];
	}
}

// static

CLect* CLect::Create()
{
	CLect *lect = new CLect();
	TheLects.push_back(lect);
	return lect;
}

CLect* CLect::Create(CSubj* subj, CRoom* room, int day, int sPrd, int ePrd)
{
	CLect* lect = new CLect();
	lect->m_day = day;
	lect->m_sPrd = sPrd;
	lect->m_ePrd = ePrd;
	lect->m_room = room;
	lect->CaptureSubj(subj);

	TheLects.push_back(lect);

	return lect;
}

void CLect::ClearSubj(CSubj* subj)
{
	for(CVecB::iterator i = TheLects.begin(); i != TheLects.end(); i++)
	{
		if(((CLect*) *i)->m_subj == subj)
			((CLect*) *i)->ReleaseSubj();
	}
}

void CLect::ClearRoom(CRoom* room)
{
	CLect* lect;
	for(CVecB::iterator i = TheLects.begin(); i != TheLects.end(); i++)
	{
		lect = (CLect*) *i;
		if(lect->m_room == room)
			lect->m_room = NULL;
	}
}

void CLect::ClearSubbase(int col, CBase* base)
{
	if(col==COL_LECT_SUBJ)
		ClearSubj((CSubj*) base);
	else if(col == COL_LECT_ROOM)
		ClearRoom((CRoom*) base);
}

void CLect::FullCheckOverlap()
{
	CLect* lect;
	for(CVecB::iterator i = TheLects.begin(); i != TheLects.end(); i++)
	{
		lect = (CLect*) *i;
		lect->m_overlap = FALSE;
		for(CVecB::iterator j = TheLects.begin(); j != i; j++)
			if(lect->IsOverlappedWith((CLect*) *j))
				((CLect*) *j)->m_overlap = lect->m_overlap = TRUE;
	}
}