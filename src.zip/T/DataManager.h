#pragma once

#define N_SECTS		4
#define N_GRADES	4
#define N_DAYS		5
#define N_PRDS		18

//#define STARTOR_HEADER		_T("[STARTOR]")
//#define SEP_HEADER			_T("[SEPARATOR]")
//#define INTSEP_HEADER			_T("[INT SEPARATOR]")
#define VERSION_HEADER_OLD		_T("T VERSION")
#define VERSION_HEADER			_T("[T VERSION]")
#define FILESIZE_HEADER			_T("[FILE SIZE]")
#define SUBTITLE_HEADER			_T("[TABLE NAMES]")
#define NSECTS_HEADER			_T("[NUMBER OF SECTORS]")
#define DAYS_HEADER				_T("[DAYS]")
#define GRADES_HEADER			_T("[GRADES]")
#define PRDS_HEADER				_T("[PERIODS]")
#define TIMES_HEADER			_T("[TIMES]")

#define TABLEWIDTH_HEADER		_T("[HML TABLE WIDTH]")
#define TIMEWIDTH_HEADER		_T("[HML TIME WIDTH]")
#define PRDWIDTH_HEADER			_T("[HML PERIOD WIDTH]")
#define DAYWIDTH_HEADER			_T("[HML DAY WIDTH]")
#define TABLEHEIGHT_HEADER		_T("[HML TABLE HEIGHT]")
#define SECTHEIGHT_HEADER		_T("[HML SECTOR HEIGHT]")
#define DAYHEIGHT_HEADER		_T("[HML DAY HEIGHT]")
#define PRDHEIGHT_HEADER		_T("[HML PERIOD HEIGHT]")

#define FILENAME_HEADER		_T("[FILENAME]")
#define TITLE_HEADER		_T("[TITLE]")
#define INST_HEADER			_T("[����-����]")
#define ROOM_HEADER			_T("[���ǽ�]")
#define TEAM_HEADER			_T("[����-����]")
#define SUBJ_HEADER			_T("[������]")
#define LECT_HEADER			_T("[����]")
//#define EOL					_T("\r\n")
#define EOL					END_OF_LINE
#define SPACE				_T(" ")

#define GRADETABLE_NAME	_T("�г⺰")
#define INSTTABLE_NAME	_T("���纰")
#define ROOMTABLE_NAME	_T("���ǽǺ�")

#define HML_TABLEWIDTH		80156
#define HML_TIMEWIDTH		5924
#define HML_PRDWIDTH		1678
#define HML_DAYWIDTH		3376
#define HML_TABLEHEIGHT		50512
#define HML_SECTHEIGHT		2297
#define HML_DAYHEIGHT		2297
#define HML_PRDHEIGHT		2551


class CDataManager
{
	LPTSTR	m_pathName; // full pathname with filename

	LPTSTR	m_title;	// ����
	LPTSTR* m_days;		// �� ȭ �� �� ��
	LPTSTR* m_times;	// ���� �ð�
	LPTSTR* m_prds;		// 1, 2, 3, ... ����
	LPTSTR* m_grades;	// �г�

	int m_nSects;		// sect ����
	int m_nGrades;		// �г� ��
	int m_nDays;		// �ִ� ���� �� ��
	int m_nPrds;		// ���� �ð� ��

	LPTSTR m_gradeTableName;
	LPTSTR m_instTableName;
	LPTSTR m_roomTableName;

public:
	CDataManager(void);
	~CDataManager(void);
	
	inline LPTSTR GetPathName() {return m_pathName;}
	inline void SetPathName(LPCTSTR pathName) {m_pathName = AllocCharBuffer(m_pathName, pathName);}
	static CString GetFileName();
	static void SetFileName(LPCTSTR filename);

	inline int	GetNSects() {return m_nSects;}
	inline void	SetNSects(int nSects) {m_nSects = nSects;}
	inline int	GetNGrades() {return m_nGrades;}
	inline void SetNGrades(int nGrade) {m_nGrades = nGrade;}
	inline int	GetNDays() {return m_nDays;}
	inline void SetNDays(int nDays) {m_nDays = nDays;}
	inline int	GetNPrds() {return m_nPrds;}
	inline void SetNPrds(int nPrds) {m_nPrds = nPrds;}

	inline LPTSTR GetTitle() {return m_title;}
	inline void SetTitle(LPCTSTR title) {m_title = AllocCharBuffer(m_title, title);}

	inline LPTSTR GetGradeTableName() {return m_gradeTableName;}
	inline LPTSTR GetInstTableName() {return m_instTableName;}
	inline LPTSTR GetRoomTableName() {return m_roomTableName;}

	inline LPTSTR* GetDays() {return m_days;}
	inline LPTSTR GetDay(int n) {return m_days[n];}
	inline LPTSTR* GetTimes() {return m_times;}
	inline LPTSTR GetTime(int n) {return m_times[n];}
	inline LPTSTR* GetPrds() {return m_prds;}
	inline LPTSTR GetPrd(int n) {return m_prds[n];}
	inline LPTSTR* GetGrades() {return m_grades;}
	inline LPTSTR GetGrade(int n) {return m_grades[n];}

	int GetDayIndex(LPCTSTR dayStr);
	int GetPrdIndex(LPCTSTR prdStr);
	int GetGradeIndex(LPCTSTR gradeStr);

	void LoadDefaultCfg();
	int LoadCfg(CStdioFile& file, ULONGLONG initPos = 0);
	CString LoadAll(CStdioFile& file, ULONGLONG initPos = 0);
	void SaveCfg(CFile& file, BOOL comment = TRUE);
	void SaveAll(CFile& file, BOOL comment = TRUE);

	static int FindChar(const CString& str, TCHAR c, int pos = 0);
	static void DeleteBiArray(LPTSTR*& arr, int size);
	static BOOL ReadHeaderedString(CStdioFile& file, CString &str, LPCTSTR header);
	static void WriteAsMbs(CFile& file, LPCTSTR wcsStr);
	static void BuildBiArray(const CString& str, TCHAR sep, int& n, LPTSTR*& data);
	static BOOL GetSeparatedString(const CString& src, TCHAR sep, int& pos, CString& dst);



	void LoadTestData();
};

extern CDataManager TheDataMgr;