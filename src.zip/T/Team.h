#pragma once

class CTeam : public CBase
{
	BOOL	m_group;
	DWORD	m_color;
	LPTSTR	m_name;	// ���簡 1���̸� m_name = m_inst[0].m_name�� ����.
	LPTSTR	m_note;
	vector<CInst*> m_inst;

	static int IndexForNew;

	CTeam(LPCTSTR name = NULL);
public:
	~CTeam(void);

	//inherited from CBase

	int GetRow();

	BOOL GetInString(int col, CString &str);
	BOOL SetByString(int col, LPCTSTR str);

	void ToString(CString& str);
	void FromString(const CString& str, int& pos);

	// not inherited

	inline BOOL HasVName(const CString& str) {return GetVName() != NULL && str.Compare(GetVName()) == 0;}
	inline LPTSTR GetVName() {return m_group ? m_name : m_inst[0]->GetName();}
	inline void SetVName(LPCTSTR name) {if(m_group) SetName(name); else m_inst[0]->SetName(name);}

	inline LPTSTR GetVNote() {return m_group ? m_note : m_inst[0]->GetNote();}
	inline void SetVNote(LPCTSTR note) {if(m_group) SetNote(note); else m_inst[0]->SetNote(note);}

	inline BOOL& IsGroup() {return m_group;}
	inline void SetGroup(BOOL group) {m_group = group;}
	void GroupToSingle();
	void SingleToGroup();

	inline BOOL HasName(const CString& str) {return m_name != NULL && str.Compare(m_name) == 0;}
	inline LPTSTR GetName() {return m_name;}
	inline void SetName(LPCTSTR name) {m_name = AllocCharBuffer(m_name, name);}

	inline LPTSTR GetNote() {return m_note;}
	inline void SetNote(LPCTSTR note) {m_note = AllocCharBuffer(m_note, note);}

	inline void  SetColor(DWORD color) {m_color = color;}
	inline DWORD GetColor() {return m_color;}

	BOOL HasInst(const CInst* inst);
	inline int GetInstSize() {return m_inst.size();}
	int GetInstIndex(CInst* inst);
	CInst* GetInst(int index);
	CInst* GetInst(LPCTSTR name);
	inline void AddInst(CInst* inst) {if(inst != NULL && !HasInst(inst)) m_inst.push_back(inst);}
	void EraseInst(CInst* inst);
	void EraseInst(int index);
	inline void EraseAllInsts() {m_inst.clear();}

	BOOL IsOverlappedWith(CTeam* team);

	//static
	
	inline static int GetSize() {return (int) TheTeams.size();}

	static int GetRow(LPCTSTR name);

	static CTeam* Create(LPCTSTR = NULL);
	// CTeam�� CreateWithInst�� team�� inst�� �����ϰ� inst�� team�� m_inst�� ����Ѵ�.
	static CTeam* CreateWithInst(LPCTSTR = NULL);
	// ���ο� �̸��� �����ϰ� �� �̸����� CreateWithInst(�̸�) ȣ��
	static CTeam* CreateForDlg();

	inline static CTeam* Get(int row) {return (CTeam*) TheTeams[row];}
	static CTeam* Get(LPCTSTR name);

	inline static void Exchange(int row0, int row1) {TheTeams.Exchange(row0, row1);}

	inline static void Delete(CTeam* team) {TheTeams.Delete(team);}
	inline static void Delete(int row) {TheTeams.Delete(row);}

	inline static void Clear() {TheTeams.Clear();}

	inline static BOOL GetInString(int row, int col, CString &str) {return Get(row)->GetInString(col, str);}
	inline static BOOL SetByString(int row, int col, LPCTSTR  str) {return Get(row)->SetByString(col, str);}

	// TheTeams�� base�� group�� ��� ��� inst�� �����Ѵ�.
	static void ClearInst(CInst* inst);
	inline static void ClearSubbase(int col, CBase* base) {if(col == COL_TEAM_INST) ClearInst((CInst*)base);}

	inline static void ConvertToString(CString& str) {TheTeams.ConvertToString(str);}
	inline static void BuildFromString(const CString& str) {TheTeams.BuildFromString(str);}

	static void DetermineIndexForNew();
};
