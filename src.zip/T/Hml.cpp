#include "StdAfx.h"

#include "Base.h"
#include "Room.h"
#include "Inst.h"
#include "Team.h"
#include "Lect.h"
#include "Subj.h"

#include "TTable.h"

#include "DataManager.h"
#include "T.h"
#include "Hml.h"
/*
#define HML_TABLEWIDTH		80156
#define HML_TIMEWIDTH		5924
#define HML_PRDWIDTH		1678
#define HML_DAYWIDTH		3376
#define HML_TABLEHEIGHT		50512
#define HML_SECTHEIGHT		2297
#define HML_DAYHEIGHT		2297
#define HML_PRDHEIGHT		2551
*/
int CHml::Sizes[];

CHml::CHml(void)
{
}

CHml::~CHml(void)
{
}

void CHml::GetUsedColors(vector<DWORD>& colors)
{
	colors.push_back(CTTable::DefaultColor);
	colors.push_back(CTTable::OverlapColor);
	BOOL insert;
	for(int i=0; i<CTeam::GetSize(); i++)
	{
		insert = TRUE;
		DWORD color = CTeam::Get(i)->GetColor();
		for(vector<DWORD>::iterator iter = colors.begin(); iter != colors.end(); iter++)
		{
			if(color == *iter)
			{
				insert = FALSE;
				break;
			}
		}
		if(insert)
			colors.push_back(color);
	}
}

void CHml::WriteUTF8ByteOrderMark(CFile& file)
{
	char bom[3] = {(char)0xEF, (char)0xBB, (char)0xBF};
	file.Write(bom, 3);
}

void CHml::WriteAsUTF8(CFile& file, const CStringW& str)
{
	CStringA utf8;
	int n = ::WideCharToMultiByte(CP_UTF8, 0, str, -1, NULL, 0, NULL, NULL);
	::WideCharToMultiByte(CP_UTF8, 0, str, -1, utf8.GetBuffer(n-1), n, NULL, NULL);
	utf8.ReleaseBuffer(--n);
	file.Write(utf8, n);
}

#ifdef _DEBUG
int CHml::ReadAsUTF8(CFile& file, CStringW& wcsStr)
{
	CStringA utf8;
	int n = file.Read(utf8.GetBuffer(BUFSIZ), BUFSIZ);
	utf8.ReleaseBuffer(n);
	n = ::MultiByteToWideChar(CP_UTF8, 0, utf8, -1, NULL, 0);
	::MultiByteToWideChar(CP_UTF8, 0, utf8, -1, wcsStr.GetBuffer(n-1), n);
	wcsStr.ReleaseBuffer(--n);
	return n;
}

void CHml::WriteAsChar(CFile& file, const char* str)
{
	file.Write(str, strlen(str));
}

void CHml::WideCharToUTF8(LPCTSTR src, CStringA& dst)
{
	int n = ::WideCharToMultiByte(CP_UTF8, 0, src, -1, NULL, 0, NULL, NULL);
	::WideCharToMultiByte(CP_UTF8, 0, src, -1, dst.GetBuffer(n-1), n, NULL, NULL);
	dst.ReleaseBuffer(n-1);
}

void CHml::UTF8ToWideChar(LPCSTR src, CStringW& dst)
{
	int n = ::MultiByteToWideChar(CP_UTF8, 0, src, -1, NULL, 0);
	::MultiByteToWideChar(CP_UTF8, 0, src, -1, dst.GetBuffer(n-1), n);
	dst.ReleaseBuffer(n-1);
}
#endif

CString& CHml::GetTime(CString& str)
{
	CTime t = CTime::GetCurrentTime();
	LPCTSTR s[] = {_T("��"), _T("��"), _T("ȭ"), _T("��"), _T("��"), _T("��"), _T("��")};
	str.Format(_T("%4d�� %02d�� %02d�� %s���� "), t.GetYear(), t.GetMonth(), t.GetDay(), s[t.GetDayOfWeek()-1]);
	int n = t.GetHour();
	if(n <= 12)
		str.AppendFormat(_T("���� %02d:%02d:%02d"), n, t.GetMinute(), t.GetSecond());
	else
		str.AppendFormat(_T("���� %02d:%02d:%02d"), n-12, t.GetMinute(), t.GetSecond());
	return str;
}

CString& CHml::GetLang(int n, CString& str)
{
	LPCTSTR s[] = {_T("Hangul"), _T("Latin"), _T("Hanja"), _T("Japanese"), _T("Other"), _T("Symbol"), _T("User")};
	str = s[n];
	return str;
}

#define WU(x)		WriteAsUTF8(file, _T(x))

void CHml::WriteFirstPageHeader(CFile& file)
{
	WU("<SECDEF CharGrid=\"0\" FirstBorder=\"false\" FirstFill=\"false\" LineGrid=\"0\" OutlineShape=\"1\" SpaceColumns=\"1134\" TabStop=\"8000\" TextDirection=\"0\" TextVerticalWidthHead=\"0\">");
	WU("<STARTNUMBER Equation=\"0\" Figure=\"0\" Page=\"0\" PageStartsOn=\"Both\" Table=\"0\"/><HIDE Border=\"false\" EmptyLine=\"false\" Fill=\"false\" Footer=\"false\" Header=\"false\" MasterPage=\"false\" PageNumPos=\"false\"/>");
	WU("<PAGEDEF GutterType=\"LeftOnly\" Height=\"84188\" Landscape=\"1\" Width=\"59528\"><PAGEMARGIN Bottom=\"2835\" Footer=\"0\" Gutter=\"0\" Header=\"0\" Left=\"1417\" Right=\"1417\" Top=\"2835\"/></PAGEDEF><FOOTNOTESHAPE>");
	WU("<AUTONUMFORMAT Superscript=\"false\" Type=\"Digit\"/><NOTELINE Color=\"321326\" Length=\"0\" Type=\"None\" Width=\"0.1mm\"/><NOTESPACING AboveLine=\"0\" BelowLine=\"0\" BetweenNotes=\"0\"/><NOTENUMBERING NewNumber=\"1\" Type=\"Continuous\"/>");
	WU("<NOTEPLACEMENT BeneathText=\"false\" Place=\"EachColumn\"/></FOOTNOTESHAPE><ENDNOTESHAPE><AUTONUMFORMAT Superscript=\"false\" Type=\"Digit\"/><NOTELINE Length=\"0\" Type=\"None\" Width=\"0.1mm\"/>");
	WU("<NOTESPACING AboveLine=\"0\" BelowLine=\"0\" BetweenNotes=\"0\"/><NOTENUMBERING NewNumber=\"1\" Type=\"Continuous\"/><NOTEPLACEMENT BeneathText=\"false\" Place=\"EndOfDocument\"/></ENDNOTESHAPE>");
	CString str1 = _T("<PAGEBORDERFILL FillArea=\"Paper\" FooterInside=\"false\" HeaderInside=\"false\" TextBorder=\"true\" Type=\"%s\"><PAGEOFFSET Bottom=\"1417\" Left=\"1417\" Right=\"1417\" Top=\"1417\"/></PAGEBORDERFILL>");
	CString str0;
	for(int i=0; i<3; i++)
	{
		str0.Format(str1, i==0 ? _T("Both") : i==1 ? _T("Even") : _T("Odd"));
		WriteAsUTF8(file, str0);
	}
	WU("</SECDEF><COLDEF Count=\"1\" Layout=\"Left\" SameGap=\"0\" SameSize=\"true\" Type=\"Newspaper\"/>");
}

void CHml::ExportAsHml(LPCTSTR pathName)
{
	CFile file(pathName, CFile::modeCreate | CFile::modeWrite);
	WriteUTF8ByteOrderMark(file);
	WU("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\" ?><HWPML Style=\"embed\" SubVersion=\"7.0.0.0\" Version=\"2.7\"><HEAD SecCnt=\"1\"><DOCSUMMARY>");
	CString str0, str1;
	str0.Format(_T("<TITLE>%s</TITLE><AUTHOR>T ver. %s</AUTHOR><DATE>%s</DATE></DOCSUMMARY>"), TheDataMgr.GetTitle(), VERSION, GetTime(str1));
	WriteAsUTF8(file, str0);
	WU("<DOCSETTING><BEGINNUMBER Endnote=\"1\" Equation=\"1\" Footnote=\"1\" Page=\"1\" Picture=\"1\" Table=\"1\"/><CARETPOS List=\"0\" Para=\"0\" Pos=\"35\"/></DOCSETTING><MAPPINGTABLE><FACENAMELIST>");
	for(int i=0; i<7; i++)
	{
		str0.Format(_T("<FONTFACE Count=\"1\" Lang=\"%s\">"), GetLang(i, str1));
		WriteAsUTF8(file, str0);
		WU("<FONT Id=\"0\" Name=\"����\" Type=\"ttf\"><TYPEINFO ArmStyle=\"1\" Contrast=\"0\" FamilyType=\"2\" Letterform=\"1\" Midline=\"1\" Proportion=\"0\" StrokeVariation=\"1\" Weight=\"6\" XHeight=\"1\"/></FONT></FONTFACE>");
	}
	WU("</FACENAMELIST>");

	vector<DWORD> colors;
	GetUsedColors(colors);
	str0.Format(_T("<BORDERFILLLIST Count=\"%d\">"), colors.size()+18);
	WriteAsUTF8(file, str0);
	// str1 input Id
	str1 = _T("<BORDERFILL Id=\"%d\" BackSlash=\"0\" BreakCellSeparateLine=\"0\" CenterLine=\"0\" CounterBackSlash=\"0\" CounterSlash=\"0\" CrookedSlash=\"0\" Shadow=\"false\" Slash=\"0\" ThreeD=\"false\">");
	// str2 input LEFTBORDER Width, RIGHTBORDER Width, TOPBORDER Width, BOTTOMBORDER Width
	CString str2 = _T("<LEFTBORDER Type=\"None\" Width=\"0.%dmm\"/><RIGHTBORDER Type=\"None\" Width=\"0.%dmm\"/><TOPBORDER Type=\"None\" Width=\"0.%dmm\"/><BOTTOMBORDER Type=\"None\" Width=\"0.%dmm\"/><DIAGONAL Type=\"Solid\" Width=\"0.1mm\"/>");
	// 4294967295 = (255, 255, 255, 255)
	CString str3 = _T("<FILLBRUSH><WINDOWBRUSH Alpha=\"0\" FaceColor=\"4294967295\" HatchColor=\"0\"/></FILLBRUSH>");
	CString str4 = _T("</BORDERFILL>");
	str0.Format(str1, 1);
	WriteAsUTF8(file, str0);
	str0.Format(str2, 1, 1, 1, 1);
	WriteAsUTF8(file, str0);
	WriteAsUTF8(file, str3+str4);
	str2.Replace(_T("None"), _T("Solid"));
	for(int i=0; i<16; i++)
	{
		str0.Format(str1, i+2);
		WriteAsUTF8(file, str0);
		str0.Format(str2+str4, i&HML_LEFTBORDER ? 4:12, i&HML_RIGHTBORDER ? 4:12, i&HML_TOPBORDER ? 4:12, i&HML_BOTTOMBORDER ? 4:12);
		WriteAsUTF8(file, str0);
	}
	// colored cells
	str2.Replace(_T("%d"), _T("4"));
	str3.Replace(_T("4294967295"), _T("%d"));
	str3 += str4;
	for(UINT i=0; i<colors.size(); i++)
	{
		str0.Format(str1, i+18);
		WriteAsUTF8(file, str0);
		WriteAsUTF8(file, str2);
		str0.Format(str3, colors[i]);
		WriteAsUTF8(file, str0);
	}
	// �밢��
	str0.Format(str1, colors.size()+18);
	str0.Replace(_T(" BackSlash=\"0\""), _T(" BackSlash=\"2\""));
	WriteAsUTF8(file, str0);
	str2.Replace(_T("1"), _T("12"));
	WriteAsUTF8(file, str2 + str4);
	WU("</BORDERFILLLIST><CHARSHAPELIST Count=\"5\">");
	// input Id, Height/100
	str1 = _T("<CHARSHAPE Id=\"%d\" Height=\"%d00\" BorderFillId=\"0\" ShadeColor=\"4294967295\" SymMark=\"0\" TextColor=\"0\" UseFontSpace=\"false\" UseKerning=\"false\">");
	str2 = _T("<CHAROFFSET Hangul=\"0\" Hanja=\"0\" Japanese=\"0\" Latin=\"0\" Other=\"0\" Symbol=\"0\" User=\"0\"/>%s</CHARSHAPE>");
	for(int i=0; i<5; i++)
	{
		str0.Format(str1, i, (i==0 || i == 1) ? 8 : (i==2 || i== 3) ? 16 : 10);
		WriteAsUTF8(file, str0);
		WU("<FONTID Hangul=\"0\" Hanja=\"0\" Japanese=\"0\" Latin=\"0\" Other=\"0\" Symbol=\"0\" User=\"0\"/><RATIO Hangul=\"100\" Hanja=\"100\" Japanese=\"100\" Latin=\"100\" Other=\"100\" Symbol=\"100\" User=\"100\"/>");
		WU("<CHARSPACING Hangul=\"0\" Hanja=\"0\" Japanese=\"0\" Latin=\"0\" Other=\"0\" Symbol=\"0\" User=\"0\"/><RELSIZE Hangul=\"100\" Hanja=\"100\" Japanese=\"100\" Latin=\"100\" Other=\"100\" Symbol=\"100\" User=\"100\"/>");
		str0.Format(str2, i%2 ? _T("<BOLD/>") : _T(""));
		WriteAsUTF8(file, str0);
	}
	WU("</CHARSHAPELIST><TABDEFLIST Count=\"1\"><TABDEF AutoTabLeft=\"false\" AutoTabRight=\"false\" Id=\"0\"/></TABDEFLIST><NUMBERINGLIST Count=\"1\"><NUMBERING Id=\"1\" Start=\"0\">");
	// input Level
	str1 = _T("<PARAHEAD Alignment=\"Left\" AutoIndent=\"false\" Level=\"%d\" NumFormat=\"Digit\" TextOffset=\"0\" TextOffsetType=\"percent\" UseInstWidth=\"false\" WidthAdjust=\"0\"></PARAHEAD>");
	for(int i=1; i<=7; i++)
	{
		str0.Format(str1, i);
		WriteAsUTF8(file, str0);
	}
	WU("</NUMBERING></NUMBERINGLIST><PARASHAPELIST Count=\"1\"><PARASHAPE Align=\"Center\" BreakLatinWord=\"KeepWord\" BreakNonLatinWord=\"false\" Condense=\"0\" FontLineHeight=\"false\" HeadingType=\"None\" Id=\"0\" KeepLines=\"false\" ");
	WU("KeepWithNext=\"false\" Level=\"0\" LineWrap=\"Break\" PageBreakBefore=\"false\" SnapToGrid=\"false\" TabDef=\"0\" VerAlign=\"Baseline\" WidowOrphan=\"false\">");
	WU("<PARAMARGIN Indent=\"0\" Left=\"0\" LineSpacing=\"160\" LineSpacingType=\"Percent\" Next=\"0\" Prev=\"0\" Right=\"0\"/><PARABORDER BorderFill=\"1\" Connect=\"false\" IgnoreMargin=\"false\"/></PARASHAPE></PARASHAPELIST>");
	WU("<STYLELIST Count=\"1\"><STYLE CharShape=\"0\" EngName=\"Normal\" Id=\"0\" LangId=\"1042\" LockForm=\"0\" Name=\"������\" NextStyle=\"0\" ParaShape=\"0\" Type=\"Para\"/></STYLELIST></MAPPINGTABLE></HEAD>");
	WU("<BODY><SECTION Id=\"0\">");

	for(UINT i = 0; i < theApp.Tables.size(); i++)
	{
		theApp.Tables[i]->ExportAsHml(file, colors, i==0);
	}
	WU("</SECTION></BODY></HWPML>");
	file.Close();
}

