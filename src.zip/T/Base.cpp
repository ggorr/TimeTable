#include "StdAfx.h"
#include "Base.h"
#include "Inst.h"
#include "Team.h"
#include "Room.h"
#include "Subj.h"
#include "Lect.h"

CVecB TheRooms(TYPE_ROOM);
CVecB TheInsts(TYPE_INST);
CVecB TheTeams(TYPE_TEAM);
CVecB TheLects(TYPE_LECT);
CVecB TheSubjs(TYPE_SUBJ);

CVecB::CVecB(int type)
{
	m_type = type;
}

CVecB::~CVecB()
{
	for(iterator iter = begin(); iter != end(); iter++)
		delete *iter;
}

int CVecB::GetRow(const CBase *base)
{
	for(UINT i = 0; i < size(); i++)
		if(base == *(begin()+i))
			return (int) i;
	return ROW_NONE;
}

BOOL CVecB::Contains(const CBase* base)
{
	for(iterator i = begin(); i != end(); i++)
		if(base == *i)
			return TRUE;
	return FALSE;
}

void CVecB::Exchange(int row0, int row1)
{
	CBase* base = *(begin() + row0);
	*(begin() + row0) = *(begin() + row1);
	*(begin() + row1) = base;
}

CBase* CVecB::CreateBase()
{
	switch(m_type)
	{
	case TYPE_INST:
		return CInst::Create();
	case TYPE_TEAM:
		return CTeam::Create();
	case TYPE_ROOM:
		return CRoom::Create();
	case TYPE_SUBJ:
		return CSubj::Create();
	case TYPE_LECT:
		return CLect::Create();
	default:
		return NULL;
	}
}

CBase* CVecB::CreateBaseForDlg()
{
	switch(m_type)
	{
	case TYPE_INST:
		return CInst::CreateForDlg();
	case TYPE_TEAM:
		return CTeam::CreateForDlg();
	case TYPE_ROOM:
		return CRoom::CreateForDlg();
	case TYPE_SUBJ:
		return CSubj::CreateForDlg();
	case TYPE_LECT:
		return CLect::CreateForDlg();
	default:
		return NULL;
	}
}
// Delete means erase base from vector and delete it
void CVecB::Delete(CBase* base)
{
	for(iterator iter = begin(); iter != end(); iter++)
	{
		if(*iter == base)
		{
			delete base;
			erase(iter);
			return;
		}
	}
}
// Delete means erase base from vector and delete it
void CVecB::Delete(int row)
{
	ASSERT(0 <= row && row < (int) size());
	delete *(begin() + row);
	erase(begin()+row);
}

void CVecB::Clear()
{
	for(iterator i = begin(); i != end(); i++)
		delete *i;
	clear();
}

void CVecB::ClearSubbase(int col, CBase* base)
{
	switch(m_type)
	{
	case TYPE_TEAM:
		return CTeam::ClearSubbase(col, base);
	case TYPE_SUBJ:
		return CSubj::ClearSubbase(col, base);
	case TYPE_LECT:
		return CLect::ClearSubbase(col, base);
	}
}

void CVecB::ConvertToString(CString& str)
{
	str.Empty();
	CString str1;
	for(int i = 0; i < GetSize(); i++)
	{
		Get(i)->ToString(str1);
		str += str1;
	}
}

void CVecB::BuildFromString(const CString& str)
{
	int len = str.GetLength();
	int pos = 0;
	while(pos != -1 && pos != len)
		CreateBase()->FromString(str, pos);
}
