// GradeTable.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "T.h"

#include "Base.h"
#include "Inst.h"
#include "Team.h"
#include "Room.h"
#include "Subj.h"
#include "Lect.h"

#include "TTable.h"
#include "GradeTable.h"

#include "DataManager.h"

// CGradeTable

IMPLEMENT_DYNCREATE(CGradeTable, CTTable)

CGradeTable::CGradeTable()
{
}

CGradeTable::~CGradeTable()
{
}

BEGIN_MESSAGE_MAP(CGradeTable, CTTable)
END_MESSAGE_MAP()

// CGradeTable �����Դϴ�.

#ifdef _DEBUG
void CGradeTable::AssertValid() const
{
	CTTable::AssertValid();
}

#ifndef _WIN32_WCE
void CGradeTable::Dump(CDumpContext& dc) const
{
	CTTable::Dump(dc);
}
#endif
#endif //_DEBUG

void CGradeTable::Initialize()
{
	m_name = AllocCharBuffer(m_name, TheDataMgr.GetGradeTableName());
	m_sectTitles.clear();
	m_lects.clear();
	for(int i = m_order*TheDataMgr.GetNSects(); i < (m_order+1)*TheDataMgr.GetNSects(); i++)
	{
		if(i < TheDataMgr.GetNGrades())
		{
			m_sectTitles.push_back(TheDataMgr.GetGrade(i));
			vector<CLect*> lects;
			for(int j=0; j<TheLects.GetSize(); j++)
			{
				CLect* lect = CLect::Get(j);
				if(lect->GetSubj() != NULL && lect->GetSubj()->GetGrade() == i &&
					lect->GetDay() != NONE && lect->GetSPrd() != NONE && lect->GetEPrd() != NONE)
					lects.push_back(lect);
			}
			m_lects.push_back(lects);
		}
		else
			break;
	}
	m_nValidSects = (int) m_sectTitles.size();
}

void CGradeTable::GetLectString(CLect* lect, CString& str)
{
	CString strTemp;
	CSubj* subj = lect->GetSubj();
	subj->GetInString(COL_THIS, str);
	if(subj->GetTeam() == NULL)
	{
		if(lect->GetRoom() != NULL)
		{
			str.Append(_T("\n()\n"));
			lect->GetRoom()->GetInString(COL_THIS, strTemp);
			str.Append(strTemp);
		}
	}
	else
	{
		subj->GetInString(COL_SUBJ_TEAM, strTemp);
		str.Append(_T("\n(") + strTemp + _T(")"));
		if(lect->GetRoom() != NULL)
		{
			lect->GetRoom()->GetInString(COL_THIS, strTemp);
			str.Append(_T("\n") + strTemp);
		}
	}
}

void CGradeTable::GetHmlLectString(CString& str, CString& format, CLect* lect)
{
	CString strTemp;
	CSubj* subj = lect->GetSubj();
	subj->GetInString(COL_THIS, strTemp);
	str.Format(format, 1, strTemp);
	if(subj->GetTeam() == NULL)
	{
		if(lect->GetRoom() != NULL)
		{
			str.AppendFormat(format, 1, _T("()"));
			lect->GetRoom()->GetInString(COL_THIS, strTemp);
			str.AppendFormat(format, 1, strTemp);
		}
	}
	else
	{
		subj->GetInString(COL_SUBJ_TEAM, strTemp);
		str.AppendFormat(format,1,  _T("(") + strTemp + _T(")"));
		if(lect->GetRoom() != NULL)
		{
			lect->GetRoom()->GetInString(COL_THIS, strTemp);
			str.AppendFormat(format, 1, strTemp);
		}
	}
}