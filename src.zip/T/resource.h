//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// T.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDC_DELETE                      3
#define IDOK2                           3
#define IDC_ADD                         4
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_TTYPE                       130
#define ID_WINDOW_MANAGER               131
#define IDR_TABLE                       131
#define IDS_WINDOWS_MANAGER             132
#define IDR_TEAMLIST                    133
#define IDR_ROOMLIST                    134
#define IDR_THEME_MENU                  200
#define ID_SET_STYLE                    201
#define ID_VIEW_APPLOOK_WIN_2000        210
#define ID_VIEW_APPLOOK_OFF_XP          211
#define ID_VIEW_APPLOOK_WIN_XP          212
#define ID_VIEW_APPLOOK_OFF_2003        213
#define ID_VIEW_APPLOOK_VS_2005         214
#define ID_VIEW_APPLOOK_OFF_2007_BLUE   215
#define ID_VIEW_APPLOOK_OFF_2007_BLACK  216
#define ID_VIEW_APPLOOK_OFF_2007_SILVER 217
#define ID_VIEW_APPLOOK_OFF_2007_AQUA   218
#define IDS_EDIT_MENU                   306
#define IDC_TABLE_ADD                   311
#define IDD_BASE                        312
#define IDD_TDIALOG                     316
#define IDD_REVISE_TITLE                316
#define IDC_CURSORSIZENS                317
#define IDC_COMBO                       318
#define IDC_EDIT                        319
#define IDD_LOG                         322
#define IDC_LIST                        1000
#define IDC_EXIT                        1002
#define IDC_SELECT                      1009
#define IDC_REVISE_TITLE_EDIT           1021
#define IDC_STATIC_VER                  1022
#define IDC_STATIC_COPYRIGHT            1024
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_TABLE_GRADE                  32774
#define ID_LIST_TEAM                    32775
#define ID_LIST_ROOM                    32776
#define ID_32777                        32777
#define ID_LIST_LECT                    32778
#define ID_LIST_SUBJ                    32779
#define ID_32780                        32780
#define ID_LECT                         32781
#define ID_32782                        32782
#define ID_LIST_INST                    32783
#define ID_FILESAVE                     32784
#define ID_FILEOPEN                     32785
#define ID_FILESAVEAS                   32786
#define ID_FILENEW                      32787
#define ID_FILE_OPEN_TSV                32788
#define ID_FILE_SAVE_TSV                32789
#define ID_FILE_SAVE_AS_TSV             32790
#define ID_32795                        32795
#define ID_TABLE_INST                   32796
#define ID_32797                        32797
#define ID_TABLE_TEST                   32798
#define ID_TEST_TEST                    32799
#define ID_FILE_NEW_TSV                 32802
#define ID_32803                        32803
#define ID_                             32804
#define ID_REVISE_TITLE                 32805
#define ID_32806                        32806
#define ID_FILE_HML                     32807
#define ID_ACCELERATOR32808             32808
#define ID_32820                        32820
#define ID_FILE_SAVE_CFG                32821
#define ID_32822                        32822
#define ID_FILE_OLD_LIST                32823
#define ID_FILE_LOG_LIST                32824
#define ID_32825                        32825
#define ID_32826                        32826

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        324
#define _APS_NEXT_COMMAND_VALUE         32827
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           320
#endif
#endif
