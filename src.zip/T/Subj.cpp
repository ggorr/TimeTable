#include "StdAfx.h"
#include "T.h"
#include "Base.h"
#include "Inst.h"
#include "Team.h"
#include "Lect.h"
#include "Subj.h"

#include "DataManager.h"

#define NEW_NAME_FORMAT	_T("�� ������ %d")

int CSubj::IndexForNew = 0;

CSubj::CSubj(LPCTSTR name)
{
	m_id = NULL;
	m_grade = NONE;
	m_name = AllocCharBuffer(NULL, name);
	m_team = NULL;
	m_note = NULL;
}

CSubj::~CSubj()
{
	if(m_id != NULL)
		free(m_id);
	if(m_name != NULL)
		free(m_name);
	if(m_note != NULL)
		free(m_note);
}

// inherited from CBase

int CSubj::GetRow()
{
	return TheSubjs.GetRow(this);
}

BOOL CSubj::GetInString(int col, CString &str)
{
	switch(col)
	{
	case COL_INDEX:
		str.Format(_T("%d"), GetRow());
		break;
	case COL_THIS:
		str.SetString(m_name);
		break;
	case COL_SUBJ_ID:
		str.SetString(m_id);
		break;
	case COL_SUBJ_NAME:
		str.SetString(m_name);
		break;
	case COL_SUBJ_GRADE:
		if(m_grade == NONE)
			str.Empty();
		else
			str.SetString(TheDataMgr.GetGrade(m_grade));
		break;
	case COL_SUBJ_NPRDS:
		str.Format(_T("%d"), GetNPrds());
		break;
	case COL_SUBJ_TEAM:
		if(m_team == NULL)
			str.Empty();
		else
			m_team->GetInString(COL_THIS, str);
		break;
	case COL_SUBJ_LECT:
		if(m_lect.size() == 0)
			str.Empty();
		else
		{
			vector<CLect*>::iterator i = m_lect.begin();
			(*i)->GetInString(COL_INDEX, str);
			CString temp;
			for(i++; i != m_lect.end(); i++)
			{
				str.Append(_T(", "));
				(*i)->GetInString(COL_INDEX, temp);
				str.Append(temp);
			}
		}
		break;
	case COL_SUBJ_NOTE:
		str.SetString(m_note);
		break;
	default:
		return CBase::GetInString(col, str);
	}
	return TRUE;
}

BOOL CSubj::SetByString(int col, LPCTSTR str)
{
	switch(col)
	{
	case COL_SUBJ_ID:
		m_id = AllocCharBuffer(m_id, str);
		break;
	case COL_SUBJ_NAME:
		m_name = AllocCharBuffer(m_name, str);
		break;
	case COL_SUBJ_GRADE:
		m_grade = TheDataMgr.GetGradeIndex(str);
		break;
	case COL_SUBJ_NOTE:
		m_note = AllocCharBuffer(m_note, str);
		break;
	default:
		return CBase::SetByString(col, str);
	}
	return TRUE;
}

int  CSubj::GetInt(int col) 
{
	if(col == COL_SUBJ_GRADE)
		return m_grade;
	else
		return CBase::GetInt(col);
}

void CSubj::SetInt(int col, int n)
{
	if(col == COL_SUBJ_GRADE)
		m_grade = n;
	else
		CBase::SetInt(col, n);
}

void CSubj::ToString(CString& str)
{
	// index
	str.Format(_T("%d%c"), GetRow(), PRI_SEPARATOR);
	// id
	AppendEscString(str, m_id);
	// name
	AppendEscString(str, m_name);
	// grade
	if(m_grade == NONE)
		str += PRI_SEPARATOR;
	else
		str.AppendFormat(_T("%d%c"), m_grade, PRI_SEPARATOR);
	// team
	if(m_team == NULL)
		str += PRI_SEPARATOR;
	else
		str.AppendFormat(_T("%d%c"), m_team->GetRow(), PRI_SEPARATOR);
	// lect
	for(int i = 0; i < GetLectSize(); i++)
		str.AppendFormat(_T("%d%c"), m_lect[i]->GetRow(), SEC_SEPARATOR);
	str += PRI_SEPARATOR;
	// nprds
	str.AppendFormat(_T("%d%c"), GetNPrds(), PRI_SEPARATOR);
	// note
	AppendEscString(str, m_note);
	str += END_OF_LINE;
}

void CSubj::FromString(const CString& str, int& pos)
{
	CString str1;
	// index
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	// id
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	m_id = AllocCharBuffer(m_id, Deescape(str1));
	// name
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	m_name = AllocCharBuffer(m_name, Deescape(str1));
	// grade
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	if(_stscanf_s(str1, _T("%d"), &m_grade) == -1 || m_grade < 0 || TheDataMgr.GetNGrades() <= m_grade)
		m_grade = NONE;
	// team
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	int row;
	if(_stscanf_s(str1, _T("%d"), &row) == -1 || row < 0 || CTeam::GetSize() <= row)
		m_team = NULL;
	else
		m_team = CTeam::Get(row);
	// lect
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	int pos1 = 0;
	while(true)
	{
		CString str2;
		if(!CDataManager::GetSeparatedString(str1, SEC_SEPARATOR, pos1, str2))
			break;
		if(_stscanf_s(str2, _T("%d"), &row) != -1 && 0 <= row && row < CLect::GetSize())
			CaptureLect(CLect::Get(row));
	}
	// nprds
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	// note
	if(CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		m_note = AllocCharBuffer(m_note, Deescape(str1));
}

// not inherited

BOOL CSubj::HasLect(CLect* lect)
{
	for(vector<CLect*>::iterator iter = m_lect.begin(); iter != m_lect.end(); iter++)
		if(lect == *iter)
			return TRUE;
	return FALSE;
}

int CSubj::GetNPrds()
{
	int nPrds = 0;
	for(vector<CLect*>::iterator i = m_lect.begin(); i != m_lect.end(); i++)
	{

		if(((CLect*) *i)->GetSPrd() != NONE && ((CLect*) *i)->GetEPrd() != NONE)
			nPrds += ((CLect*) *i)->GetEPrd() - ((CLect*) *i)->GetSPrd() + 1;
	}
	return nPrds;
}

BOOL CSubj::HasTeam(LPCTSTR name)
{
	return m_team != NULL && m_team->HasName(name);
}

int CSubj::GetLectIndex(CLect* lect)
{
	for(UINT i = 0; i < m_lect.size(); i++)
		if(lect == m_lect[i])
			return (int) i;
	return NONE;
}

void CSubj::EraseLect(CLect* lect)
{
	for(vector<CLect*>::iterator iter = m_lect.begin(); iter != m_lect.end(); iter++)
		if(lect == *iter)
		{
			m_lect.erase(iter);
			return;
		}
}

// lect�� �����Ѵ�. lect->m_subj == this, this->m_lect = subj;
void CSubj::CaptureLect(CLect* lect)
{
	lect->ReleaseSubj();
	lect->SetSubj(this);
	AddLect(lect);
}

// lect�� ���踦 û���Ѵ�.
void CSubj::ReleaseLect(CLect* lect)
{
	lect->EraseSubj();
	EraseLect(lect);
}

// static 

int CSubj::GetRow(LPCTSTR name)
{
	for(UINT i = 0; i < TheSubjs.size(); i++)
		if(((CSubj*) TheSubjs[i])->HasName(name))
			return (int) i;
	return ROW_NONE;
}

CSubj* CSubj::Create(LPCTSTR name)
{
	CSubj* subj = Get(name);
	if(subj == NULL)
	{
		subj = new CSubj(name);
		TheSubjs.push_back(subj);
	}
	return subj;
}

CSubj* CSubj::CreateForDlg()
{
	CString str;
	str.Format(NEW_NAME_FORMAT, IndexForNew);
	IndexForNew++;
	return Create(str);
}

CSubj* CSubj::Get(LPCTSTR name)
{
	CSubj *subj;
	for(CVecB::iterator i=TheSubjs.begin(); i!=TheSubjs.end(); i++)
	{
		subj = (CSubj*) *i;
		if(subj->HasName(name))
			return subj;
	}
	return NULL;
}

void CSubj::ClearTeam(CTeam* team)
{
	CSubj* subj;
	for(CVecB::iterator i = TheSubjs.begin(); i != TheSubjs.end(); i++)
	{
		subj = (CSubj*) *i;
		if(subj->m_team == team)
			subj->m_team = NULL;
	}
}

void CSubj::ClearLect(CLect* lect)
{
	for(CVecB::iterator i = TheSubjs.begin(); i != TheSubjs.end(); i++)
		((CSubj*) *i)->EraseLect(lect);
}

void CSubj::DetermineIndexForNew()
{
	CString str0(NEW_NAME_FORMAT);
	int pos = str0.Find(_T("%d"));
	str0.Truncate(pos);
	CString str1;
	int index;
	IndexForNew = 0;
	for(int i = 0; i < GetSize(); i++)
	{
		GetInString(i, COL_SUBJ_NAME, str1);
		if(str0.Compare(str1.Left(pos)) == 0)
		{
			_stscanf_s(str1.Mid(pos), _T("%d"), &index);
			if(index >= IndexForNew)
				IndexForNew = index + 1;
		}
	}
}