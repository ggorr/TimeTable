
// stdafx.cpp : ǥ�� ���� ���ϸ� ��� �ִ� �ҽ� �����Դϴ�.
// T.pch�� �̸� �����ϵ� ����� �˴ϴ�.
// stdafx.obj���� �̸� �����ϵ� ���� ������ ���Ե˴ϴ�.

#include "stdafx.h"



LPTSTR AllocCharBuffer(LPTSTR old, LPCTSTR str)
{
	if(str == NULL || _tcslen(str) == 0)
	{
		if(old != NULL)
			free(old);
		return NULL;
	}
	else
	{
		int len = _tcslen(str) + 1;
		LPTSTR buf = (LPTSTR) realloc(old, len*sizeof(TCHAR));
		_tcscpy_s(buf, len, str);
		return buf;
	}
}

LPTSTR NewCharBuffer(LPCTSTR str)
{
	if(str == NULL || _tcslen(str) == 0)
		return NULL;
	else
	{
		int len = _tcslen(str) + 1;
		LPTSTR buf = new TCHAR[len];
		_tcscpy_s(buf, len, str);
		return buf;
	}
}

CString& Enescape(CString& str)
{
	str.Replace(ESCAPE_STR, ESCAPE_CHAR_ESC);
	str.Replace(STARTOR_STR, STARTOR_ESC);
	str.Replace(PRI_SEPARATOR_STR, PRI_SEPARATOR_ESC);
	return str;
}

CString& Enescape(CString& dst, LPCTSTR src)
{
	dst = src;
	return Enescape(dst);
}

CString& AppendEscString(CString& dst, LPCTSTR src)
{
	CString str(src);
	dst.Append(Enescape(str));
//	dst.Append(Enescape(CString(src)));
	dst += PRI_SEPARATOR;
	return dst;
}

CString& Deescape(CString& str)
{
	int pos = 0;
	while((pos = str.Find(ESCAPE_CHAR, pos)) >= 0)
		str.Delete(pos++);
	return str;
}

CString& Deescape(CString& dst, LPCTSTR src)
{
	dst = src;
	return Deescape(dst);
}

CString GetModuleFolderPath()
{
	CString path;
	GetModuleFileName(AfxGetInstanceHandle(), path.GetBuffer(MAX_PATH), MAX_PATH);
	path.ReleaseBuffer();
	return path.Left(path.ReverseFind(_T('\\'))+1);
}
