#pragma once

class CLect : public CBase
{
	CSubj*	m_subj;
	CRoom*	m_room;
	int		m_day;
	int		m_sPrd;
	int		m_ePrd;
	LPTSTR	m_note;

	CTeam*	m_team;
	int		m_grade;

	BOOL	m_overlap;

	CLect(void);
public:
	~CLect(void);

	// inherited from CBase

	int GetRow();

	BOOL GetInString(int col, CString &str);
	BOOL SetByString(int col, LPCTSTR str);

	int  GetInt(int col);
	void SetInt(int col, int n);

	void ToString(CString& str);
	void FromString(const CString& str, int& pos);

	// not inherited

	inline BOOL HasSubj(CSubj* subj) {return m_subj == subj;}
	BOOL HasSubj(LPCTSTR name);
	inline CSubj* GetSubj() {return m_subj;}
	void SetSubj(CSubj *subj) {m_subj = subj;}
	void EraseSubj() {m_subj = NULL;}

	// subj�� �����Ѵ�. subj->m_lect == this, this->m_lect == subj
	void CaptureSubj(CSubj* subj);
	// m_subj�� ���踦 û���Ѵ�.
	void ReleaseSubj();

	inline BOOL HasRoom(CRoom* room) {return m_room == room;}
	BOOL HasRoom(LPCTSTR name);
	inline CRoom* GetRoom() {return m_room;}
	inline void SetRoom(CRoom *room) {m_room = room;}
	inline void EraseRoom() {m_room = NULL;}

	inline void SetDay(int day) {m_day = day;}
	inline int& GetDay() {return m_day;}

	inline void SetSPrd(int sPrd) {m_sPrd = sPrd;}
	inline int& GetSPrd() {return m_sPrd;}

	inline void SetEPrd(int ePrd) {m_ePrd = ePrd;}
	inline int& GetEPrd() {return m_ePrd;}

	inline void SetPrd(int sPrd, int ePrd) {m_sPrd = sPrd; m_ePrd = ePrd;}

	BOOL Contains(int grade, int day, int prd);

	inline BOOL& IsOverlapped() {return m_overlap;}
	BOOL IsOverlappedWith(CLect* lect);
	void PrepareDrag();		// only for drag
	BOOL IsOverlappedWith_Drag(CLect* lect);
	void CheckOverlap_Drag();	// only for drag

	// static
	static BOOL* Overlap;	// only for drag

	inline static int GetSize() {return (int) TheLects.size();}

	static CLect* Create();
	static CLect* Create(CSubj* subj, CRoom* room, int day, int sPrd, int ePrd);

	static CLect* CreateForDlg() {return Create();}

	inline static CLect* Get(int row) {return (CLect*) TheLects[row];}

	inline static void Exchange(int row0, int row1) {TheLects.Exchange(row0, row1);}

	inline static void Delete(CLect* lect) {TheLects.Delete(lect);}
	inline static void Delete(int row) {TheLects.Delete(row);}

	inline static void Clear() {TheLects.Clear();}

	inline static BOOL GetInString(int row, int col, CString &str) {return Get(row)->GetInString(col, str);}
	inline static BOOL SetByString(int row, int col, LPCTSTR  str) {return Get(row)->SetByString(col, str);}

	inline static int  GetInt(int row, int col) {return Get(row)->GetInt(col);}
	inline static void SetInt(int row, int col, int n) {Get(row)->SetInt(col, n);}

	// TheLects���� subj�� ��� �����Ѵ�.
	static void ClearSubj(CSubj* subj);
	// TheLects���� room�� ��� �����Ѵ�.
	static void ClearRoom(CRoom* room);
	// TheLects���� base�� ��� �����Ѵ�.
	// col == COL_LECT_ROOM �̸� CRoom* base, col == COL_LECT_SUBJ�̸� CSubj* base
	static void ClearSubbase(int col, CBase* base);

	inline static void ConvertToString(CString& str) {TheLects.ConvertToString(str);}
	inline static void BuildFromString(const CString& str) {TheLects.BuildFromString(str);}

	static void FullCheckOverlap();
};