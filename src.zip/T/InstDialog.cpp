// InstDialog.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "T.h"

#include "Base.h"
#include "Inst.h"
#include "Team.h"

#include "TDialog.h"
#include "InstDialog.h"
#include "TeamDialog.h"

#define WIDTH_NO	45
#define WIDTH_NAME	100
#define WIDTH_NOTE	150
#define WIDTH_LIST	(WIDTH_NO+WIDTH_NAME+WIDTH_NOTE+20)

// CInstListCtrl

IMPLEMENT_DYNAMIC(CInstListCtrl, CTListCtrl)

CInstListCtrl::CInstListCtrl()
{
	m_vecB = &TheInsts;

	m_nCols = 3;

	m_primaryCol = COL_INST_NAME;

	m_editableCols.push_back(COL_INST_NAME);
	m_editableCols.push_back(COL_INST_NOTE);
}

CInstListCtrl::~CInstListCtrl()
{
}

BEGIN_MESSAGE_MAP(CInstListCtrl, CTListCtrl)
//	ON_NOTIFY_REFLECT(LVN_BEGINDRAG, &CInstListCtrl::OnLvnBeginDrag)
	//ON_NOTIFY_REFLECT(NM_CLICK, &CInstListCtrl::OnNMClick)
END_MESSAGE_MAP()

COLORREF CInstListCtrl::OnGetCellBkColor(int nRow, int nColumn)
{
	return RGB(255,255,255);
}

void CInstListCtrl::Initialize()
{
	vector<LPCTSTR> labels;
	labels.push_back(_T("��ȣ"));
	labels.push_back(_T("�̸�"));
	labels.push_back(_T("��Ÿ"));

	vector<int> widths;
	widths.push_back(WIDTH_NO);
	widths.push_back(WIDTH_NAME);
	widths.push_back(WIDTH_NOTE);
	
	CTListCtrl::Initialize(labels, widths);
}

void CInstListCtrl::PostCopyEditToCell()
{
	if(m_selectedCol == COL_INST_NAME)
	{
		m_dlg->GetRefererDlg()->GetList()->UpdateCol(COL_TEAM_VNAME);
		m_dlg->GetRefererDlg()->GetList()->UpdateCol(COL_TEAM_INST);
		m_dlg->GetRefererDlg()->GetRefererDlg()->GetList()->UpdateCol(COL_SUBJ_TEAM);
		theApp.ResetTables();
	}
	else // if(m_selectedCol == COL_INST_NOTE)
		m_dlg->GetRefererDlg()->GetList()->UpdateCol(COL_TEAM_VNOTE);
}

void CInstListCtrl::ExchangeRows(int row0, int row1)
{
	int teamRow0, teamRow1;
	for(int i = 0; i < CTeam::GetSize(); i++)
	{
		if(CTeam::Get(i)->IsGroup())
			continue;
		if(CTeam::Get(i)->HasInst(CInst::Get(row0)))
			teamRow0 = i;
		if(CTeam::Get(i)->HasInst(CInst::Get(row1)))
			teamRow1 = i;
	}
	m_dlg->GetRefererDlg()->GetList()->GetVecB()->Exchange(teamRow0, teamRow1);
	m_dlg->GetRefererDlg()->GetList()->CTListCtrl::ExchangeRows(teamRow0, teamRow1);

	CTListCtrl::ExchangeRows(row0, row1);
}

// CInstDialog ��ȭ �����Դϴ�.

CInstDialog TheInstModelessDlg;

IMPLEMENT_DYNAMIC(CInstDialog, CTDialog)

CInstDialog::CInstDialog(CWnd* pParent /*=NULL*/)
	: CTDialog(CInstDialog::IDD, pParent)
{
}

CInstDialog::~CInstDialog()
{
}

void CInstDialog::DoDataExchange(CDataExchange* pDX)
{
	CTDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST, theList);
}


BEGIN_MESSAGE_MAP(CInstDialog, CTDialog)
	ON_BN_CLICKED(IDC_DELETE, &CInstDialog::OnBnClickedDelete)
END_MESSAGE_MAP()


// CInstDialog �޽��� ó�����Դϴ�.

BOOL CInstDialog::OnInitDialog()
{
	CTDialog::OnInitDialog();

	//SetWindowText(_T("���� ��� - ����"));
	m_list = &theList;

	PostInitDialog(WIDTH_LIST);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CInstDialog::OnBnAdd()
{
	CTDialog::OnBnAdd();

	m_refererDlg->GetList()->AppendRow();

	theApp.BuildTables();
	theApp.ResetTables();
}

void CInstDialog::OnBnClickedDelete()
{
	BOOL* insts = new BOOL[TheInsts.GetSize()];
	ZeroMemory(insts, sizeof(BOOL) * TheInsts.GetSize());
	BOOL* teams = new BOOL[TheTeams.GetSize()];
	ZeroMemory(teams, sizeof(BOOL) * TheTeams.GetSize());

	int count = 0;
	for(int i = 0; i < m_list->GetItemCount(); i++)
		if(m_list->GetCheck(i))
		{
			insts[i] = TRUE;
			for(int j = 0; j < TheTeams.GetSize(); j++)
				if(!CTeam::Get(j)->IsGroup() && CTeam::Get(j)->HasInst(CInst::Get(i)))
				{
					teams[j] = TRUE;
					if(j <= m_refererDlg->GetList()->GetSelectedRow())
						count++;
					break;
				}
		}
		m_refererDlg->GetList()->SetItemState(m_refererDlg->GetList()->GetSelectedRow(), 0, LVIS_SELECTED | LVIS_FOCUSED);
		m_refererDlg->GetList()->SetSelectedRow(m_refererDlg->GetList()->GetSelectedRow() - count);
		m_refererDlg->GetList()->SetItemState(m_refererDlg->GetList()->GetSelectedRow(), LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);

	// CTeamListCtrl�� CSubjListCtrl ����
	m_refererDlg->DeleteRowsAndUpdateReferer(teams, m_refererDlg->GetRefererDlg(), COL_SUBJ_TEAM);
	// CInstListCtrl ����
	DeleteRowsAndUpdateReferer(insts, m_refererDlg, COL_TEAM_INST);
	delete[] insts;
	delete[] teams;

	theApp.BuildTables();
	theApp.ResetTables();
}

