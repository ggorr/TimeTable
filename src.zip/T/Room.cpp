#include "StdAfx.h"
#include "T.h"
#include "Base.h"
#include "Room.h"

#include "DataManager.h"

#define NEW_NAME_FORMAT _T("�� ���ǽ� %d")

int CRoom::IndexForNew = 0;

CRoom::CRoom(LPCTSTR name)
{
	m_name = AllocCharBuffer(NULL, name);
	m_note = NULL;
}

CRoom::~CRoom(void)
{
	if(m_name != NULL)
		free(m_name);
	if(m_note != NULL)
		free(m_note);
}

int CRoom::GetRow()
{
	return TheRooms.GetRow(this);
}

BOOL CRoom::GetInString(int col, CString &str)
{
	switch(col)
	{
	case COL_INDEX:
		str.Format(_T("%d"), GetRow());
		break;
	case COL_THIS:
		str.SetString(m_name);
		break;
	case COL_ROOM_NAME:
		str.SetString(m_name);
		break;
	case COL_ROOM_NOTE:
		str.SetString(m_note);
		break;
	default:
		return CBase::GetInString(col, str);
	}
	return TRUE;
}

BOOL CRoom::SetByString(int col, LPCTSTR str)
{
	switch(col)
	{
	case COL_ROOM_NAME:
		m_name = AllocCharBuffer(m_name, str);
		break;
	case COL_ROOM_NOTE:
		m_note = AllocCharBuffer(m_note, str);
		break;
	default:
		return CBase::SetByString(col, str);
	}
	return TRUE;
}

void CRoom::ToString(CString& str)
{
	// index
	str.Format(_T("%d%c"), GetRow(), PRI_SEPARATOR);
	// name
	AppendEscString(str, m_name);
	// note
	AppendEscString(str, m_note);
	str += END_OF_LINE;
}

void CRoom::FromString(const CString& str, int& pos)
{
	CString str1;
	// index
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	// name
	if(!CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		return;
	// note
	m_name = AllocCharBuffer(m_name, Deescape(str1));
	if(CDataManager::GetSeparatedString(str, PRI_SEPARATOR, pos, str1))
		m_note = AllocCharBuffer(m_note, Deescape(str1));
}

// static

int CRoom::GetRow(LPCTSTR name)
{
	for(UINT i = 0; i < TheRooms.size(); i++)
		if(((CRoom*) TheRooms[i])->HasName(name))
			return (int) i;
	return ROW_NONE;
}

CRoom* CRoom::Create(LPCTSTR name)
{
	CRoom* room = Get(name);
	if(room == NULL)
	{
		room = new CRoom(name);
		TheRooms.push_back(room);
	}
	return room;
}

CRoom* CRoom::CreateForDlg()
{
	CString str;
	str.Format(NEW_NAME_FORMAT, IndexForNew);
	IndexForNew++;
	return Create(str);
}

CRoom* CRoom::Get(LPCTSTR name)
{
	CRoom *room;
	for(CVecB::iterator i=TheRooms.begin(); i!=TheRooms.end(); i++)
	{
		room = (CRoom*) *i;
		if(room->HasName(name))
			return room;
	}
	return NULL;
}

void CRoom::DetermineIndexForNew()
{
	CString str0(NEW_NAME_FORMAT);
	int pos = str0.Find(_T("%d"));
	str0.Truncate(pos);
	CString str1;
	int index;
	IndexForNew = 0;
	for(int i = 0; i < GetSize(); i++)
	{
		GetInString(i, COL_ROOM_NAME, str1);
		if(str0.Compare(str1.Left(pos)) == 0)
		{
			_stscanf_s(str1.Mid(pos), _T("%d"), &index);
			if(index >= IndexForNew)
				IndexForNew = index + 1;
		}
	}
}