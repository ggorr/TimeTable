// LectDialog.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "T.h"

#include "Base.h"
#include "Room.h"
#include "Subj.h"
#include "Lect.h"

#include "TDialog.h"
#include "RoomDialog.h"
#include "SubjDialog.h"
#include "LectDialog.h"

#include "TTable.h"
#include "GradeTable.h"

#include "DataManager.h"

#define WIDTH_NO	45
#define WIDTH_SUBJ	150
#define WIDTH_ROOM	120
#define WIDTH_DAY	40
#define WIDTH_PRD	50
#define WIDTH_GRADE	45
#define WIDTH_NOTE	100
#define WIDTH_LIST	(WIDTH_NO+WIDTH_SUBJ+WIDTH_ROOM+WIDTH_DAY+WIDTH_PRD+WIDTH_GRADE+WIDTH_NOTE+20)

//#define COLOR_SELECTEDCELL	RGB(192,192,192)

// CLectListCtrl

IMPLEMENT_DYNAMIC(CLectListCtrl, CTListCtrl)

CLectListCtrl::CLectListCtrl()
{
	m_vecB = &TheLects;

	m_nCols = 7;

	// primaryCol�� ���� row�� ���� �� ����.
	// COL_NONE�̸� ��� ����.
	m_primaryCol = COL_NONE;

	// editable column
	m_editableCols.push_back(COL_LECT_PRD);
	m_editableCols.push_back(COL_LECT_NOTE);

	m_comboBoxCols.push_back(COL_LECT_DAY);

	// function column
	m_funcCols.push_back(COL_LECT_SUBJ);
	m_funcCols.push_back(COL_LECT_ROOM);

	// function correspond to function column, ������ ���߾�� ��
	m_funcs.push_back(&CTListCtrl::PickSubj);
	m_funcs.push_back(&CTListCtrl::PickRoom);
}

CLectListCtrl::~CLectListCtrl()
{
}

BEGIN_MESSAGE_MAP(CLectListCtrl, CTListCtrl)
END_MESSAGE_MAP()

COLORREF CLectListCtrl::OnGetCellBkColor(int nRow, int nColumn)
{
	return RGB(255,255,255);
}

void CLectListCtrl::Initialize()
{
	vector<LPCTSTR> labels;
	labels.push_back(_T("��ȣ"));
	labels.push_back(_T("����"));
	labels.push_back(_T("���ǽ�"));
	labels.push_back(_T("����"));
	labels.push_back(_T("�ð�"));
	labels.push_back(_T("�г�"));
	labels.push_back(_T("��Ÿ"));

	vector<int>widths;
	widths.push_back(WIDTH_NO);
	widths.push_back(WIDTH_SUBJ);
	widths.push_back(WIDTH_ROOM);
	widths.push_back(WIDTH_DAY);
	widths.push_back(WIDTH_PRD);
	widths.push_back(WIDTH_GRADE);	
	widths.push_back(WIDTH_NOTE);

	vector<int> lvcfmt;
	lvcfmt.push_back(LVCFMT_LEFT);
	lvcfmt.push_back(LVCFMT_LEFT);
	lvcfmt.push_back(LVCFMT_LEFT);
	lvcfmt.push_back(LVCFMT_CENTER);
	lvcfmt.push_back(LVCFMT_CENTER);
	lvcfmt.push_back(LVCFMT_CENTER);
	lvcfmt.push_back(LVCFMT_LEFT);

	CTListCtrl::Initialize(labels, widths, lvcfmt);
}

void CLectListCtrl::PostCopyEditToCell()
{
	if(m_selectedCol == COL_LECT_PRD)
		m_dlg->GetRefererDlg()->GetList()->UpdateCol(COL_SUBJ_NPRDS);
	theApp.ResetTables();
}

void CLectListCtrl::ExchangeRows(int row0, int row1)
{
	CTListCtrl::ExchangeRows(row0, row1);
	TheSubjModelessDlg.GetList()->UpdateCol(COL_SUBJ_LECT);
}		

void CLectListCtrl::PickRoom()
{
	CRoomDialog dlg;
	// dlg�� call�ϴ� dialog�� CLectDialog�̴�.
	dlg.SetRefererDlg(m_dlg);
	dlg.SetMode(MODE_MODAL);
	dlg.SetTitle(_T("���ǽ� ���"));
	dlg.SetMaxCheckedRows(1);

	// ��ϵ� ���ǽ��� dialog�� �Ѱܼ� check�ϵ��� �Ѵ�.
	CLect* lect = CLect::Get(m_selectedRow);
	if(lect->GetRoom() != NULL)
		dlg.PushBackCheckedRow(lect->GetRoom()->GetRow());

	if(dlg.DoModal() == IDC_SELECT)
	{
		if(dlg.GetCheckedRows().size() == 0)
			lect->SetRoom(NULL);
		else
			lect->SetRoom(CRoom::Get(dlg.GetCheckedRows()[0]));
		UpdateRow(m_selectedRow);
		theApp.ResetTables();
	}
	m_state = DSTATE_SELECTED;
}

void CLectListCtrl::PickSubj()
{
	CSubjDialog dlg;
	// dlg�� call�ϴ� dialog�� CLectDialog�̴�.
	dlg.SetRefererDlg(m_dlg);
	dlg.SetMode(MODE_MODAL);
	dlg.SetTitle(_T("������ ��� - ����"));
	dlg.SetMaxCheckedRows(1);

	CLect* lect = CLect::Get(m_selectedRow);
	if(lect->GetSubj() != NULL)
		dlg.PushBackCheckedRow(lect->GetSubj()->GetRow());

	if(dlg.DoModal() == IDC_SELECT)
	{
		if(dlg.GetCheckedRows().size() == 0)
			lect->CaptureSubj(NULL);
		else
			lect->CaptureSubj(CSubj::Get(dlg.GetCheckedRows()[0]));
		UpdateRow(m_selectedRow);
		TheSubjModelessDlg.GetList()->UpdateCol(COL_SUBJ_LECT);
		theApp.ResetTables();
	}
	m_state = DSTATE_SELECTED;
}

// CLectDialog ��ȭ �����Դϴ�.

CLectDialog TheLectModelessDlg;

IMPLEMENT_DYNAMIC(CLectDialog, CTDialog)

CLectDialog::CLectDialog(CWnd* pParent /*=NULL*/)
	: CTDialog(CLectDialog::IDD, pParent)
{
}

CLectDialog::~CLectDialog()
{
}

void CLectDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST, theList);
}


BEGIN_MESSAGE_MAP(CLectDialog, CTDialog)
	ON_BN_CLICKED(IDC_DELETE, &CLectDialog::OnBnClickedDelete)
END_MESSAGE_MAP()


// CLectDialog �޽��� ó�����Դϴ�.

BOOL CLectDialog::OnInitDialog()
{
	CTDialog::OnInitDialog();
	
	m_refererDlg = &TheSubjModelessDlg;
	//SetWindowText(_T("���� ���"));
	m_list = &theList;

	theComboBox.Create(WS_CHILD | CBS_DROPDOWNLIST, CRect(0,0,0,0), this, IDC_COMBO);
	theList.SetComboBox(&theComboBox);

	PostInitDialog(WIDTH_LIST);

	for(int i = 0; i < TheDataMgr.GetNDays(); i++)
		theComboBox.AddString(TheDataMgr.GetDay(i));
	theComboBox.AddString(_T("����"));

	GetDlgItem(IDC_SELECT)->EnableWindow(FALSE);
	//GetDlgItem(IDC_ADD)->EnableWindow(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CLectDialog::OnBnClickedDelete()
{
	DeleteCheckedRowsAndUpdateReferer(&TheSubjModelessDlg, COL_SUBJ_LECT);
	TheSubjModelessDlg.GetList()->UpdateCol0(COL_SUBJ_NPRDS);
	theApp.ResetTables();
}

//void CLectDialog::OnExit()
//{
//}
